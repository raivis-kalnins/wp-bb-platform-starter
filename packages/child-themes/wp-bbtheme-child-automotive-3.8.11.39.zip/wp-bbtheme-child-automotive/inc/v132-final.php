<?php
/**
 * v3.8.11.32 Automotive deterministic homepage + WooCommerce repair.
 *
 * This layer intentionally avoids another global Bootstrap reset. It owns only
 * Automotive homepage repairs and the child-owned WooCommerce legacy routes.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v132_is_automotive' ) ) {
    function wpbb_child_v132_is_automotive() {
        return false !== strpos( strtolower( basename( get_stylesheet_directory() ) ), 'automotive' );
    }
}

if ( ! function_exists( 'wpbb_child_v132_enqueue' ) ) {
    function wpbb_child_v132_enqueue() {
        if ( ! wpbb_child_v132_is_automotive() ) return;
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v132.css';
        $js  = '/assets/suite-v132.js';

        wp_enqueue_style(
            'wpbb-suite-v132',
            $uri . $css,
            array( 'wpbb-suite-v131' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.32'
        );
        wp_enqueue_script(
            'wpbb-suite-v132',
            $uri . $js,
            array( 'wpbb-suite-v131' ),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.32',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v132',
            'window.wpbbSuiteV132=' . wp_json_encode( array(
                'themeSlug' => basename( $dir ),
                'version'   => '3.8.11.32',
            ) ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v132_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v132_body_class' ) ) {
    function wpbb_child_v132_body_class( $classes ) {
        if ( wpbb_child_v132_is_automotive() ) $classes[] = 'wpbb-v132-theme-automotive';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v132_body_class', PHP_INT_MAX );

/* WooCommerce normally owns these callbacks. Older compatibility layers in a
 * long-running demo can lose them; put them back only if they are absent. */
if ( ! function_exists( 'wpbb_child_v132_checkout_callbacks' ) ) {
    function wpbb_child_v132_checkout_callbacks() {
        if ( ! wpbb_child_v132_is_automotive() || ! function_exists( 'is_checkout' ) ) return;
        if ( function_exists( 'woocommerce_order_review' ) && false === has_action( 'woocommerce_checkout_order_review', 'woocommerce_order_review' ) ) {
            add_action( 'woocommerce_checkout_order_review', 'woocommerce_order_review', 10 );
        }
        if ( function_exists( 'woocommerce_checkout_payment' ) && false === has_action( 'woocommerce_checkout_order_review', 'woocommerce_checkout_payment' ) ) {
            add_action( 'woocommerce_checkout_order_review', 'woocommerce_checkout_payment', 20 );
        }
    }
}
add_action( 'wp_loaded', 'wpbb_child_v132_checkout_callbacks', PHP_INT_MAX );

/* Keep checkout transactional. Marketing/newsletter consent belongs to the
 * footer form, not to billing/payment. */
if ( ! function_exists( 'wpbb_child_v132_strip_marketing_checkout_fields' ) ) {
    function wpbb_child_v132_strip_marketing_checkout_fields( $fields ) {
        if ( ! wpbb_child_v132_is_automotive() || ! is_array( $fields ) ) return $fields;
        $pattern = '/newsletter|newslatter|marketing|email[ _-]*updates|subscribe/';
        foreach ( $fields as $key => $value ) {
            if ( ! is_array( $value ) ) continue;

            $looks_like_field = array_key_exists( 'type', $value ) || array_key_exists( 'label', $value ) || array_key_exists( 'class', $value );
            if ( $looks_like_field ) {
                $label = isset( $value['label'] ) ? strtolower( wp_strip_all_tags( (string) $value['label'] ) ) : '';
                $hay = strtolower( (string) $key . ' ' . $label );
                if ( preg_match( $pattern, $hay ) ) unset( $fields[ $key ] );
                continue;
            }

            foreach ( $value as $field_key => $field ) {
                if ( ! is_array( $field ) ) continue;
                $label = isset( $field['label'] ) ? strtolower( wp_strip_all_tags( (string) $field['label'] ) ) : '';
                $hay = strtolower( (string) $field_key . ' ' . $label );
                if ( preg_match( $pattern, $hay ) ) unset( $fields[ $key ][ $field_key ] );
            }
        }
        return $fields;
    }
}
add_filter( 'woocommerce_checkout_fields', 'wpbb_child_v132_strip_marketing_checkout_fields', PHP_INT_MAX );
add_filter( 'woocommerce_get_additional_checkout_fields', 'wpbb_child_v132_strip_marketing_checkout_fields', PHP_INT_MAX );

/* Make related products use the available lower-product width. */
if ( ! function_exists( 'wpbb_child_v132_related_args' ) ) {
    function wpbb_child_v132_related_args( $args ) {
        if ( ! wpbb_child_v132_is_automotive() || ! is_array( $args ) ) return $args;
        $args['posts_per_page'] = max( 3, isset( $args['posts_per_page'] ) ? (int) $args['posts_per_page'] : 3 );
        $args['columns'] = 3;
        return $args;
    }
}
add_filter( 'woocommerce_output_related_products_args', 'wpbb_child_v132_related_args', PHP_INT_MAX );
