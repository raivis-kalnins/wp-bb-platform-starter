<?php
/**
 * WP BBTheme child Automotive 3.8.11.38 - hero pagination + homepage rhythm finish.
 *
 * Adds a child-owned hero pager without restoring the retired v119-v136 layout
 * stack, tightens only the Automotive homepage's vertical rhythm, and provides
 * one last HTML-level guard against legacy proof-card placeholders.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'wpbb_child_v138_enqueue' ) ) {
    function wpbb_child_v138_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v138.css';
        $js  = '/assets/suite-v138.js';

        if ( is_readable( $dir . $css ) ) {
            wp_enqueue_style(
                'wpbb-suite-v138',
                $uri . $css,
                wp_style_is( 'wpbb-suite-v137', 'registered' ) || wp_style_is( 'wpbb-suite-v137', 'enqueued' ) ? array( 'wpbb-suite-v137' ) : array(),
                (string) filemtime( $dir . $css )
            );
        }
        if ( is_readable( $dir . $js ) ) {
            wp_enqueue_script(
                'wpbb-suite-v138',
                $uri . $js,
                wp_script_is( 'wpbb-suite-v137', 'registered' ) || wp_script_is( 'wpbb-suite-v137', 'enqueued' ) ? array( 'wpbb-suite-v137' ) : array(),
                (string) filemtime( $dir . $js ),
                true
            );
            wp_add_inline_script(
                'wpbb-suite-v138',
                'window.wpbbSuiteV138=' . wp_json_encode( array( 'version' => '3.8.11.38' ) ) . ';',
                'before'
            );
        }
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v138_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v138_body_class' ) ) {
    function wpbb_child_v138_body_class( $classes ) {
        $classes[] = 'wpbb-v138';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v138_body_class', PHP_INT_MAX );

/**
 * Some older imported homepages contain the proof band as already-rendered or
 * legacy content outside the normal block filters. Keep the database untouched
 * on anonymous requests, but guarantee correct Automotive copy in final HTML.
 */
if ( ! function_exists( 'wpbb_child_v138_front_html' ) ) {
    function wpbb_child_v138_front_html( $html ) {
        if ( ! is_string( $html ) || '' === $html ) return $html;
        if ( function_exists( 'wpbb_child_v137_repair_placeholder_string' ) ) {
            $html = wpbb_child_v137_repair_placeholder_string( $html );
        }
        return $html;
    }
}

if ( ! function_exists( 'wpbb_child_v138_start_front_buffer' ) ) {
    function wpbb_child_v138_start_front_buffer() {
        if ( is_admin() || ! is_front_page() || is_feed() || ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) ) return;
        ob_start( 'wpbb_child_v138_front_html' );
    }
}
add_action( 'template_redirect', 'wpbb_child_v138_start_front_buffer', 0 );
