<?php
/**
 * v3.8.11.33 Automotive final DOM ownership layer.
 * Repairs only the recurring live homepage/card/catalogue/hero issues and
 * leaves the recovered global Bootstrap/BBuilder geometry untouched.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v133_auto_is_theme' ) ) {
    function wpbb_child_v133_auto_is_theme() {
        return false !== strpos( strtolower( basename( get_stylesheet_directory() ) ), 'automotive' );
    }
}

if ( ! function_exists( 'wpbb_child_v133_auto_hero_urls' ) ) {
    function wpbb_child_v133_auto_hero_urls() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $urls = array();
        foreach ( array( 1, 2, 3 ) as $i ) {
            $rel = 'assets/img/hero-v118/slide-' . $i . '.jpg';
            $path = $dir . '/' . $rel;
            if ( is_file( $path ) ) $urls[] = $uri . '/' . $rel . '?v=' . filemtime( $path );
        }
        return $urls;
    }
}

if ( ! function_exists( 'wpbb_child_v133_auto_enqueue' ) ) {
    function wpbb_child_v133_auto_enqueue() {
        if ( ! wpbb_child_v133_auto_is_theme() ) return;
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v133.css';
        $js  = '/assets/suite-v133.js';
        wp_enqueue_style(
            'wpbb-suite-v133',
            $uri . $css,
            array( 'wpbb-suite-v132' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.33'
        );
        wp_enqueue_script(
            'wpbb-suite-v133',
            $uri . $js,
            array( 'wpbb-suite-v132' ),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.33',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v133',
            'window.wpbbAutoV133=' . wp_json_encode( array(
                'version' => '3.8.11.33',
                'heroUrls' => wpbb_child_v133_auto_hero_urls(),
                'process' => array(
                    array( '01', 'Search', 'Filter by condition, make, fuel and budget.' ),
                    array( '02', 'Compare', 'Review year, mileage, gearbox and pricing.' ),
                    array( '03', 'Act', 'Enquire, arrange a test drive, request rental or shop parts.' ),
                ),
            ) ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v133_auto_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v133_auto_body_class' ) ) {
    function wpbb_child_v133_auto_body_class( $classes ) {
        if ( wpbb_child_v133_auto_is_theme() ) $classes[] = 'wpbb-v133-theme-automotive';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v133_auto_body_class', PHP_INT_MAX );
