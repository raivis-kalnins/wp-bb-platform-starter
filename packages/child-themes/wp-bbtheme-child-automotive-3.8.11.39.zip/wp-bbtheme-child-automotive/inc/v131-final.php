<?php
/**
 * v3.8.11.31 Automotive live commerce/homepage hardening.
 *
 * Fixes the remaining live issues without changing the recovered global layout:
 * - duplicate vehicle finder on the homepage;
 * - process badges and homepage product catalogue geometry;
 * - shop compare controls;
 * - single-product width, add-to-cart and related-product grid;
 * - deterministic two-column cart shell;
 * - checkout order-review column, while keeping newsletter-consent cleanup safe.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v131_is_automotive' ) ) {
    function wpbb_child_v131_is_automotive() {
        return false !== strpos( strtolower( basename( get_stylesheet_directory() ) ), 'automotive' );
    }
}

if ( ! function_exists( 'wpbb_child_v131_enqueue' ) ) {
    function wpbb_child_v131_enqueue() {
        if ( ! wpbb_child_v131_is_automotive() ) {
            return;
        }
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v131.css';
        $js  = '/assets/suite-v131.js';

        wp_enqueue_style(
            'wpbb-suite-v131',
            $uri . $css,
            array( 'wpbb-suite-v130' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.31'
        );
        wp_enqueue_script(
            'wpbb-suite-v131',
            $uri . $js,
            array( 'wpbb-suite-v130' ),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.31',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v131',
            'window.wpbbSuiteV131=' . wp_json_encode( array(
                'themeSlug' => basename( $dir ),
                'version'   => '3.8.11.31',
            ) ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v131_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v131_body_class' ) ) {
    function wpbb_child_v131_body_class( $classes ) {
        if ( wpbb_child_v131_is_automotive() ) {
            $classes[] = 'wpbb-v131-theme-automotive';
        }
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v131_body_class', PHP_INT_MAX );

/**
 * Do not add any marketing/newsletter field to Checkout.  v130 already removes
 * field-array based additions; this catches common plugin keys that are added
 * through the additional-fields API in newer WooCommerce versions.
 */
if ( ! function_exists( 'wpbb_child_v131_checkout_additional_fields' ) ) {
    function wpbb_child_v131_checkout_additional_fields( $fields ) {
        if ( ! wpbb_child_v131_is_automotive() || ! is_array( $fields ) ) {
            return $fields;
        }
        foreach ( $fields as $key => $field ) {
            $label = is_array( $field ) && isset( $field['label'] ) ? strtolower( wp_strip_all_tags( (string) $field['label'] ) ) : '';
            $haystack = strtolower( (string) $key . ' ' . $label );
            if ( preg_match( '/newsletter|newslatter|marketing|email[ _-]*updates|subscribe/', $haystack ) ) {
                unset( $fields[ $key ] );
            }
        }
        return $fields;
    }
}
add_filter( 'woocommerce_get_additional_checkout_fields', 'wpbb_child_v131_checkout_additional_fields', PHP_INT_MAX );
