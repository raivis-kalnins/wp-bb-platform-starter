<?php
/**
 * v3.8.11.30 Automotive commerce/account finish.
 *
 * - Forces the Cart into a stable two-column desktop layout.
 * - Removes the accidental checkout marketing-consent control.
 * - Restores WooCommerce My Account page ownership and endpoint URLs.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v130_is_automotive' ) ) {
    function wpbb_child_v130_is_automotive() {
        return false !== strpos( strtolower( basename( get_stylesheet_directory() ) ), 'automotive' );
    }
}

if ( ! function_exists( 'wpbb_child_v130_enqueue' ) ) {
    function wpbb_child_v130_enqueue() {
        if ( ! wpbb_child_v130_is_automotive() ) {
            return;
        }
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v130.css';
        $js  = '/assets/suite-v130.js';

        wp_enqueue_style(
            'wpbb-suite-v130',
            $uri . $css,
            array( 'wpbb-suite-v129' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.30'
        );
        wp_enqueue_script(
            'wpbb-suite-v130',
            $uri . $js,
            array( 'wpbb-suite-v129' ),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.30',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v130',
            'window.wpbbSuiteV130=' . wp_json_encode( array(
                'themeSlug' => basename( $dir ),
                'version'   => '3.8.11.30',
            ) ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v130_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v130_body_class' ) ) {
    function wpbb_child_v130_body_class( $classes ) {
        if ( wpbb_child_v130_is_automotive() ) {
            $classes[] = 'wpbb-v130-theme-automotive';
        }
        return $classes;
    }
}
add_filter( 'body_class', 'wpbb_child_v130_body_class', PHP_INT_MAX );

/**
 * Make sure WooCommerce knows which Page owns the My Account endpoints.
 * Older demo imports can leave woocommerce_myaccount_page_id empty or stale,
 * which makes WooCommerce generate /lost-password/ and /orders/ at site root.
 */
if ( ! function_exists( 'wpbb_child_v130_ensure_myaccount_page' ) ) {
    function wpbb_child_v130_ensure_myaccount_page() {
        if ( ! wpbb_child_v130_is_automotive() || ( ! class_exists( 'WooCommerce' ) && ! function_exists( 'WC' ) ) ) {
            return;
        }

        $page = get_page_by_path( 'my-account', OBJECT, 'page' );
        if ( ! $page || 'publish' !== $page->post_status ) {
            return;
        }

        $current = absint( get_option( 'woocommerce_myaccount_page_id' ) );
        if ( $current !== (int) $page->ID ) {
            update_option( 'woocommerce_myaccount_page_id', (int) $page->ID, false );
        }
    }
}
add_action( 'init', 'wpbb_child_v130_ensure_myaccount_page', 35 );

if ( ! function_exists( 'wpbb_child_v130_account_endpoints' ) ) {
    function wpbb_child_v130_account_endpoints() {
        return array(
            'orders',
            'downloads',
            'edit-address',
            'edit-account',
            'payment-methods',
            'lost-password',
            'view-order',
            'add-payment-method',
            'delete-payment-method',
            'set-default-payment-method',
            'customer-logout',
        );
    }
}

/** Explicit account endpoint rules as a fallback for imported permalink data. */
if ( ! function_exists( 'wpbb_child_v130_account_rewrites' ) ) {
    function wpbb_child_v130_account_rewrites() {
        if ( ! wpbb_child_v130_is_automotive() || ( ! class_exists( 'WooCommerce' ) && ! function_exists( 'WC' ) ) ) {
            return;
        }

        foreach ( wpbb_child_v130_account_endpoints() as $endpoint ) {
            add_rewrite_endpoint( $endpoint, EP_PAGES );
            add_rewrite_rule(
                '^my-account/' . preg_quote( $endpoint, '~' ) . '/?$',
                'index.php?pagename=my-account&' . $endpoint . '=',
                'top'
            );
            add_rewrite_rule(
                '^my-account/' . preg_quote( $endpoint, '~' ) . '/([^/]+)/?$',
                'index.php?pagename=my-account&' . $endpoint . '=$matches[1]',
                'top'
            );
        }
    }
}
add_action( 'init', 'wpbb_child_v130_account_rewrites', 80 );

if ( ! function_exists( 'wpbb_child_v130_query_vars' ) ) {
    function wpbb_child_v130_query_vars( $vars ) {
        if ( ! wpbb_child_v130_is_automotive() ) {
            return $vars;
        }
        foreach ( wpbb_child_v130_account_endpoints() as $endpoint ) {
            if ( ! in_array( $endpoint, $vars, true ) ) {
                $vars[] = $endpoint;
            }
        }
        return $vars;
    }
}
add_filter( 'query_vars', 'wpbb_child_v130_query_vars', PHP_INT_MAX );

/**
 * Canonicalise endpoint URLs against /my-account/ even before the one-time
 * rewrite refresh has run.
 */
if ( ! function_exists( 'wpbb_child_v130_endpoint_url' ) ) {
    function wpbb_child_v130_endpoint_url( $url, $endpoint, $value, $permalink ) {
        if ( ! wpbb_child_v130_is_automotive() || ! in_array( $endpoint, wpbb_child_v130_account_endpoints(), true ) ) {
            return $url;
        }

        $page = get_page_by_path( 'my-account', OBJECT, 'page' );
        if ( ! $page || 'publish' !== $page->post_status ) {
            return $url;
        }

        $base = trailingslashit( get_permalink( $page ) );
        $path = $endpoint . '/';
        if ( '' !== (string) $value ) {
            $path .= rawurlencode( (string) $value ) . '/';
        }
        return $base . $path;
    }
}
add_filter( 'woocommerce_get_endpoint_url', 'wpbb_child_v130_endpoint_url', PHP_INT_MAX, 4 );

/** Root-level legacy endpoints should never 404 on this demo. */
if ( ! function_exists( 'wpbb_child_v130_account_root_redirect' ) ) {
    function wpbb_child_v130_account_root_redirect() {
        if ( ! wpbb_child_v130_is_automotive() || is_admin() || wp_doing_ajax() ) {
            return;
        }

        $path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
        if ( '' === $path || 0 === strpos( $path, 'my-account/' ) ) {
            return;
        }

        $parts = array_values( array_filter( explode( '/', $path ), 'strlen' ) );
        if ( empty( $parts ) ) {
            return;
        }
        $endpoint = sanitize_key( $parts[0] );
        if ( ! in_array( $endpoint, wpbb_child_v130_account_endpoints(), true ) ) {
            return;
        }

        $page = get_page_by_path( 'my-account', OBJECT, 'page' );
        if ( ! $page || 'publish' !== $page->post_status ) {
            return;
        }

        $target = trailingslashit( get_permalink( $page ) ) . $endpoint . '/';
        if ( isset( $parts[1] ) && '' !== $parts[1] ) {
            $target .= rawurlencode( sanitize_text_field( $parts[1] ) ) . '/';
        }
        wp_safe_redirect( $target, 302 );
        exit;
    }
}
add_action( 'template_redirect', 'wpbb_child_v130_account_root_redirect', 0 );

/** One automatic rewrite refresh for v130; no wp-admin visit is required. */
if ( ! function_exists( 'wpbb_child_v130_flush_rewrites_once' ) ) {
    function wpbb_child_v130_flush_rewrites_once() {
        if ( ! wpbb_child_v130_is_automotive() || ( ! class_exists( 'WooCommerce' ) && ! function_exists( 'WC' ) ) ) {
            return;
        }
        $key = 'wpbb_child_v130_rewrites_' . sanitize_key( get_stylesheet() );
        if ( '3.8.11.30' === (string) get_option( $key ) ) {
            return;
        }
        flush_rewrite_rules( false );
        update_option( $key, '3.8.11.30', false );
    }
}
add_action( 'wp_loaded', 'wpbb_child_v130_flush_rewrites_once', PHP_INT_MAX );

/** Keep the logged-in account navigation complete and predictable. */
if ( ! function_exists( 'wpbb_child_v130_account_menu' ) ) {
    function wpbb_child_v130_account_menu( $items ) {
        if ( ! wpbb_child_v130_is_automotive() ) {
            return $items;
        }
        $preferred = array(
            'dashboard'       => __( 'Dashboard', 'wp-theme' ),
            'orders'          => __( 'Orders', 'wp-theme' ),
            'downloads'       => __( 'Downloads', 'wp-theme' ),
            'edit-address'    => __( 'Addresses', 'wp-theme' ),
            'payment-methods' => __( 'Payment methods', 'wp-theme' ),
            'edit-account'    => __( 'Account details', 'wp-theme' ),
            'customer-logout' => __( 'Log out', 'wp-theme' ),
        );
        $out = array();
        foreach ( $preferred as $key => $label ) {
            if ( isset( $items[ $key ] ) || 'payment-methods' !== $key ) {
                $out[ $key ] = isset( $items[ $key ] ) ? $items[ $key ] : $label;
            }
        }
        foreach ( $items as $key => $label ) {
            if ( ! isset( $out[ $key ] ) ) {
                $out[ $key ] = $label;
            }
        }
        return $out;
    }
}
add_filter( 'woocommerce_account_menu_items', 'wpbb_child_v130_account_menu', 999 );

/** Remove marketing/newsletter fields that plugins add through checkout fields. */
if ( ! function_exists( 'wpbb_child_v130_checkout_fields' ) ) {
    function wpbb_child_v130_checkout_fields( $fields ) {
        if ( ! wpbb_child_v130_is_automotive() || ! is_array( $fields ) ) {
            return $fields;
        }
        foreach ( $fields as $group => $group_fields ) {
            if ( ! is_array( $group_fields ) ) {
                continue;
            }
            foreach ( $group_fields as $key => $field ) {
                $label = is_array( $field ) && isset( $field['label'] ) ? strtolower( wp_strip_all_tags( (string) $field['label'] ) ) : '';
                $haystack = strtolower( (string) $key . ' ' . $label );
                if ( preg_match( '/newsletter|newslatter|marketing|email[ _-]*updates|subscribe/', $haystack ) ) {
                    unset( $fields[ $group ][ $key ] );
                }
            }
        }
        return $fields;
    }
}
add_filter( 'woocommerce_checkout_fields', 'wpbb_child_v130_checkout_fields', PHP_INT_MAX );
