<?php
/**
 * WP BBTheme child Automotive 3.8.11.37 - scoped layout recovery.
 *
 * v136 fixed some individual rows but left a large stack of historical CSS
 * active. This release returns the frontend to the stable v118 base and adds
 * one Automotive-only owner for alignment, grids, catalogue and proof cards.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* v137 is the only late layout owner. */
remove_action( 'wp_enqueue_scripts', 'wpbb_child_v136_enqueue', PHP_INT_MAX );
remove_filter( 'body_class', 'wpbb_child_v136_body_class', PHP_INT_MAX );
remove_filter( 'body_class', 'wpbb_child_v135_body_class', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v137_proof_cards' ) ) {
    function wpbb_child_v137_proof_cards() {
        return array(
            array(
                'title' => 'Vehicle discovery',
                'text'  => 'Browse new, used and rental stock with useful filters for make, fuel, transmission and budget.',
            ),
            array(
                'title' => 'Ownership services',
                'text'  => 'Keep servicing, diagnostics, repair and rental enquiries connected to the same vehicle journey.',
            ),
            array(
                'title' => 'Parts & accessories',
                'text'  => 'Shop practical parts and accessories through the same WooCommerce basket, checkout and account.',
            ),
        );
    }
}

if ( ! function_exists( 'wpbb_child_v137_is_commerce_route' ) ) {
    function wpbb_child_v137_is_commerce_route() {
        return ( function_exists( 'is_woocommerce' ) && is_woocommerce() )
            || ( function_exists( 'is_cart' ) && is_cart() )
            || ( function_exists( 'is_checkout' ) && is_checkout() )
            || ( function_exists( 'is_account_page' ) && is_account_page() );
    }
}

if ( ! function_exists( 'wpbb_child_v137_enqueue' ) ) {
    function wpbb_child_v137_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();

        /*
         * v119-v136 are incremental emergency layers. Loading all of their CSS
         * together is the source of the current 1180/1320/1440 shell conflict.
         * Keep v118 as the stable Bootstrap/menu/media base and replace later
         * homepage geometry/runtime layers with v137. Commerce-only v130/v132
         * assets are restored below only on WooCommerce routes.
         */
        foreach ( range( 119, 136 ) as $n ) {
            $handle = 'wpbb-suite-v' . $n;
            wp_dequeue_style( $handle );
            wp_deregister_style( $handle );
            wp_dequeue_script( $handle );
            wp_deregister_script( $handle );
        }

        $base_css = $dir . '/assets/suite-v118.css';
        $base_js  = $dir . '/assets/suite-v118.js';
        if ( is_readable( $base_css ) ) {
            wp_enqueue_style( 'wpbb-suite-v118', $uri . '/assets/suite-v118.css', array(), (string) filemtime( $base_css ) );
        }
        if ( is_readable( $base_js ) ) {
            wp_enqueue_script( 'wpbb-suite-v118', $uri . '/assets/suite-v118.js', array(), (string) filemtime( $base_js ), false );
        }

        /* Keep the proven Automotive commerce/account repairs off the homepage. */
        if ( wpbb_child_v137_is_commerce_route() ) {
            $commerce_layers = array( 130, 132 );
            foreach ( $commerce_layers as $commerce_version ) {
                $commerce_css = '/assets/suite-v' . $commerce_version . '.css';
                $commerce_js  = '/assets/suite-v' . $commerce_version . '.js';
                $commerce_handle = 'wpbb-suite-v' . $commerce_version;

                if ( is_readable( $dir . $commerce_css ) ) {
                    wp_enqueue_style(
                        $commerce_handle,
                        $uri . $commerce_css,
                        is_readable( $base_css ) ? array( 'wpbb-suite-v118' ) : array(),
                        (string) filemtime( $dir . $commerce_css )
                    );
                }
                if ( is_readable( $dir . $commerce_js ) ) {
                    wp_enqueue_script(
                        $commerce_handle,
                        $uri . $commerce_js,
                        is_readable( $base_js ) ? array( 'wpbb-suite-v118' ) : array(),
                        (string) filemtime( $dir . $commerce_js ),
                        true
                    );
                    wp_add_inline_script(
                        $commerce_handle,
                        'window.wpbbSuiteV' . $commerce_version . '=' . wp_json_encode(
                            array(
                                'themeSlug' => basename( $dir ),
                                'version'   => '3.8.11.' . $commerce_version,
                            )
                        ) . ';',
                        'before'
                    );
                }
            }
        }

        $css = '/assets/suite-v137.css';
        $js  = '/assets/suite-v137.js';
        wp_enqueue_style(
            'wpbb-suite-v137',
            $uri . $css,
            is_readable( $base_css ) ? array( 'wpbb-suite-v118' ) : array(),
            is_file( $dir . $css ) ? (string) filemtime( $dir . $css ) : '3.8.11.37'
        );
        wp_enqueue_script(
            'wpbb-suite-v137',
            $uri . $js,
            is_readable( $base_js ) ? array( 'wpbb-suite-v118' ) : array(),
            is_file( $dir . $js ) ? (string) filemtime( $dir . $js ) : '3.8.11.37',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v137',
            'window.wpbbSuiteV137=' . wp_json_encode(
                array(
                    'version' => '3.8.11.37',
                    'cards'   => wpbb_child_v137_proof_cards(),
                ),
                JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
            ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v137_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v137_body_class' ) ) {
    function wpbb_child_v137_body_class( $classes ) {
        $classes[] = 'wpbb-v137';
        $classes[] = 'wpbb-v137-theme-automotive';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v137_body_class', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v137_replace_sequence' ) ) {
    function wpbb_child_v137_replace_sequence( $content, $needle, $replacements ) {
        $content = (string) $content;
        $replacements = array_values( array_filter( array_map( 'strval', (array) $replacements ), 'strlen' ) );
        if ( '' === $content || '' === (string) $needle || ! $replacements ) return $content;

        $index = 0;
        $guard = 0;
        while ( false !== ( $pos = strpos( $content, (string) $needle ) ) && $guard < 50 ) {
            $replacement = $replacements[ $index % count( $replacements ) ];
            $content = substr_replace( $content, $replacement, $pos, strlen( (string) $needle ) );
            $index++;
            $guard++;
        }
        return $content;
    }
}

if ( ! function_exists( 'wpbb_child_v137_repair_placeholder_string' ) ) {
    function wpbb_child_v137_repair_placeholder_string( $content ) {
        if ( ! is_string( $content ) || '' === $content ) return $content;
        if ( false === strpos( $content, 'Card title' ) && false === strpos( $content, 'Add a short description.' ) ) return $content;

        $titles = array();
        $texts  = array();
        foreach ( wpbb_child_v137_proof_cards() as $card ) {
            $titles[] = (string) $card['title'];
            $texts[]  = (string) $card['text'];
        }
        $content = wpbb_child_v137_replace_sequence( $content, 'Card title', $titles );
        $content = wpbb_child_v137_replace_sequence( $content, 'Add a short description.', $texts );
        return $content;
    }
}

/* Repair BBuilder icon-card defaults before render. */
if ( ! function_exists( 'wpbb_child_v137_render_block_data' ) ) {
    function wpbb_child_v137_render_block_data( $parsed_block ) {
        if ( is_admin() || empty( $parsed_block['attrs'] ) || ! is_array( $parsed_block['attrs'] ) ) return $parsed_block;

        $title = isset( $parsed_block['attrs']['title'] ) ? trim( (string) $parsed_block['attrs']['title'] ) : '';
        $text  = isset( $parsed_block['attrs']['text'] ) ? trim( (string) $parsed_block['attrs']['text'] ) : '';
        if ( 'Card title' !== $title && 'Add a short description.' !== $text ) return $parsed_block;

        static $index = 0;
        $cards = wpbb_child_v137_proof_cards();
        $card  = $cards[ $index % count( $cards ) ];
        if ( 'Card title' === $title ) $parsed_block['attrs']['title'] = $card['title'];
        if ( 'Add a short description.' === $text ) $parsed_block['attrs']['text'] = $card['text'];
        $parsed_block['attrs']['className'] = trim( (string) ( $parsed_block['attrs']['className'] ?? '' ) . ' wpbb-v137-sector-proof-card' );
        $index++;
        return $parsed_block;
    }
}
add_filter( 'render_block_data', 'wpbb_child_v137_render_block_data', 10000 );

if ( ! function_exists( 'wpbb_child_v137_mark_rendered_card' ) ) {
    function wpbb_child_v137_mark_rendered_card( $html ) {
        if ( false !== strpos( $html, 'wpbb-v137-sector-proof-card' ) ) return $html;
        if ( preg_match( '/\bclass=("|\')/i', $html ) ) {
            return preg_replace( '/\bclass=("|\')/i', 'class=$1wpbb-v137-sector-proof-card ', $html, 1 );
        }
        return preg_replace( '/<([a-z][a-z0-9:-]*)(\s|>)/i', '<$1 class="wpbb-v137-sector-proof-card"$2', $html, 1 );
    }
}

if ( ! function_exists( 'wpbb_child_v137_render_block' ) ) {
    function wpbb_child_v137_render_block( $block_content, $block ) {
        if ( is_admin() || ! is_string( $block_content ) || '' === $block_content ) return $block_content;
        $has_title = false !== strpos( $block_content, 'Card title' );
        $has_text  = false !== strpos( $block_content, 'Add a short description.' );
        if ( ! $has_title && ! $has_text ) return $block_content;

        static $index = 0;
        $cards = wpbb_child_v137_proof_cards();
        $card  = $cards[ $index % count( $cards ) ];
        if ( $has_title ) $block_content = str_replace( 'Card title', esc_html( $card['title'] ), $block_content );
        if ( $has_text ) $block_content = str_replace( 'Add a short description.', esc_html( $card['text'] ), $block_content );

        $name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
        if ( 'wpbb/icon-card' === $name || ( $has_title && $has_text ) ) {
            $block_content = wpbb_child_v137_mark_rendered_card( $block_content );
            $index++;
        }
        return $block_content;
    }
}
add_filter( 'render_block', 'wpbb_child_v137_render_block', 10000, 2 );

if ( ! function_exists( 'wpbb_child_v137_rendered_content' ) ) {
    function wpbb_child_v137_rendered_content( $content ) {
        if ( is_admin() ) return $content;
        return wpbb_child_v137_repair_placeholder_string( $content );
    }
}
add_filter( 'the_content', 'wpbb_child_v137_rendered_content', 10000 );

/* Persist corrected proof copy into the managed front page after upgrade/import. */
if ( ! function_exists( 'wpbb_child_v137_repair_managed_front_page' ) ) {
    function wpbb_child_v137_repair_managed_front_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $front = absint( get_option( 'page_on_front' ) );
        if ( ! $front ) return;
        $raw = (string) get_post_field( 'post_content', $front, 'raw' );
        if ( false === strpos( $raw, 'Card title' ) && false === strpos( $raw, 'Add a short description.' ) ) return;
        $fixed = wpbb_child_v137_repair_placeholder_string( $raw );
        if ( $fixed === $raw ) return;
        wp_update_post( wp_slash( array( 'ID' => $front, 'post_content' => $fixed ) ) );
        update_post_meta( $front, '_wpbb_child_v137_automotive_copy', '3.8.11.37' );
        clean_post_cache( $front );
    }
}
add_action( 'admin_init', 'wpbb_child_v137_repair_managed_front_page', 1000 );
add_action( 'wp_theme_after_demo_import', 'wpbb_child_v137_repair_managed_front_page', 1300 );
