<?php
/**
 * v3.8.11.29 Automotive targeted live-page repair.
 *
 * Keeps v128 commerce/hero ownership intact and fixes only the remaining
 * imported-homepage regressions: #wpbb-row-31, process badges and the product
 * catalogue host grid.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v129_enqueue' ) ) {
    function wpbb_child_v129_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $slug = basename( $dir );
        if ( false === strpos( $slug, 'automotive' ) ) {
            return;
        }

        $css = '/assets/suite-v129.css';
        $js  = '/assets/suite-v129.js';

        wp_enqueue_style(
            'wpbb-suite-v129',
            $uri . $css,
            array( 'wpbb-suite-v128' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.29'
        );
        wp_enqueue_script(
            'wpbb-suite-v129',
            $uri . $js,
            array( 'wpbb-suite-v128' ),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.29',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v129',
            'window.wpbbSuiteV129=' . wp_json_encode( array(
                'themeSlug' => $slug,
                'version'   => '3.8.11.29',
            ) ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v129_enqueue', PHP_INT_MAX );
