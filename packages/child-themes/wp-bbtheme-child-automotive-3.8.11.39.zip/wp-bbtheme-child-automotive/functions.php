<?php
defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/inc/frontend-password-protection.php';

function wpbb_automotive_project_mode( $mode ) { return 'woocommerce'; }
add_filter( 'wp_theme_project_mode', 'wpbb_automotive_project_mode' );

function wpbb_automotive_assets() {
    $theme = wp_get_theme();
    $manifest = get_stylesheet_directory() . '/dist/.vite/manifest.json';
    if ( ! is_readable( $manifest ) ) return;
    $data = json_decode( (string) file_get_contents( $manifest ), true );
    if ( ! is_array( $data ) ) return;
    if ( ! empty( $data['src/scss/public.scss']['file'] ) ) {
        wp_enqueue_style( 'wpbb-automotive-app', get_stylesheet_directory_uri() . '/dist/' . ltrim( $data['src/scss/public.scss']['file'], '/' ), array(), $theme->get( 'Version' ) );
        if ( function_exists( 'wp_theme_sector_customizer_css' ) ) wp_add_inline_style( 'wpbb-automotive-app', wp_theme_sector_customizer_css( '#C63D2F', '18px', '--sector-primary', '--sector-radius' ) );
    }
    if ( ! empty( $data['src/js/main.js']['file'] ) ) wp_enqueue_script( 'wpbb-automotive-app', get_stylesheet_directory_uri() . '/dist/' . ltrim( $data['src/js/main.js']['file'], '/' ), array(), $theme->get( 'Version' ), true );
}
add_action( 'wp_enqueue_scripts', 'wpbb_automotive_assets', 30 );

function wpbb_automotive_dark_mode_bootstrap() { echo '<script>(function(){try{var m=localStorage.getItem("wpThemeMode");if(m==="dark"){document.documentElement.classList.add("is-dark-theme");document.documentElement.setAttribute("data-theme","dark");}}catch(e){}})();</script>'; }
add_action( 'wp_head', 'wpbb_automotive_dark_mode_bootstrap', 1 );


function wpbb_automotive_demo_profile( $profile ) {
    $assets = trailingslashit( get_stylesheet_directory_uri() ) . 'assets/img/demo/';
    return array_merge( $profile, array(
        'id'=>'automotive', 'name'=>__( 'Automotive Dealer & Parts', 'wp-bbtheme-child-automotive' ), 'commerce'=>true,
        'eyebrow'=>__( 'Cars, parts and workshop support', 'wp-bbtheme-child-automotive' ), 'hero_title'=>__( 'Find the car, part or service without the dealership clutter.', 'wp-bbtheme-child-automotive' ), 'hero_text'=>__( 'Search new, used and rental vehicles, shop parts with WooCommerce and keep workshop enquiries in the same automotive website.', 'wp-bbtheme-child-automotive' ),
        'hero_image'=>$assets . 'hero.jpg', 'about_image'=>$assets . 'about.jpg',
        'primary_label'=>__( 'Find a vehicle', 'wp-bbtheme-child-automotive' ), 'primary_url'=>'#finder',
        'secondary_label'=>__( 'Explore services', 'wp-bbtheme-child-automotive' ), 'secondary_url'=>wp_theme_demo_page_url( 'services' ),
        'services_eyebrow'=>__( 'What we do', 'wp-bbtheme-child-automotive' ), 'services_heading'=>__( 'Sales, rentals, parts and workshop services in one clear system.', 'wp-bbtheme-child-automotive' ),
        'about_eyebrow'=>__( 'Why choose us', 'wp-bbtheme-child-automotive' ), 'about_title'=>__( 'A practical automotive site for the whole ownership journey.', 'wp-bbtheme-child-automotive' ), 'about_text'=>__( 'Vehicles use a dedicated searchable catalogue, parts use WooCommerce, and service or rental enquiries stay connected to the same customer experience.', 'wp-bbtheme-child-automotive' ),
        'industries_eyebrow'=>__( 'Built around your needs', 'wp-bbtheme-child-automotive' ), 'industries_heading'=>__( 'New cars, used stock, rentals, parts and service without separate websites.', 'wp-bbtheme-child-automotive' ),
        'process_eyebrow'=>__( 'How it works', 'wp-bbtheme-child-automotive' ), 'process_heading'=>__( 'Search stock, compare the facts and choose the next useful action.', 'wp-bbtheme-child-automotive' ), 'faq_heading'=>__( 'Buying, renting, servicing and parts questions answered early.', 'wp-bbtheme-child-automotive' ),
        'services'=>array(array( __( 'Vehicle sales', 'wp-bbtheme-child-automotive' ), __( 'Present new and used vehicles with the specifications people compare.', 'wp-bbtheme-child-automotive' ) ),
array( __( 'Car rental', 'wp-bbtheme-child-automotive' ), __( 'Show rental-ready stock and daily rates alongside purchase listings.', 'wp-bbtheme-child-automotive' ) ),
array( __( 'Workshop service', 'wp-bbtheme-child-automotive' ), __( 'Create clear servicing, diagnostic and repair journeys.', 'wp-bbtheme-child-automotive' ) ),
array( __( 'Parts store', 'wp-bbtheme-child-automotive' ), __( 'Sell service parts and accessories through WooCommerce.', 'wp-bbtheme-child-automotive' ) )), 'industries'=>array(array( __( 'New vehicles', 'wp-bbtheme-child-automotive' ), __( 'Manufacturer-style detail with dealer enquiry actions.', 'wp-bbtheme-child-automotive' ) ),
array( __( 'Used cars', 'wp-bbtheme-child-automotive' ), __( 'Mileage, year, history and pricing surfaced clearly.', 'wp-bbtheme-child-automotive' ) ),
array( __( 'Rentals', 'wp-bbtheme-child-automotive' ), __( 'Daily pricing and vehicle type filters for short-term needs.', 'wp-bbtheme-child-automotive' ) ),
array( __( 'Workshop & parts', 'wp-bbtheme-child-automotive' ), __( 'Keep maintenance and parts shopping close to vehicle ownership.', 'wp-bbtheme-child-automotive' ) )), 'stats'=>array(array( '12', __( 'Vehicles available', 'wp-bbtheme-child-automotive' ) ),
array( '10', __( 'Parts categories', 'wp-bbtheme-child-automotive' ) ),
array( '3', __( 'Stock types', 'wp-bbtheme-child-automotive' ) ),
array( '1', __( 'Unified account', 'wp-bbtheme-child-automotive' ) )), 'process'=>array(array( '01', __( 'Search', 'wp-bbtheme-child-automotive' ), __( 'Filter by condition, make, fuel and budget.', 'wp-bbtheme-child-automotive' ) ),
array( '02', __( 'Compare', 'wp-bbtheme-child-automotive' ), __( 'Review year, mileage, gearbox and pricing.', 'wp-bbtheme-child-automotive' ) ),
array( '03', __( 'Act', 'wp-bbtheme-child-automotive' ), __( 'Enquire, arrange a test drive, request rental or shop parts.', 'wp-bbtheme-child-automotive' ) )),
        'cta_title'=>__( 'Make the next vehicle decision easier.', 'wp-bbtheme-child-automotive' ), 'cta_text'=>__( 'Use the vehicle finder, parts store and service content as a complete starting point for dealers, garages and rental businesses.', 'wp-bbtheme-child-automotive' ), 'footer_text'=>__( 'Vehicle sales, parts, rentals and workshop support in one connected automotive website.', 'wp-bbtheme-child-automotive' ),
        'page_labels'=>array('about'=>__( 'About', 'wp-bbtheme-child-automotive' ),'services'=>__( 'Services', 'wp-bbtheme-child-automotive' ),'industries'=>__( 'Solutions', 'wp-bbtheme-child-automotive' ),'contact'=>__( 'Contact', 'wp-bbtheme-child-automotive' ),'blog'=>__( 'Insights', 'wp-bbtheme-child-automotive' )),
        'palette'=>array('theme_brand_color'=>'#C63D2F','theme_accent_color'=>'#243447','theme_background_color'=>'#f7f8fb','theme_surface_color'=>'#ffffff','theme_border_color'=>'#dfe4ee','theme_radius'=>'22px')
    ) );
}
add_filter( 'wp_theme_demo_profile', 'wpbb_automotive_demo_profile', 20 );


function wpbb_automotive_pattern_markup( $name ) {
    $path = get_stylesheet_directory() . '/patterns/' . sanitize_file_name( $name ) . '.php';
    if ( ! is_readable( $path ) ) return '';
    ob_start(); include $path; return trim( (string) ob_get_clean() );
}

function wpbb_automotive_extra_home_sections( $content, $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'automotive' ) return $content;
    return $content . wpbb_automotive_pattern_markup( 'sector-proof' );
}
add_filter( 'wp_theme_demo_extra_home_sections', 'wpbb_automotive_extra_home_sections', 25, 2 );

function wpbb_automotive_blog_profile( $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'automotive' ) return $profile;
    $profile['blog_eyebrow'] = __( 'Insights', 'wp-bbtheme-child-automotive' );
    $profile['blog_archive_title'] = __( 'Car guides, workshop advice and ownership news.', 'wp-bbtheme-child-automotive' );
    $profile['blog_archive_intro'] = __( 'Useful advice for buying, maintaining and getting more from a vehicle.', 'wp-bbtheme-child-automotive' );
    return $profile;
}
add_filter( 'wp_theme_demo_profile', 'wpbb_automotive_blog_profile', 90 );


function wpbb_automotive_demo_attachment( $filename, $title ) {
    $slug   = sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) );
    $source = get_stylesheet_directory() . '/assets/img/demo/' . basename( $filename );
    if ( ! is_readable( $source ) ) return 0;

    $post_name = 'wpbb-automotive-' . $slug;
    $existing  = get_page_by_path( $post_name, OBJECT, 'attachment' );
    if ( $existing ) {
        $attached = get_attached_file( $existing->ID );
        if ( $attached && is_readable( $attached ) && filesize( $attached ) > 0 ) return (int) $existing->ID;
    }

    $uploads = wp_upload_dir();
    if ( ! empty( $uploads['error'] ) ) return 0;
    $dir = trailingslashit( $uploads['basedir'] ) . 'wpbb-automotive';
    wp_mkdir_p( $dir );
    $target = $dir . '/' . basename( $filename );
    if ( ! file_exists( $target ) && ! copy( $source, $target ) ) return 0;

    $filetype = wp_check_filetype( $target );
    if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';

    if ( $existing ) {
        $id = (int) $existing->ID;
        update_attached_file( $id, $target );
        wp_update_post( array(
            'ID'             => $id,
            'post_mime_type' => $filetype['type'] ?: 'image/jpeg',
            'post_title'     => $title,
            'post_name'      => $post_name,
            'guid'           => trailingslashit( $uploads['baseurl'] ) . 'wpbb-automotive/' . basename( $filename ),
        ) );
    } else {
        $id = wp_insert_attachment( array(
            'post_mime_type' => $filetype['type'] ?: 'image/jpeg',
            'post_title'     => $title,
            'post_name'      => $post_name,
            'post_status'    => 'inherit',
            'guid'           => trailingslashit( $uploads['baseurl'] ) . 'wpbb-automotive/' . basename( $filename ),
        ), $target );
        if ( is_wp_error( $id ) ) return 0;
    }

    $meta = wp_generate_attachment_metadata( $id, $target );
    if ( $meta ) wp_update_attachment_metadata( $id, $meta );
    update_post_meta( $id, '_wp_attachment_image_alt', $title );
    return (int) $id;
}

function wpbb_automotive_register_directory() {
    register_post_type( 'vehicle', array(
        'labels'=>array('name'=>__( 'Vehicles', 'wp-bbtheme-child-automotive' ),'singular_name'=>__( 'Vehicle', 'wp-bbtheme-child-automotive' ),'add_new_item'=>__( 'Add Vehicle', 'wp-bbtheme-child-automotive' )),
        'public'=>true,'show_in_rest'=>true,'has_archive'=>'vehicles','rewrite'=>array('slug'=>'vehicles'),'menu_icon'=>'dashicons-car','supports'=>array('title','editor','excerpt','thumbnail','page-attributes')
    ) );
    register_taxonomy( 'vehicle_make', 'vehicle', array( 'label'=>__( 'Makes', 'wp-bbtheme-child-automotive' ), 'public'=>true, 'show_in_rest'=>true, 'hierarchical'=>true, 'rewrite'=>array('slug'=>'vehicle-make') ) ); register_taxonomy( 'vehicle_type', 'vehicle', array( 'label'=>__( 'Vehicle types', 'wp-bbtheme-child-automotive' ), 'public'=>true, 'show_in_rest'=>true, 'hierarchical'=>true, 'rewrite'=>array('slug'=>'vehicle-type') ) );
}
add_action( 'init', 'wpbb_automotive_register_directory', 12 );

function wpbb_automotive_meta_fields() { return array('condition'=>__( 'Condition', 'wp-bbtheme-child-automotive' ),'price'=>__( 'Sale price', 'wp-bbtheme-child-automotive' ),'year'=>__( 'Year', 'wp-bbtheme-child-automotive' ),'mileage'=>__( 'Mileage', 'wp-bbtheme-child-automotive' ),'fuel'=>__( 'Fuel', 'wp-bbtheme-child-automotive' ),'gearbox'=>__( 'Gearbox', 'wp-bbtheme-child-automotive' ),'rental_day'=>__( 'Rental per day', 'wp-bbtheme-child-automotive' )); }
function wpbb_automotive_meta_box() { add_meta_box( 'wpbb-automotive-details', __( 'Vehicle details', 'wp-bbtheme-child-automotive' ), 'wpbb_automotive_meta_box_render', 'vehicle', 'normal', 'high' ); }
add_action( 'add_meta_boxes', 'wpbb_automotive_meta_box' );
function wpbb_automotive_meta_box_render( $post ) {
    wp_nonce_field( 'wpbb_automotive_save', 'wpbb_automotive_nonce' ); echo '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px">';
    foreach ( wpbb_automotive_meta_fields() as $key=>$label ) { $value=get_post_meta($post->ID,'_automotive_'.$key,true); echo '<label><strong>'.esc_html($label).'</strong><input class="widefat" type="text" name="wpbb_automotive['.esc_attr($key).']" value="'.esc_attr($value).'"></label>'; } echo '</div>';
}
function wpbb_automotive_save_meta( $post_id ) {
    if ( empty($_POST['wpbb_automotive_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wpbb_automotive_nonce'])),'wpbb_automotive_save') || !current_user_can('edit_post',$post_id) ) return;
    $values=isset($_POST['wpbb_automotive'])&&is_array($_POST['wpbb_automotive'])?wp_unslash($_POST['wpbb_automotive']):array(); foreach(wpbb_automotive_meta_fields() as $key=>$label) update_post_meta($post_id,'_automotive_'.$key,sanitize_text_field($values[$key]??''));
}
add_action( 'save_post_vehicle', 'wpbb_automotive_save_meta' );

function wpbb_automotive_directory_configs( $configs ) {
    $configs['automotive'] = array(
      'post_type'=>'vehicle','eyebrow'=>__( 'Vehicle finder', 'wp-bbtheme-child-automotive' ),'title'=>__( 'Search new, used and rental vehicles.', 'wp-bbtheme-child-automotive' ),'intro'=>__( 'Filter stock by condition, make, type, budget and fuel.', 'wp-bbtheme-child-automotive' ),'keyword_label'=>__( 'Search stock', 'wp-bbtheme-child-automotive' ),'keyword_placeholder'=>__( 'Model, body style or keyword', 'wp-bbtheme-child-automotive' ),'button_label'=>__( 'Find vehicles', 'wp-bbtheme-child-automotive' ),'results_label'=>__( 'vehicles matching your search', 'wp-bbtheme-child-automotive' ),'limit'=>8,'default_sort'=>'featured',
      'filters'=>array(array('type'=>'meta_select','key'=>'condition','label'=>__( 'Condition', 'wp-bbtheme-child-automotive' ),'meta_key'=>'_automotive_condition','all_label'=>'Any stock','options'=>array('new'=>__( 'New', 'wp-bbtheme-child-automotive' ),'used'=>__( 'Used', 'wp-bbtheme-child-automotive' ),'rent'=>__( 'Rental', 'wp-bbtheme-child-automotive' ))),array('type'=>'taxonomy','key'=>'make','label'=>__( 'Make', 'wp-bbtheme-child-automotive' ),'taxonomy'=>'vehicle_make','all_label'=>'Any make'),array('type'=>'meta_max','key'=>'max_price','label'=>__( 'Max price', 'wp-bbtheme-child-automotive' ),'meta_key'=>'_automotive_price','placeholder'=>'No max','step'=>500),array('type'=>'meta_select','key'=>'fuel','label'=>__( 'Fuel', 'wp-bbtheme-child-automotive' ),'meta_key'=>'_automotive_fuel','all_label'=>'Any fuel','options'=>array('Petrol'=>__( 'Petrol', 'wp-bbtheme-child-automotive' ),'Diesel'=>__( 'Diesel', 'wp-bbtheme-child-automotive' ),'Hybrid'=>__( 'Hybrid', 'wp-bbtheme-child-automotive' ),'Electric'=>__( 'Electric', 'wp-bbtheme-child-automotive' )))),'sorts'=>array('featured'=>array('label'=>__( 'Featured', 'wp-bbtheme-child-automotive' ),'orderby'=>'menu_order','order'=>'ASC'),'price-asc'=>array('label'=>__( 'Price: low to high', 'wp-bbtheme-child-automotive' ),'orderby'=>'meta_value_num','order'=>'ASC','meta_key'=>'_automotive_price'),'price-desc'=>array('label'=>__( 'Price: high to low', 'wp-bbtheme-child-automotive' ),'orderby'=>'meta_value_num','order'=>'DESC','meta_key'=>'_automotive_price'),'newest'=>array('label'=>__( 'Newest year', 'wp-bbtheme-child-automotive' ),'orderby'=>'meta_value_num','order'=>'DESC','meta_key'=>'_automotive_year')),'card_taxonomies'=>array('vehicle_make','vehicle_type'),'card_meta'=>array(array('key'=>'_automotive_price','label'=>__( 'Price', 'wp-bbtheme-child-automotive' ),'format'=>'money','currency'=>'£'),array('key'=>'_automotive_year','label'=>__( 'Year', 'wp-bbtheme-child-automotive' )),array('key'=>'_automotive_mileage','label'=>__( 'Mileage', 'wp-bbtheme-child-automotive' ),'suffix'=>' mi'),array('key'=>'_automotive_fuel','label'=>__( 'Fuel', 'wp-bbtheme-child-automotive' ))),'card_button'=>__( 'View vehicle', 'wp-bbtheme-child-automotive' )
    ); return $configs;
}
add_filter( 'wp_theme_sector_directory_configs', 'wpbb_automotive_directory_configs' );

function wpbb_automotive_seed_directory( $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'automotive' ) return;
    $rows=array(array('title'=>'Apex E-SUV 80','slug'=>'apex-e-suv-80','excerpt'=>'New electric family SUV with long-range battery and rapid charging.','content'=>'New electric family SUV with long-range battery and rapid charging.','terms'=>array('vehicle_make'=>'Apex','vehicle_type'=>'SUV'),'meta'=>array('condition'=>'new','price'=>'48990','year'=>'2026','mileage'=>'12','fuel'=>'Electric','gearbox'=>'Automatic','rental_day'=>''),'image'=>'item-1.jpg'),array('title'=>'Volterra Touring 2.0','slug'=>'volterra-touring','excerpt'=>'Well-kept used estate with strong motorway comfort and service history.','content'=>'Well-kept used estate with strong motorway comfort and service history.','terms'=>array('vehicle_make'=>'Volterra','vehicle_type'=>'Estate'),'meta'=>array('condition'=>'used','price'=>'18950','year'=>'2022','mileage'=>'31800','fuel'=>'Diesel','gearbox'=>'Automatic','rental_day'=>''),'image'=>'item-2.jpg'),array('title'=>'Civicline Hybrid','slug'=>'civicline-hybrid','excerpt'=>'Efficient hybrid hatchback for town driving and longer trips.','content'=>'Efficient hybrid hatchback for town driving and longer trips.','terms'=>array('vehicle_make'=>'Civicline','vehicle_type'=>'Hatchback'),'meta'=>array('condition'=>'used','price'=>'16450','year'=>'2023','mileage'=>'22400','fuel'=>'Hybrid','gearbox'=>'Automatic','rental_day'=>''),'image'=>'item-3.jpg'),array('title'=>'Apex City EV Rental','slug'=>'apex-city-ev-rental','excerpt'=>'Compact electric rental car with simple daily pricing.','content'=>'Compact electric rental car with simple daily pricing.','terms'=>array('vehicle_make'=>'Apex','vehicle_type'=>'Hatchback'),'meta'=>array('condition'=>'rent','price'=>'0','year'=>'2026','mileage'=>'4500','fuel'=>'Electric','gearbox'=>'Automatic','rental_day'=>'59'),'image'=>'item-4.jpg'),array('title'=>'Northline Van Rental','slug'=>'northline-van-rental','excerpt'=>'Practical medium van for moving, trade work and short contracts.','content'=>'Practical medium van for moving, trade work and short contracts.','terms'=>array('vehicle_make'=>'Northline','vehicle_type'=>'Van'),'meta'=>array('condition'=>'rent','price'=>'0','year'=>'2025','mileage'=>'9800','fuel'=>'Diesel','gearbox'=>'Manual','rental_day'=>'79'),'image'=>'item-5.jpg'),array('title'=>'Granvia Sport Coupe','slug'=>'granvia-sport-coupe','excerpt'=>'Low-mileage petrol coupe with a focused driver specification.','content'=>'Low-mileage petrol coupe with a focused driver specification.','terms'=>array('vehicle_make'=>'Granvia','vehicle_type'=>'Coupe'),'meta'=>array('condition'=>'used','price'=>'27900','year'=>'2024','mileage'=>'11200','fuel'=>'Petrol','gearbox'=>'Automatic','rental_day'=>''),'image'=>'item-6.jpg'));
    foreach($rows as $i=>$row){
      foreach($row['terms'] as $tax=>$term) if(taxonomy_exists($tax)&&!term_exists($term,$tax)) wp_insert_term($term,$tax);
      $existing=get_page_by_path($row['slug'],OBJECT,'vehicle'); $args=array('post_type'=>'vehicle','post_status'=>'publish','post_title'=>$row['title'],'post_name'=>$row['slug'],'menu_order'=>$i,'post_excerpt'=>$row['excerpt'],'post_content'=>'<!-- wp:paragraph --><p>'.esc_html($row['content']).'</p><!-- /wp:paragraph -->');
      if($existing){$args['ID']=$existing->ID;$id=wp_update_post($args);}else{$id=wp_insert_post($args);} if(!$id||is_wp_error($id))continue;
      foreach($row['terms'] as $tax=>$term)wp_set_object_terms($id,$term,$tax); foreach($row['meta'] as $key=>$value)update_post_meta($id,'_automotive_'.$key,$value); $img=wpbb_automotive_demo_attachment($row['image'],$row['title']); if($img)set_post_thumbnail($id,$img); update_post_meta($id,'_wp_theme_demo_vehicle',1);
    }
}
add_action( 'wp_theme_seed_sector_pages', 'wpbb_automotive_seed_directory', 25 );

function wpbb_automotive_after_hero_finder( $content, $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'automotive' ) return $content;
    return $content . '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wpbb-automotive-finder-section","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container"} --><!-- wp:wpbb/column {"xs":12} --><!-- wp:wpbb/sector-finder {"context":"automotive","limit":8} /--><!-- /wp:wpbb/column --><!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';
}
add_filter( 'wp_theme_demo_after_hero_sections', 'wpbb_automotive_after_hero_finder', 20, 2 );

function wpbb_automotive_navigation( $items, $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'automotive' ) return $items;
    array_splice( $items, 1, 0, array( array('key'=>'vehicle','title'=>__( 'Vehicles', 'wp-bbtheme-child-automotive' ),'type'=>'post_type_archive','object'=>'vehicle','locations'=>array('header','footer')) ) ); return $items;
}
add_filter( 'wp_theme_demo_navigation_items', 'wpbb_automotive_navigation', 20, 2 );

function wpbb_automotive_header_search_types( $types ) { if(post_type_exists('vehicle'))$types[]='vehicle'; return array_values(array_unique($types)); }
add_filter( 'wp_theme_header_search_post_types', 'wpbb_automotive_header_search_types' );

function wpbb_automotive_single_content( $content ) {
    if ( !is_singular('vehicle') || !in_the_loop() || !is_main_query() ) return $content; $content=wpbb_child_381043_dedupe_single_body($content,get_the_excerpt()); $id=get_the_ID(); $image=get_the_post_thumbnail_url($id,'large'); $gallery = function_exists( 'wpbb_child_381045_gallery_single_markup' ) ? wpbb_child_381045_gallery_single_markup( $id ) : ''; if ( ! $gallery && function_exists( 'wp_theme_item_gallery_single_markup' ) ) $gallery = wp_theme_item_gallery_single_markup( $id );
    $facts=''; foreach(wpbb_automotive_meta_fields() as $key=>$label){$value=get_post_meta($id,'_automotive_'.$key,true);if(''!==trim((string)$value))$facts.='<div><small>'.esc_html($label).'</small><strong>'.esc_html($value).'</strong></div>';}
    $html='<section class="wpbb-sector-single"><div class="container"><div class="wpbb-sector-single__hero"><div class="wpbb-sector-single__media">'.($gallery?:($image?'<img src="'.esc_url($image).'" alt="'.esc_attr(get_the_title()).'">':'')).'</div><div><p class="wp-theme-sector-eyebrow">'.esc_html('Vehicle').'</p><h1>'.esc_html(get_the_title()).'</h1><p class="wp-theme-sector-lead">'.esc_html(get_the_excerpt()).'</p><div class="wpbb-sector-single__facts">'.$facts.'</div></div></div><div class="wpbb-sector-single__content">'.$content.'</div>';
    if(function_exists('wpbb_automotive_request_form'))$html.=wpbb_automotive_request_form($id); return $html.'</div></section>';
}
add_filter( 'the_content', 'wpbb_automotive_single_content', 25 );

function wpbb_automotive_polylang_post_types( $types, $settings ) { $types['vehicle']='vehicle'; return $types; }
add_filter( 'pll_get_post_types', 'wpbb_automotive_polylang_post_types', 10, 2 );
function wpbb_automotive_pll_vehicle_make( $tax, $settings ) { $tax['vehicle_make']='vehicle_make'; return $tax; }
add_filter( 'pll_get_taxonomies', 'wpbb_automotive_pll_vehicle_make', 10, 2 );
function wpbb_automotive_pll_vehicle_type( $tax, $settings ) { $tax['vehicle_type']='vehicle_type'; return $tax; }
add_filter( 'pll_get_taxonomies', 'wpbb_automotive_pll_vehicle_type', 10, 2 );

function wpbb_automotive_register_requests() { register_post_type('vehicle_enquiry',array('labels'=>array('name'=>__( 'Vehicle Enquiries', 'wp-bbtheme-child-automotive' ),'singular_name'=>__( 'Vehicle Enquiry', 'wp-bbtheme-child-automotive' )),'public'=>false,'show_ui'=>true,'show_in_menu'=>'edit.php?post_type=vehicle','supports'=>array('title'))); }
add_action('init','wpbb_automotive_register_requests',14);
function wpbb_automotive_request_form( $object_id ) {
    $success=isset($_GET['request'])&&'received'===sanitize_key(wp_unslash($_GET['request'])); ob_start(); ?>
    <div class="wpbb-sector-request" id="request"><p class="wp-theme-sector-eyebrow"><?php echo esc_html(__( 'Vehicle enquiry', 'wp-bbtheme-child-automotive' )); ?></p><h2><?php echo esc_html(__( 'Tell the team what you would like to do next.', 'wp-bbtheme-child-automotive' )); ?></h2><?php if($success):?><div class="alert alert-success"><?php echo esc_html(__( 'Thanks. Your vehicle enquiry has been received.', 'wp-bbtheme-child-automotive' )); ?></div><?php endif;?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="wpbb_automotive_submit_request"><input type="hidden" name="object_id" value="<?php echo esc_attr($object_id); ?>"><?php wp_nonce_field('wpbb_automotive_request_'.$object_id,'wpbb_automotive_request_nonce'); ?>
      <?php echo '<label class=""><span>'.esc_html(__( 'Name', 'wp-bbtheme-child-automotive' )).'</span><input type="text" name="name" required></label>' . '<label class=""><span>'.esc_html(__( 'Email', 'wp-bbtheme-child-automotive' )).'</span><input type="email" name="email" required></label>' . '<label class=""><span>'.esc_html(__( 'Phone', 'wp-bbtheme-child-automotive' )).'</span><input type="tel" name="phone"></label>' . '<label class=""><span>'.esc_html(__( 'I want to', 'wp-bbtheme-child-automotive' )).'</span><select name="intent" required><option value="buy">Buy / finance</option><option value="test-drive">Book a test drive</option><option value="rent">Rent this vehicle</option><option value="part-exchange">Discuss part exchange</option></select></label>' . '<label class="is-wide"><span>'.esc_html(__( 'Message', 'wp-bbtheme-child-automotive' )).'</span><textarea name="message" rows="5"></textarea></label>'; ?><button class="btn btn-primary" type="submit"><?php echo esc_html(__( 'Send vehicle enquiry', 'wp-bbtheme-child-automotive' )); ?></button>
    </form></div><?php return ob_get_clean();
}
function wpbb_automotive_submit_request() {
    $object_id=absint($_POST['object_id']??0); if(!$object_id||'vehicle'!==get_post_type($object_id))wp_die(esc_html(__( 'Invalid request.', 'wp-bbtheme-child-automotive' ))); if(empty($_POST['wpbb_automotive_request_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wpbb_automotive_request_nonce'])),'wpbb_automotive_request_'.$object_id))wp_die(esc_html(__( 'The form expired. Please try again.', 'wp-bbtheme-child-automotive' )));
    $name=sanitize_text_field(wp_unslash($_POST['name']??'')); $email=sanitize_email(wp_unslash($_POST['email']??'')); $phone=sanitize_text_field(wp_unslash($_POST['phone']??'')); $intent=sanitize_text_field(wp_unslash($_POST['intent']??'')); $message=sanitize_textarea_field(wp_unslash($_POST['message']??'')); if('' === (string) $name || ! is_email( $email ) || '' === (string) $intent)wp_die(esc_html(__( 'Please complete the required fields.', 'wp-bbtheme-child-automotive' )));
    $request_id=wp_insert_post(array('post_type'=>'vehicle_enquiry','post_status'=>'publish','post_title'=>sprintf('%s — %s',get_the_title($object_id),isset($name)?$name:current_time('mysql')))); if($request_id&&!is_wp_error($request_id)){foreach(array('object_id'=>$object_id,'name'=>$name,'email'=>$email,'phone'=>$phone,'intent'=>$intent,'message'=>$message,'status'=>'new') as $key=>$value)update_post_meta($request_id,'_automotive_request_'.$key,$value);}
    wp_safe_redirect(add_query_arg('request','received',get_permalink($object_id)).'#request'); exit;
}
add_action('admin_post_wpbb_automotive_submit_request','wpbb_automotive_submit_request'); add_action('admin_post_nopriv_wpbb_automotive_submit_request','wpbb_automotive_submit_request');

function wpbb_automotive_mega_menu( $definitions, $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'automotive' ) return $definitions; $archive=get_post_type_archive_link('vehicle')?:home_url('/vehicles/');
    $definitions['vehicle']=array('title'=>__( 'Vehicles navigation', 'wp-bbtheme-child-automotive' ),'target_key'=>'vehicle','eyebrow'=>__( 'Vehicles', 'wp-bbtheme-child-automotive' ),'heading'=>__( 'Find the right vehicle faster.', 'wp-bbtheme-child-automotive' ),'intro'=>__( 'Browse current new, used and rental stock, then move to parts or service.', 'wp-bbtheme-child-automotive' ),'columns'=>array(
      array('title'=>__( 'Explore', 'wp-bbtheme-child-automotive' ),'links'=>array(array(__( 'Vehicles', 'wp-bbtheme-child-automotive' ),__( 'Filter stock by condition, make, type, budget and fuel.', 'wp-bbtheme-child-automotive' ),$archive),array(__( 'Services', 'wp-bbtheme-child-automotive' ),__( 'Sales, rentals, parts and workshop services in one clear system.', 'wp-bbtheme-child-automotive' ),wp_theme_demo_page_url('services')),array(__( 'Solutions', 'wp-bbtheme-child-automotive' ),__( 'New cars, used stock, rentals, parts and service without separate websites.', 'wp-bbtheme-child-automotive' ),wp_theme_demo_page_url('industries')))),
      array('title'=>__( 'Plan', 'wp-bbtheme-child-automotive' ),'links'=>array(array(__( 'How it works', 'wp-bbtheme-child-automotive' ),__( 'Search stock, compare the facts and choose the next useful action.', 'wp-bbtheme-child-automotive' ),wp_theme_demo_page_url('services')),array(__( 'About', 'wp-bbtheme-child-automotive' ),__( 'Vehicles use a dedicated searchable catalogue, parts use WooCommerce, and service or rental enquiries stay connected to the same customer experience.', 'wp-bbtheme-child-automotive' ),wp_theme_demo_page_url('about')),array(__( 'Contact', 'wp-bbtheme-child-automotive' ),__( 'Talk to the team about the next step.', 'wp-bbtheme-child-automotive' ),wp_theme_demo_page_url('contact')))),
      array('title'=>__( 'Useful', 'wp-bbtheme-child-automotive' ),'links'=>array(array(__( 'Insights', 'wp-bbtheme-child-automotive' ),__( 'Useful advice for buying, maintaining and getting more from a vehicle.', 'wp-bbtheme-child-automotive' ),get_permalink(get_option('page_for_posts'))?:home_url('/blog/')),array(__( 'Search', 'wp-bbtheme-child-automotive' ),__( 'Use the live finder to narrow the catalogue.', 'wp-bbtheme-child-automotive' ),$archive),array(__( 'Enquire', 'wp-bbtheme-child-automotive' ),__( 'Send the details needed for a useful response.', 'wp-bbtheme-child-automotive' ),wp_theme_demo_page_url('contact'))))
    )); return $definitions;
}
add_filter('wp_theme_demo_mega_menu_definitions','wpbb_automotive_mega_menu',20,2);

function wpbb_automotive_woo_profile( $profile ) { return 'store'; } add_filter('wp_theme_woo_support_default_profile','wpbb_automotive_woo_profile');
function wpbb_automotive_demo_products( $products ) { return array(array('simple','Premium Oil Filter','Service Parts',18,'High-quality replacement filter for routine servicing.'),
array('simple','Front Brake Pad Set','Brakes',64,'Low-noise front brake pads for compatible passenger cars.'),
array('simple','Wiper Blade Pair','Maintenance',24,'All-season replacement wiper blade set.'),
array('simple','12V Smart Battery Charger','Garage Tools',79,'Automatic charger and maintainer for cars and vans.'),
array('simple','All-Weather Floor Mats','Accessories',55,'Durable easy-clean floor mat set.'),
array('simple','LED Workshop Inspection Lamp','Garage Tools',39,'Rechargeable inspection light for workshop and roadside use.'),
array('simple','Cabin Air Filter','Service Parts',22,'Fresh-air cabin filter replacement.'),
array('simple','Wheel Locking Bolt Set','Accessories',32,'Secure wheel locking bolt kit.'),
array('simple','Emergency Travel Kit','Accessories',49,'Core roadside and travel essentials in one compact bag.'),
array('simple','Synthetic Engine Oil 5L','Service Parts',46,'Fully synthetic engine oil for compatible petrol and diesel vehicles.')); } add_filter('wp_theme_woo_demo_product_data','wpbb_automotive_demo_products');
function wpbb_automotive_demo_product_image( $path,$product,$index ) { $images=array('product-1.jpg','product-2.jpg','product-3.jpg','product-4.jpg','product-5.jpg','product-6.jpg','product-7.jpg','product-8.jpg','product-9.jpg','product-10.jpg'); return isset($images[$index])?get_stylesheet_directory().'/assets/img/demo/'.$images[$index]:$path; } add_filter('wp_theme_woo_demo_product_image_path','wpbb_automotive_demo_product_image',10,3);
function wpbb_automotive_woocommerce_support() { add_theme_support('woocommerce');add_theme_support('wc-product-gallery-zoom');add_theme_support('wc-product-gallery-lightbox');add_theme_support('wc-product-gallery-slider'); } add_action('after_setup_theme','wpbb_automotive_woocommerce_support',30);
function wpbb_automotive_woocommerce_legacy_template( $template ) {
 if(is_admin()||!function_exists('WC')||wp_doing_ajax()||is_feed())return $template;$base=trailingslashit(get_stylesheet_directory()).'woocommerce-legacy/';$candidate='';
 if(function_exists('is_cart')&&is_cart())$candidate='cart.php';elseif(function_exists('is_checkout')&&is_checkout())$candidate='checkout.php';elseif(function_exists('is_account_page')&&is_account_page())$candidate='account.php';elseif(function_exists('is_product')&&is_product())$candidate='product.php';elseif((function_exists('is_shop')&&is_shop())||(function_exists('is_product_taxonomy')&&is_product_taxonomy()))$candidate='catalog.php'; if($candidate&&is_readable($base.$candidate))return $base.$candidate;return $template;
} add_filter('template_include','wpbb_automotive_woocommerce_legacy_template',99);
function wpbb_automotive_woo_body_class($classes){if(function_exists('is_woocommerce')&&(is_woocommerce()||is_cart()||is_checkout()||is_account_page()))$classes[]='wp-theme-uses-woo-legacy-shell';return $classes;} add_filter('body_class','wpbb_automotive_woo_body_class');

function wpbb_automotive_register_service_requests(){register_post_type('vehicle_service_request',array('labels'=>array('name'=>__( 'Service Requests', 'wp-bbtheme-child-automotive' ),'singular_name'=>__( 'Service Request', 'wp-bbtheme-child-automotive' )),'public'=>false,'show_ui'=>true,'show_in_menu'=>'edit.php?post_type=vehicle','supports'=>array('title')));}add_action('init','wpbb_automotive_register_service_requests',14);
function wpbb_automotive_service_form(){ $success=isset($_GET['service'])&&'received'===sanitize_key(wp_unslash($_GET['service']));ob_start();?><div class="container wpbb-automotive-service-shell"><section class="wpbb-sector-request" id="service-request"><p class="wp-theme-sector-eyebrow"><?php echo esc_html(__( 'Workshop booking', 'wp-bbtheme-child-automotive' ));?></p><h2><?php echo esc_html(__( 'Request a service or repair appointment.', 'wp-bbtheme-child-automotive' ));?></h2><?php if($success):?><div class="alert alert-success"><?php echo esc_html(__( 'Thanks. Your workshop request has been received.', 'wp-bbtheme-child-automotive' ));?></div><?php endif;?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="wpbb_automotive_service_request"><?php wp_nonce_field('wpbb_automotive_service','wpbb_automotive_service_nonce');?><label><span><?php echo esc_html(__( 'Name', 'wp-bbtheme-child-automotive' ));?></span><input name="name" required></label><label><span><?php echo esc_html(__( 'Email', 'wp-bbtheme-child-automotive' ));?></span><input type="email" name="email" required></label><label><span><?php echo esc_html(__( 'Registration', 'wp-bbtheme-child-automotive' ));?></span><input name="registration"></label><label><span><?php echo esc_html(__( 'Service type', 'wp-bbtheme-child-automotive' ));?></span><select name="service_type"><option>Routine service</option><option>Diagnostics</option><option>Brakes</option><option>Tyres</option><option>Repair</option></select></label><label class="is-wide"><span><?php echo esc_html(__( 'What does the workshop need to know?', 'wp-bbtheme-child-automotive' ));?></span><textarea name="message"></textarea></label><button class="btn btn-primary" type="submit"><?php echo esc_html(__( 'Request workshop appointment', 'wp-bbtheme-child-automotive' ));?></button></form></section></div><?php return ob_get_clean();}
function wpbb_automotive_append_service_form($content){if(!is_page('services')||!in_the_loop()||!is_main_query())return$content;return$content.wpbb_automotive_service_form();}add_filter('the_content','wpbb_automotive_append_service_form',30);
function wpbb_automotive_service_submit(){if(empty($_POST['wpbb_automotive_service_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wpbb_automotive_service_nonce'])),'wpbb_automotive_service'))wp_die('Expired form.');$name=sanitize_text_field(wp_unslash($_POST['name']??''));$email=sanitize_email(wp_unslash($_POST['email']??''));if(!$name||!is_email($email))wp_die('Required fields missing.');$id=wp_insert_post(array('post_type'=>'vehicle_service_request','post_status'=>'publish','post_title'=>'Workshop — '.$name));if($id&&!is_wp_error($id))foreach(array('name'=>$name,'email'=>$email,'registration'=>sanitize_text_field(wp_unslash($_POST['registration']??'')),'service_type'=>sanitize_text_field(wp_unslash($_POST['service_type']??'')),'message'=>sanitize_textarea_field(wp_unslash($_POST['message']??'')))as$key=>$value)update_post_meta($id,'_automotive_service_'.$key,$value);wp_safe_redirect(add_query_arg('service','received',wp_theme_demo_page_url('services')).'#service-request');exit;}add_action('admin_post_wpbb_automotive_service_request','wpbb_automotive_service_submit');add_action('admin_post_nopriv_wpbb_automotive_service_request','wpbb_automotive_service_submit');


/** v3.8.10.7: ensure every demo parts product has useful single-product content. */
function wpbb_automotive_seed_product_content_v107( $page_id = 0, $profile = array() ) {
    if ( ! post_type_exists( 'product' ) ) return;
    $ids = get_posts(array('post_type'=>'product','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids'));
    foreach ( $ids as $id ) {
        if ( trim( wp_strip_all_tags( (string) get_post_field('post_content',$id) ) ) ) continue;
        $title=get_the_title($id);
        $content='<h2>Product details</h2><p>'.esc_html($title).' is included in the automotive starter catalogue with clear pricing, compatibility guidance and a straightforward purchase or quote route.</p><h2>Before ordering</h2><p>Check fitment, vehicle compatibility and installation requirements with the workshop team when needed.</p>';
        wp_update_post(array('ID'=>$id,'post_content'=>$content));
    }
}
add_action('wp_theme_after_demo_import','wpbb_automotive_seed_product_content_v107',45,2);

/**
 * v3.8.10.20: keep editable Mega Menu content out of public discovery / SEO.
 * The parent already registers these objects as private; child filters make the
 * intent explicit for Core XML sitemaps and common SEO plugins too.
 */
function wpbb_child_private_megamenu_post_type_args( $args, $post_type ) {
    if ( 'megamenu' !== $post_type ) return $args;
    $args['public'] = false;
    $args['publicly_queryable'] = false;
    $args['exclude_from_search'] = true;
    $args['has_archive'] = false;
    $args['rewrite'] = false;
    $args['query_var'] = false;
    return $args;
}
add_filter( 'register_post_type_args', 'wpbb_child_private_megamenu_post_type_args', 20, 2 );

function wpbb_child_private_megamenu_taxonomy_args( $args, $taxonomy ) {
    if ( 'megamenu-cat' !== $taxonomy ) return $args;
    $args['public'] = false;
    $args['publicly_queryable'] = false;
    $args['rewrite'] = false;
    $args['query_var'] = false;
    return $args;
}
add_filter( 'register_taxonomy_args', 'wpbb_child_private_megamenu_taxonomy_args', 20, 2 );

function wpbb_child_core_sitemap_post_types( $post_types ) {
    unset( $post_types['megamenu'] );
    return $post_types;
}
add_filter( 'wp_sitemaps_post_types', 'wpbb_child_core_sitemap_post_types', 20 );

function wpbb_child_core_sitemap_taxonomies( $taxonomies ) {
    unset( $taxonomies['megamenu-cat'] );
    return $taxonomies;
}
add_filter( 'wp_sitemaps_taxonomies', 'wpbb_child_core_sitemap_taxonomies', 20 );

function wpbb_child_mega_robots( $robots ) {
    if ( is_singular( 'megamenu' ) || is_tax( 'megamenu-cat' ) ) {
        $robots['noindex'] = true;
        $robots['nofollow'] = true;
    }
    return $robots;
}
add_filter( 'wp_robots', 'wpbb_child_mega_robots', 20 );

function wpbb_child_yoast_exclude_megamenu_post_type( $excluded, $post_type ) {
    return 'megamenu' === $post_type ? true : $excluded;
}
add_filter( 'wpseo_sitemap_exclude_post_type', 'wpbb_child_yoast_exclude_megamenu_post_type', 20, 2 );

function wpbb_child_yoast_exclude_megamenu_taxonomy( $excluded, $taxonomy ) {
    return 'megamenu-cat' === $taxonomy ? true : $excluded;
}
add_filter( 'wpseo_sitemap_exclude_taxonomy', 'wpbb_child_yoast_exclude_megamenu_taxonomy', 20, 2 );

function wpbb_child_yoast_mega_robots( $robots ) {
    if ( is_singular( 'megamenu' ) || is_tax( 'megamenu-cat' ) ) return 'noindex, nofollow';
    return $robots;
}
add_filter( 'wpseo_robots', 'wpbb_child_yoast_mega_robots', 20 );


/**
 * v3.8.10.21: global request-a-quote UI is opt-in by child theme.
 * Sector themes with their own quote journeys can keep it; the rest do not
 * expose an unrelated floating "My Quote" control or public route.
 */
if ( ! function_exists( 'wpbb_child_request_quote_enabled' ) ) {
    function wpbb_child_request_quote_enabled() {
        $enabled_themes = array(
            'wp-bbtheme-child-automotive',
            'wp-bbtheme-child-building-services',
            'wp-bbtheme-child-insurance',
            'wp-bbtheme-child-logistics',
            'wp-bbtheme-child-medicine',
            'wp-bbtheme-child-woo-tech-shop',
        );
        $enabled = in_array( get_stylesheet(), $enabled_themes, true );
        return (bool) apply_filters( 'wpbb_child_request_quote_enabled', $enabled, get_stylesheet() );
    }
}

function wpbb_child_request_quote_body_class( $classes ) {
    $classes[] = wpbb_child_request_quote_enabled() ? 'wpbb-request-quote-enabled' : 'wpbb-request-quote-disabled';
    return $classes;
}
add_filter( 'body_class', 'wpbb_child_request_quote_body_class', 30 );

function wpbb_child_request_quote_menu_items( $items ) {
    if ( wpbb_child_request_quote_enabled() ) return $items;
    $target = trim( (string) wp_parse_url( home_url( '/request-a-quote/' ), PHP_URL_PATH ), '/' );
    foreach ( $items as $key => $item ) {
        $path = trim( (string) wp_parse_url( $item->url, PHP_URL_PATH ), '/' );
        if ( $target && $path === $target ) unset( $items[ $key ] );
    }
    return $items;
}
add_filter( 'wp_nav_menu_objects', 'wpbb_child_request_quote_menu_items', 30 );

function wpbb_child_request_quote_disable_route() {
    if ( wpbb_child_request_quote_enabled() ) return;
    $request = isset( $GLOBALS['wp']->request ) ? trim( (string) $GLOBALS['wp']->request, '/' ) : '';
    if ( ! is_page( 'request-a-quote' ) && 'request-a-quote' !== $request ) return;

    global $wp_query;
    if ( $wp_query ) $wp_query->set_404();
    status_header( 404 );
    nocache_headers();
    $template = get_404_template();
    if ( $template ) {
        include $template;
        exit;
    }
    wp_die( esc_html__( 'Page not found.', 'wp-bbtheme-child' ), esc_html__( 'Not found', 'wp-bbtheme-child' ), array( 'response' => 404 ) );
}
add_action( 'template_redirect', 'wpbb_child_request_quote_disable_route', 1 );

function wpbb_child_request_quote_sitemap_args( $args, $post_type ) {
    if ( wpbb_child_request_quote_enabled() || 'page' !== $post_type ) return $args;
    $page = get_page_by_path( 'request-a-quote' );
    if ( $page ) {
        $excluded = isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array();
        $excluded[] = (int) $page->ID;
        $args['post__not_in'] = array_values( array_unique( $excluded ) );
    }
    return $args;
}
add_filter( 'wp_sitemaps_posts_query_args', 'wpbb_child_request_quote_sitemap_args', 30, 2 );

require_once get_stylesheet_directory() . '/inc/seo-guardrails.php';

/** v3.8.10.24: identify generated legal pages independently of translated slugs. */
function wpbb_child_legal_page_body_class_v381024( $classes ) {
    if ( ! is_page() ) return $classes;
    $post = get_queried_object();
    if ( ! $post instanceof WP_Post ) return $classes;

    $is_legal = function_exists( 'is_privacy_policy' ) && is_privacy_policy();
    if ( ! $is_legal && false !== strpos( (string) $post->post_content, 'wp-theme-legal-section' ) ) {
        $is_legal = true;
    }
    if ( $is_legal ) $classes[] = 'wpbb-legal-page';
    return array_values( array_unique( $classes ) );
}
add_filter( 'body_class', 'wpbb_child_legal_page_body_class_v381024', 40 );

/** v3.8.10.25: remove generated empty spacing without touching authored copy. */
if ( ! function_exists( 'wpbb_child_remove_empty_paragraphs_v381025' ) ) {
    function wpbb_child_remove_empty_paragraphs_v381025( $content ) {
        if ( is_admin() || ! is_string( $content ) || '' === $content ) return $content;
        return (string) preg_replace(
            '~<p(?:\\s[^>]*)?>(?:\\s|&nbsp;|&#160;|<br\\s*/?>)*</p>~i',
            '',
            $content
        );
    }
}
add_filter( 'the_content', 'wpbb_child_remove_empty_paragraphs_v381025', 120 );

/** v3.8.10.25: do not output a completely empty CTA block above the footer. */
if ( ! function_exists( 'wpbb_child_remove_empty_cta_v381025' ) ) {
    function wpbb_child_remove_empty_cta_v381025( $block_content, $block ) {
        if ( empty( $block['blockName'] ) || 'wpbb/cta-section' !== $block['blockName'] || ! is_string( $block_content ) ) return $block_content;
        if ( preg_match( '~<(?:img|picture|video|iframe|form|button|a)\\b~i', $block_content ) ) return $block_content;
        $plain = trim( html_entity_decode( wp_strip_all_tags( $block_content ), ENT_QUOTES | ENT_HTML5, get_bloginfo( 'charset' ) ) );
        return '' === $plain ? '' : $block_content;
    }
}
add_filter( 'render_block', 'wpbb_child_remove_empty_cta_v381025', 120, 2 );



/** v3.8.10.29: make demo switching/imports self-healing across child themes. */
if ( ! function_exists( 'wpbb_child_demo_refresh_on_activation_v381029' ) ) {
    function wpbb_child_demo_refresh_on_activation_v381029() {
        // The parent importer stores one global version/profile. When a different
        // child theme is activated, invalidate that marker so its own profile is
        // imported instead of reusing the previous child's demo state.
        delete_option( 'wp_theme_demo_import_version' );
        delete_option( 'wp_theme_demo_menu_profile' );
    }
    add_action( 'after_switch_theme', 'wpbb_child_demo_refresh_on_activation_v381029', 5 );
}

if ( ! function_exists( 'wpbb_child_demo_integrity_guard_v381029' ) ) {
    function wpbb_child_demo_integrity_guard_v381029( $page_id = 0, $profile = array() ) {
        $page_id = absint( $page_id ?: get_option( 'page_on_front' ) );
        if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) return;

        $content = (string) get_post_field( 'post_content', $page_id );
        // Never rewrite a real imported or edited homepage. This is only a guard
        // for the genuinely empty/near-empty page seen after switching demos.
        if ( strlen( trim( $content ) ) >= 120 ) return;

        if ( ! is_array( $profile ) ) $profile = array();
        $eyebrow = (string) ( $profile['eyebrow'] ?? __( 'Welcome', 'wp-theme' ) );
        $title = (string) ( $profile['hero_title'] ?? get_bloginfo( 'name' ) );
        $intro = (string) ( $profile['hero_text'] ?? __( 'A practical WordPress starter site ready to edit.', 'wp-theme' ) );
        $primary_label = (string) ( $profile['primary_label'] ?? __( 'Get started', 'wp-theme' ) );
        $primary_url = (string) ( $profile['primary_url'] ?? home_url( '/contact/' ) );
        $secondary_label = (string) ( $profile['secondary_label'] ?? __( 'Explore', 'wp-theme' ) );
        $secondary_url = (string) ( $profile['secondary_url'] ?? home_url( '/services/' ) );
        $services_heading = (string) ( $profile['services_heading'] ?? __( 'Useful services, clearly presented.', 'wp-theme' ) );
        $about_title = (string) ( $profile['about_title'] ?? __( 'A flexible starting point for the real site.', 'wp-theme' ) );
        $about_text = (string) ( $profile['about_text'] ?? $intro );
        $hero_image = esc_url( (string) ( $profile['hero_image'] ?? '' ) );
        $about_image = esc_url( (string) ( $profile['about_image'] ?? $hero_image ) );
        $services = ! empty( $profile['services'] ) && is_array( $profile['services'] ) ? array_slice( $profile['services'], 0, 4 ) : array();
        $stats = ! empty( $profile['stats'] ) && is_array( $profile['stats'] ) ? array_slice( $profile['stats'], 0, 4 ) : array();

        $out = '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wp-theme-sector-hero wp-theme-demo-repair","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container","customClasses":"align-items-center"} --><!-- wp:wpbb/column {"xs":12,"lg":6} --><p class="wp-theme-sector-eyebrow">' . esc_html( $eyebrow ) . '</p><h1>' . esc_html( $title ) . '</h1><p class="wp-theme-sector-lead">' . esc_html( $intro ) . '</p><div class="wp-theme-demo-buttons"><a class="btn btn-primary" href="' . esc_url( $primary_url ) . '">' . esc_html( $primary_label ) . '</a><a class="btn btn-outline-primary" href="' . esc_url( $secondary_url ) . '">' . esc_html( $secondary_label ) . '</a></div><!-- /wp:wpbb/column -->';
        if ( $hero_image ) $out .= '<!-- wp:wpbb/column {"xs":12,"lg":6} --><figure class="wp-theme-sector-page-image"><img src="' . $hero_image . '" alt="" loading="eager" decoding="async"></figure><!-- /wp:wpbb/column -->';
        $out .= '<!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';

        if ( 'automotive' === ( $profile['id'] ?? '' ) ) {
            $out .= '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wpbb-automotive-finder-section","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container"} --><!-- wp:wpbb/column {"xs":12} --><!-- wp:wpbb/sector-finder {"context":"automotive","limit":8} /--><!-- /wp:wpbb/column --><!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';
        }

        $out .= '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wp-theme-services-section","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container"} --><!-- wp:wpbb/column {"xs":12} --><p class="wp-theme-sector-eyebrow">' . esc_html( (string) ( $profile['services_eyebrow'] ?? __( 'Services', 'wp-theme' ) ) ) . '</p><h2>' . esc_html( $services_heading ) . '</h2><!-- wp:wpbb/row {"gutterX":"gx-4","gutterY":"gy-4"} -->';
        foreach ( $services as $service ) {
            $service_title = is_array( $service ) ? (string) ( $service[0] ?? '' ) : '';
            $service_text = is_array( $service ) ? (string) ( $service[1] ?? '' ) : '';
            if ( '' === trim( $service_title ) ) continue;
            $out .= '<!-- wp:wpbb/column {"xs":12,"md":6,"lg":3} --><article class="wp-theme-sector-card"><h3>' . esc_html( $service_title ) . '</h3><p>' . esc_html( $service_text ) . '</p></article><!-- /wp:wpbb/column -->';
        }
        $out .= '<!-- /wp:wpbb/row --><!-- /wp:wpbb/column --><!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';

        $out .= '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wp-theme-about-section","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container","customClasses":"align-items-center"} -->';
        if ( $about_image ) $out .= '<!-- wp:wpbb/column {"xs":12,"lg":6} --><figure class="wp-theme-sector-page-image"><img src="' . $about_image . '" alt="" loading="lazy" decoding="async"></figure><!-- /wp:wpbb/column -->';
        $out .= '<!-- wp:wpbb/column {"xs":12,"lg":6} --><p class="wp-theme-sector-eyebrow">' . esc_html( (string) ( $profile['about_eyebrow'] ?? __( 'About', 'wp-theme' ) ) ) . '</p><h2>' . esc_html( $about_title ) . '</h2><p class="wp-theme-sector-lead">' . esc_html( $about_text ) . '</p><!-- /wp:wpbb/column --><!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';

        if ( $stats ) {
            $out .= '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wp-theme-sector-proof","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container","gutterX":"gx-3","gutterY":"gy-3"} -->';
            foreach ( $stats as $stat ) {
                $number = is_array( $stat ) ? (string) ( $stat[0] ?? '' ) : '';
                $label = is_array( $stat ) ? (string) ( $stat[1] ?? '' ) : '';
                $out .= '<!-- wp:wpbb/column {"xs":6,"lg":3} --><div class="wp-theme-sector-proof__item"><h3>' . esc_html( $number ) . '</h3><p>' . esc_html( $label ) . '</p></div><!-- /wp:wpbb/column -->';
            }
            $out .= '<!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';
        }

        $out .= '<!-- wp:wpbb/cta-section {"title":"' . esc_attr( (string) ( $profile['cta_title'] ?? __( 'Ready to make it yours?', 'wp-theme' ) ) ) . '","titleTag":"h2","text":"' . esc_attr( (string) ( $profile['cta_text'] ?? $intro ) ) . '","buttonText":"' . esc_attr( $primary_label ) . '","buttonUrl":"' . esc_url( $primary_url ) . '","className":"wp-theme-home-cta wp-theme-home-cta--bbuilder"} /-->';

        wp_update_post( array( 'ID' => $page_id, 'post_content' => $out ) );
        update_post_meta( $page_id, '_wp_theme_demo_repaired_381029', current_time( 'mysql' ) );
    }
    add_action( 'wp_theme_after_demo_import', 'wpbb_child_demo_integrity_guard_v381029', 99, 2 );
}


/* v3.8.10.30: realistic demo blog featured images. Runs only after the theme's explicit demo import. */
function wpbb_automotive_demo_blog_photo_attachment( $filename, $title ) {
    $slug = sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) );
    $existing = get_page_by_path( 'automotive-blog-' . $slug, OBJECT, 'attachment' );
    if ( $existing ) {
        if ( function_exists( 'wpbb_automotive_refresh_bundled_attachment_v381041' ) ) wpbb_automotive_refresh_bundled_attachment_v381041( (int) $existing->ID, 'assets/img/blog' );
        return (int) $existing->ID;
    }
    $source = get_stylesheet_directory() . '/assets/img/blog/' . basename( $filename );
    if ( ! is_readable( $source ) ) return 0;
    $uploads = wp_upload_dir();
    $dir = trailingslashit( $uploads['basedir'] ) . 'automotive-blog';
    wp_mkdir_p( $dir );
    $target = $dir . '/' . basename( $filename );
    if ( ! file_exists( $target ) ) copy( $source, $target );
    $filetype = wp_check_filetype( $target );
    if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';
    $id = wp_insert_attachment( array(
        'post_mime_type' => $filetype['type'] ?: 'image/jpeg',
        'post_title' => $title,
        'post_name' => 'automotive-blog-' . $slug,
        'post_status' => 'inherit',
    ), $target );
    if ( $id && ! is_wp_error( $id ) ) {
        if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';
        $meta = wpbb_child_381048_generate_attachment_metadata( $id, $target );
        if ( $meta ) wp_update_attachment_metadata( $id, $meta );
        update_post_meta( $id, '_wp_attachment_image_alt', $title );
        return (int) $id;
    }
    return 0;
}
function wpbb_automotive_seed_demo_blog_photos( $page_id = 0, $profile = array() ) {
    $posts = get_posts( array( 'post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>12, 'orderby'=>'date', 'order'=>'DESC' ) );
    if ( ! $posts ) return;
    $images = array( 'blog-1.jpg','blog-2.jpg','blog-3.jpg','blog-4.jpg','blog-5.jpg','blog-6.jpg' );
    foreach ( $posts as $index => $post ) {
        $filename = $images[ $index % count( $images ) ];
        $attachment = wpbb_automotive_demo_blog_photo_attachment( $filename, get_the_title( $post ) );
        if ( $attachment ) set_post_thumbnail( $post->ID, $attachment );
    }
}
add_action( 'wp_theme_after_demo_import', 'wpbb_automotive_seed_demo_blog_photos', 70, 2 );


/** v3.8.10.31: apply bundled realistic media to already-imported demos after theme upgrade. */

/**
 * Refresh an already-imported demo attachment from the current child-theme asset.
 *
 * Image optimisation may have changed `_wp_attached_file` from e.g. item-1.jpg to
 * item-1.avif/webp. Resolve the bundled source by filename stem instead of requiring
 * the child theme to ship every generated format, then regenerate all WP sub-sizes.
 */
function wpbb_automotive_refresh_bundled_attachment_v381041( $attachment_id, $asset_dir ) {
    $attachment_id = absint( $attachment_id );
    if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) return false;

    $attached = (string) get_post_meta( $attachment_id, '_wp_attached_file', true );
    $stem = pathinfo( basename( $attached ), PATHINFO_FILENAME );
    if ( '' === $stem ) return false;

    $base = trailingslashit( get_stylesheet_directory() ) . trailingslashit( $asset_dir ) . $stem;
    $source = '';
    foreach ( array( '.jpg', '.jpeg', '.png', '.webp', '.avif' ) as $extension ) {
        if ( is_readable( $base . $extension ) ) {
            $source = $base . $extension;
            break;
        }
    }
    if ( ! $source ) return false;

    $target = get_attached_file( $attachment_id );
    if ( ! $target ) return false;

    if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';

    $source_ext = strtolower( (string) pathinfo( $source, PATHINFO_EXTENSION ) );
    $target_ext = strtolower( (string) pathinfo( $target, PATHINFO_EXTENSION ) );
    $written = false;

    if ( $source_ext === $target_ext ) {
        $written = (bool) @copy( $source, $target );
    } else {
        $target_type = wp_check_filetype( $target );
        $target_mime = ! empty( $target_type['type'] ) ? (string) $target_type['type'] : '';
        $editor = wp_get_image_editor( $source );
        if ( ! is_wp_error( $editor ) && 0 === strpos( $target_mime, 'image/' ) ) {
            $saved = $editor->save( $target, $target_mime );
            $written = ! is_wp_error( $saved ) && is_readable( $target );
        }
    }

    // Some hosts can read AVIF/WebP but cannot encode it. Fall back to the bundled
    // source extension and update WordPress to the new original file explicitly.
    if ( ! $written ) {
        $fallback = trailingslashit( dirname( $target ) ) . $stem . '.' . $source_ext;
        if ( ! @copy( $source, $fallback ) ) return false;
        update_attached_file( $attachment_id, $fallback );
        $filetype = wp_check_filetype( $fallback );
        if ( ! empty( $filetype['type'] ) ) {
            wp_update_post( array( 'ID' => $attachment_id, 'post_mime_type' => $filetype['type'] ) );
        }
        $target = $fallback;
    }

    // Remove old generated sizes first. Otherwise stale JPG thumbnails can remain
    // referenced after the original was converted to AVIF/WebP by an optimiser.
    $old_meta = wp_get_attachment_metadata( $attachment_id );
    if ( is_array( $old_meta ) && ! empty( $old_meta['sizes'] ) && is_array( $old_meta['sizes'] ) ) {
        foreach ( $old_meta['sizes'] as $old_size ) {
            if ( empty( $old_size['file'] ) ) continue;
            $old_file = trailingslashit( dirname( $target ) ) . basename( (string) $old_size['file'] );
            if ( is_file( $old_file ) && wp_normalize_path( $old_file ) !== wp_normalize_path( $target ) ) @unlink( $old_file );
        }
    }

    $meta = wpbb_child_381048_generate_attachment_metadata( $attachment_id, $target );
    if ( $meta ) wp_update_attachment_metadata( $attachment_id, $meta );
    clean_attachment_cache( $attachment_id );
    return true;
}

function wpbb_automotive_realistic_media_upgrade_v381041() {
    if ( ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) ) return;
    $done_key = 'wpbb_automotive_realistic_media_upgrade_v381041';
    if ( get_option( $done_key ) ) return;
    if ( ! current_user_can( 'manage_options' ) ) return;

    $pairs = array(array('wpbb-automotive','assets/img/demo'),array('automotive-blog','assets/img/blog'));
    foreach ( $pairs as $pair ) {
        $upload_prefix = $pair[0];
        $asset_dir = $pair[1];
        $ids = get_posts( array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => array( array( 'key'=>'_wp_attached_file', 'value'=>$upload_prefix . '/', 'compare'=>'LIKE' ) ),
        ) );
        foreach ( $ids as $attachment_id ) {
            wpbb_automotive_refresh_bundled_attachment_v381041( $attachment_id, $asset_dir );
        }
    }
    if ( function_exists( 'wpbb_automotive_seed_directory' ) ) wpbb_automotive_seed_directory( array( 'id'=>'automotive' ) );
    if ( function_exists( 'wpbb_automotive_seed_demo_blog_photos' ) ) wpbb_automotive_seed_demo_blog_photos( 0, array() );
    if ( post_type_exists( 'product' ) && function_exists( 'wpbb_automotive_demo_products' ) && function_exists( 'wpbb_automotive_demo_product_image' ) ) {
        $products = wpbb_automotive_demo_products( array() );
        foreach ( $products as $index => $product_data ) {
            $title = isset( $product_data[1] ) ? (string) $product_data[1] : '';
            if ( '' === $title ) continue;
            $matches = get_posts( array( 'post_type'=>'product', 'post_status'=>'any', 'posts_per_page'=>1, 'title'=>$title ) );
            if ( ! $matches ) continue;
            $source = wpbb_automotive_demo_product_image( '', $product_data, $index );
            if ( ! $source || ! is_readable( $source ) ) continue;
            $attachment_slug = 'wpbb-automotive-realistic-' . sanitize_title( $title );
            $existing = get_posts( array( 'post_type'=>'attachment', 'name'=>$attachment_slug, 'post_status'=>'inherit', 'posts_per_page'=>1, 'fields'=>'ids' ) );
            $attachment_id = $existing ? (int) $existing[0] : 0;
            if ( ! $attachment_id ) {
                $uploads = wp_upload_dir();
                $dir = trailingslashit( $uploads['basedir'] ) . 'wpbb-automotive-realistic';
                wp_mkdir_p( $dir );
                $target = $dir . '/' . basename( $source );
                if ( ! @copy( $source, $target ) ) continue;
                $filetype = wp_check_filetype( $target );
                if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';
                $attachment_id = wp_insert_attachment( array( 'post_mime_type'=>$filetype['type'] ?: 'image/jpeg', 'post_title'=>$title, 'post_name'=>$attachment_slug, 'post_status'=>'inherit' ), $target );
            } else {
                $target = get_attached_file( $attachment_id );
                if ( $target ) @copy( $source, $target );
            }
            if ( $attachment_id && ! is_wp_error( $attachment_id ) ) {
                $target = get_attached_file( $attachment_id );
                if ( $target ) {
                    if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';
                    $meta = wpbb_child_381048_generate_attachment_metadata( $attachment_id, $target );
                    if ( $meta ) wp_update_attachment_metadata( $attachment_id, $meta );
                }
                set_post_thumbnail( $matches[0]->ID, $attachment_id );
            }
        }
    }
    update_option( $done_key, current_time( 'mysql' ), false );
}
add_action( 'admin_init', 'wpbb_automotive_realistic_media_upgrade_v381041', 120 );


/* v3.8.10.42: full-width single-column demo rows + optional frontend demo protection. */
function wpbb_child_381042_repair_single_columns( $blocks ) {
    foreach ( $blocks as &$block ) {
        if ( 'wpbb/row' === ( $block['blockName'] ?? '' ) && ! empty( $block['innerBlocks'] ) ) {
            $column_indexes = array();
            foreach ( $block['innerBlocks'] as $index => $inner ) {
                if ( 'wpbb/column' === ( $inner['blockName'] ?? '' ) ) $column_indexes[] = $index;
            }
            if ( 1 === count( $column_indexes ) ) {
                $idx = $column_indexes[0];
                $attrs = $block['innerBlocks'][ $idx ]['attrs'] ?? array();
                if ( 12 === (int) ( $attrs['xs'] ?? 12 ) ) {
                    $attrs['xs'] = 12;
                    foreach ( array( 'sm', 'md', 'lg', 'xl', 'xxl' ) as $breakpoint ) unset( $attrs[ $breakpoint ] );
                    $block['innerBlocks'][ $idx ]['attrs'] = $attrs;
                }
            }
        }
        if ( ! empty( $block['innerBlocks'] ) ) $block['innerBlocks'] = wpbb_child_381042_repair_single_columns( $block['innerBlocks'] );
    }
    unset( $block );
    return $blocks;
}

function wpbb_child_381042_repair_demo_page_widths() {
    $pages = get_posts( array(
        'post_type' => 'page', 'post_status' => 'any', 'posts_per_page' => -1,
        'meta_key' => '_wp_theme_demo_managed', 'meta_value' => '1', 'fields' => 'ids',
    ) );
    foreach ( $pages as $page_id ) {
        $content = (string) get_post_field( 'post_content', $page_id );
        if ( false === strpos( $content, 'wpbb/column' ) ) continue;
        $blocks = parse_blocks( $content );
        $repaired = serialize_blocks( wpbb_child_381042_repair_single_columns( $blocks ) );
        if ( $repaired !== $content ) wp_update_post( array( 'ID' => $page_id, 'post_content' => $repaired ) );
    }
}
add_action( 'wp_theme_after_demo_import', 'wpbb_child_381042_repair_demo_page_widths', 140 );
function wpbb_child_381042_repair_demo_page_widths_once() {
    if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) return;
    $key = 'wpbb_381042_single_col_' . sanitize_key( get_stylesheet() );
    if ( get_option( $key ) ) return;
    wpbb_child_381042_repair_demo_page_widths();
    update_option( $key, 1, false );
}
add_action( 'admin_init', 'wpbb_child_381042_repair_demo_page_widths_once', 40 );

/**
 * v3.8.10.43: repair shared demo alignment and force one fresh media pass.
 *
 * The previous media migration was intentionally one-shot. This release uses a
 * new per-theme marker so sites that already ran v381041 receive the current
 * child-owned room/product/project/blog images as well.
 */
if ( ! function_exists( 'wpbb_child_381043_normalize_text' ) ) {
    function wpbb_child_381043_normalize_text( $value ) {
        $value = html_entity_decode( wp_strip_all_tags( (string) $value ), ENT_QUOTES | ENT_HTML5, get_bloginfo( 'charset' ) );
        return trim( preg_replace( '/\\s+/u', ' ', $value ) );
    }
}

if ( ! function_exists( 'wpbb_child_381043_dedupe_single_body' ) ) {
    function wpbb_child_381043_dedupe_single_body( $content, $excerpt = '' ) {
        $excerpt_text = wpbb_child_381043_normalize_text( $excerpt );
        if ( '' === $excerpt_text ) return $content;

        $content_text = wpbb_child_381043_normalize_text( $content );
        if ( $content_text === $excerpt_text ) return '';

        if ( preg_match( '~^\\s*<p(?:\\s[^>]*)?>(.*?)</p>~is', (string) $content, $match ) ) {
            if ( wpbb_child_381043_normalize_text( $match[1] ) === $excerpt_text ) {
                return ltrim( substr( (string) $content, strlen( $match[0] ) ) );
            }
        }
        return $content;
    }
}

if ( ! function_exists( 'wpbb_child_381043_repair_block_alignment' ) ) {
    function wpbb_child_381043_repair_block_alignment( $blocks ) {
        foreach ( $blocks as &$block ) {
            if ( 'wpbb/row' === ( $block['blockName'] ?? '' ) ) {
                $attrs = $block['attrs'] ?? array();
                $classes = preg_split( '/\\s+/', trim( (string) ( $attrs['customClasses'] ?? '' ) ) );
                $classes = array_values( array_filter( array_map( 'sanitize_html_class', $classes ) ) );
                if ( in_array( 'wp-theme-sector-media-text', $classes, true ) ) {
                    $classes = array_values( array_diff( $classes, array( 'align-items-center', 'align-items-end' ) ) );
                    if ( ! in_array( 'align-items-start', $classes, true ) ) $classes[] = 'align-items-start';
                    $attrs['customClasses'] = implode( ' ', $classes );
                    $block['attrs'] = $attrs;
                }
            }
            if ( ! empty( $block['innerBlocks'] ) ) {
                $block['innerBlocks'] = wpbb_child_381043_repair_block_alignment( $block['innerBlocks'] );
            }
        }
        unset( $block );
        return $blocks;
    }
}

if ( ! function_exists( 'wpbb_child_381043_repair_demo_pages' ) ) {
    function wpbb_child_381043_repair_demo_pages() {
        // Repair every page that actually contains the theme's media/text row.
        // This also covers front pages imported before the managed-page marker existed.
        $page_ids = get_posts( array(
            'post_type' => 'page',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids',
        ) );
        foreach ( $page_ids as $page_id ) {
            $content = (string) get_post_field( 'post_content', $page_id );
            if ( false === strpos( $content, 'wp-theme-sector-media-text' ) ) continue;
            $repaired = serialize_blocks( wpbb_child_381043_repair_block_alignment( parse_blocks( $content ) ) );
            if ( $repaired !== $content ) {
                wp_update_post( array( 'ID' => $page_id, 'post_content' => $repaired ) );
                clean_post_cache( $page_id );
            }
        }
    }
}

if ( ! function_exists( 'wpbb_child_381043_refresh_media_once' ) ) {
    function wpbb_child_381043_refresh_media_once( $page_id = 0, $profile = array() ) {
        if ( ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;

        $current_stylesheet = sanitize_key( get_stylesheet() );
        $done_key = 'wpbb_child_381043_media_' . $current_stylesheet;
        $owner_key = 'wpbb_child_381043_media_owner';
        // Demo posts are shared while child themes are switched. Refresh again
        // whenever a different child theme last supplied the active media.
        if ( get_option( $done_key ) && $current_stylesheet === (string) get_option( $owner_key ) ) return;

        $defined = get_defined_functions();
        foreach ( (array) ( $defined['user'] ?? array() ) as $function_name ) {
            if ( ! preg_match( '/^wpbb_[a-z0-9_]+_realistic_media_upgrade_v381041$/', $function_name ) ) continue;
            delete_option( $function_name );
            call_user_func( $function_name );
        }

        // Correct stale titles/alt text left behind when the same demo posts were
        // reused while switching child themes.
        $post_ids = get_posts( array(
            'post_type' => 'any',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'meta_key' => '_thumbnail_id',
            'fields' => 'ids',
        ) );
        foreach ( $post_ids as $post_id ) {
            $thumbnail_id = (int) get_post_thumbnail_id( $post_id );
            if ( ! $thumbnail_id ) continue;
            $attached = (string) get_post_meta( $thumbnail_id, '_wp_attached_file', true );
            $attachment_name = (string) get_post_field( 'post_name', $thumbnail_id );
            if ( false === strpos( $attached, '-blog/' ) && 0 !== strpos( $attachment_name, 'wpbb-' ) ) continue;
            $title = get_the_title( $post_id );
            if ( '' === trim( (string) $title ) ) continue;
            wp_update_post( array( 'ID' => $thumbnail_id, 'post_title' => $title ) );
            update_post_meta( $thumbnail_id, '_wp_attachment_image_alt', $title );
            clean_post_cache( $post_id );
            clean_attachment_cache( $thumbnail_id );
        }

        wpbb_child_381043_repair_demo_pages();
        update_option( $done_key, current_time( 'mysql' ), false );
        update_option( $owner_key, $current_stylesheet, false );
    }
}
add_action( 'wp_theme_after_demo_import', 'wpbb_child_381043_refresh_media_once', 180, 2 );
add_action( 'admin_init', 'wpbb_child_381043_refresh_media_once', 130 );

/**
 * v3.8.10.45: shared rhythm, contrast, sector-media and gallery repair.
 */
require_once __DIR__ . '/inc/sector-consistency.php';

/**
 * v3.8.10.47: win the final template_include pass for WooCommerce screens.
 * Some block-template resolvers run after the older priority-99 callback and
 * can otherwise replace the complete child-owned product shell with a generic
 * single-post template.
 */
if ( ! function_exists( 'wpbb_child_381047_force_woo_legacy_template' ) ) {
    function wpbb_child_381047_force_woo_legacy_template( $template ) {
        if ( is_admin() || wp_doing_ajax() || is_feed() || ! post_type_exists( 'product' ) ) {
            return $template;
        }
        if ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {
            return $template;
        }
        $base = trailingslashit( get_stylesheet_directory() ) . 'woocommerce-legacy/';
        $candidate = '';
        if ( ( function_exists( 'is_product' ) && is_product() ) || is_singular( 'product' ) ) {
            $candidate = 'product.php';
        } elseif ( function_exists( 'is_cart' ) && is_cart() ) {
            $candidate = 'cart.php';
        } elseif ( function_exists( 'is_checkout' ) && is_checkout() ) {
            $candidate = 'checkout.php';
        } elseif ( function_exists( 'is_account_page' ) && is_account_page() ) {
            $candidate = 'account.php';
        } elseif ( ( function_exists( 'is_shop' ) && is_shop() ) || ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) ) {
            $candidate = 'catalog.php';
        }
        return $candidate && is_readable( $base . $candidate ) ? $base . $candidate : $template;
    }
}
add_filter( 'template_include', 'wpbb_child_381047_force_woo_legacy_template', PHP_INT_MAX );

// v3.8.10.64 shared BBuilder/demo consistency layer.
require_once get_stylesheet_directory() . '/inc/bbuilder-system-v62.php';

/**
 * v3.8.10.64 PWA endpoint hardening.
 *
 * The parent theme links to ?wpbb-pwa=manifest and registers
 * ?wpbb-pwa=service-worker. Serve those endpoints before the normal template
 * loader so browsers always receive the expected MIME type and valid payload.
 * The service worker intentionally has no fetch handler: this prevents stale
 * worker-cached ES modules from causing Chromium cross-world preload warnings.
 */
if ( ! function_exists( 'wpbb_child_381063_serve_pwa_endpoint' ) ) {
    function wpbb_child_381063_serve_pwa_endpoint() {
        if ( empty( $_GET['wpbb-pwa'] ) ) return;
        $mode = sanitize_key( wp_unslash( $_GET['wpbb-pwa'] ) );
        if ( ! in_array( $mode, array( 'manifest', 'service-worker' ), true ) ) return;

        while ( ob_get_level() ) {
            @ob_end_clean();
        }
        nocache_headers();
        header( 'X-Content-Type-Options: nosniff' );

        if ( 'manifest' === $mode ) {
            header( 'Content-Type: application/manifest+json; charset=UTF-8' );
            $name = trim( (string) get_bloginfo( 'name' ) );
            if ( '' === $name ) $name = 'WP Base';
            $scope = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
            if ( '' === $scope ) $scope = '/';
            $icons = array();
            foreach ( array( 192, 512 ) as $size ) {
                $file = get_stylesheet_directory() . '/assets/icons/icon-' . $size . '.png';
                if ( is_readable( $file ) ) {
                    $icons[] = array(
                        'src' => get_stylesheet_directory_uri() . '/assets/icons/icon-' . $size . '.png',
                        'sizes' => $size . 'x' . $size,
                        'type' => 'image/png',
                        'purpose' => 'any maskable',
                    );
                }
            }
            echo wp_json_encode( array(
                'name' => $name,
                'short_name' => function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 24 ) : substr( $name, 0, 24 ),
                'start_url' => home_url( '/' ),
                'scope' => $scope,
                'display' => 'standalone',
                'background_color' => '#ffffff',
                'theme_color' => '#3155D9',
                'icons' => $icons,
            ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            exit;
        }

        header( 'Content-Type: application/javascript; charset=UTF-8' );
        header( 'Service-Worker-Allowed: /' );
        echo "self.addEventListener('install',function(event){self.skipWaiting();});\n";
        echo "self.addEventListener('activate',function(event){event.waitUntil((async function(){try{var keys=await caches.keys();await Promise.all(keys.filter(function(k){return /^(wpbb|wp-theme|wpbase)/i.test(k);}).map(function(k){return caches.delete(k);}));}catch(e){}await self.clients.claim();})());});\n";
        exit;
    }
    add_action( 'template_redirect', 'wpbb_child_381063_serve_pwa_endpoint', -9999 );
}
// v3.8.10.75 commerce consistency and managed-demo media repair.
require_once get_stylesheet_directory() . '/inc/v74-commerce.php';
// v3.8.10.75 structural/media/Woo repair.
require_once get_stylesheet_directory() . '/inc/v75-suite.php';

// v3.8.10.81: keep interactive wp-admin saves/updates fast.
require_once get_stylesheet_directory() . '/inc/v82-suite.php';
require_once get_stylesheet_directory() . '/inc/admin-performance.php';

// v3.8.10.83 premium Jobs-aligned sector presentation and multilingual managed-demo refresh.
require_once get_stylesheet_directory() . '/inc/v83-premium-suite.php';
// v3.8.10.97 final premium Jobs-aligned suite and mobile navigation.
require_once get_stylesheet_directory() . '/inc/v97-premium-suite.php';


/** 3.8.10.98 suite-wide layout/mobile finishing layer. */
function wpbb_suite_v98_enqueue(){
    $v = wp_get_theme()->get('Version');
    wp_enqueue_style('wpbb-suite-v98', get_stylesheet_directory_uri() . '/assets/suite-v98.css', array(), $v);
    wp_enqueue_script('wpbb-suite-v98', get_stylesheet_directory_uri() . '/assets/suite-v98.js', array(), $v, true);
}
add_action('wp_enqueue_scripts','wpbb_suite_v98_enqueue',999);

// v3.8.10.99 final suite-wide grid, branding, hero and mobile finish.
require_once get_stylesheet_directory() . '/inc/v99-finish.php';

// v3.8.11.00 cookie ownership, hero/colour and mobile navigation finish.
require_once get_stylesheet_directory() . '/inc/v100-finish.php';

// v3.8.11.02 navigation, legal, colour and media correction.
require_once get_stylesheet_directory() . '/inc/v101-finish.php';

// v3.8.11.04 deterministic mobile navigation and WooCommerce/alignment finish.
require_once get_stylesheet_directory() . '/inc/v104-finish.php';

// v3.8.11.05 legal/contact grid, mobile drawer and WooCommerce template finish.
require_once get_stylesheet_directory() . '/inc/v105-finish.php';

// v3.8.11.07 final search, WooCommerce, Jobs captcha/grid and responsive repair.
require_once get_stylesheet_directory() . '/inc/v107-finish.php';

// v3.8.11.08 WooCommerce layout/polish and packaging finish.
require_once get_stylesheet_directory() . '/inc/v108-finish.php';

// v3.8.11.09 WooCommerce, media and account finalisation.
require_once get_stylesheet_directory() . '/inc/v109-finish.php';

// v3.8.11.10 media, WooCommerce, managed-page and route-facing finish.
require_once get_stylesheet_directory() . '/inc/v110-finish.php';

// v3.8.11.11 hero finder, editorial grid, mega-menu and image-quality finish.
require_once get_stylesheet_directory() . '/inc/v111-finish.php';

// v3.8.11.12 editorial grid, hero clarity and media recovery.
require_once get_stylesheet_directory() . '/inc/v112-finish.php';

// v3.8.11.13 final hero edge/clarity and editorial-grid alignment.
require_once get_stylesheet_directory() . '/inc/v113-finish.php';

// v3.8.11.14 child-only settings, editor, legal, editorial and hero finish.
require_once get_stylesheet_directory() . '/inc/v114-finish.php';

// v3.8.11.15 final mega-menu, hero/media, quote and BBuilder repair.
require_once get_stylesheet_directory() . '/inc/v115-finish.php';

// v3.8.11.16 reset-safe layout/media, mega-menu, consent and BBuilder finish.
require_once get_stylesheet_directory() . '/inc/v116-finish.php';

// v3.8.11.17 exact mega-menu placement, reset-safe BBuilder grid and immediate media recovery.
require_once get_stylesheet_directory() . '/inc/v117-finish.php';


// v3.8.11.18 reset-safe gutters, direct hero assets, nav-trigger mega positioning and cache finish.
require_once get_stylesheet_directory() . '/inc/v118-finish.php';

// v3.8.11.19 live regression repair: closer mega menus, canonical gutters/grids and no-flash consent.
require_once get_stylesheet_directory() . '/inc/v119-finish.php';

// v3.8.11.20 stable v119 rollback, restored gutters/grids and deterministic hero pagination/quality repair.
require_once get_stylesheet_directory() . '/inc/v120-finish.php';

// v3.8.11.21 scoped BBuilder grid recovery; retire v119/v120 global geometry while preserving hero quality/pagination.
require_once get_stylesheet_directory() . '/inc/v121-finish.php';

// v3.8.11.22 component-only grid-gap finish; keep v121 alignment and restore stable card/media/stat spacing.
require_once get_stylesheet_directory() . '/inc/v122-finish.php';

// v3.8.11.23 remaining basic grids/gaps + authoritative hero source/pagination finish.
require_once get_stylesheet_directory() . '/inc/v123-finish.php';

// v3.8.11.24 final basic visual hardening: deterministic card gaps, full-width fun-facts and one compact hero pager.
require_once get_stylesheet_directory() . '/inc/v124-finish.php';

// v3.8.11.25 final scoped grid, hero clarity and WooCommerce shop/cart/account finish.
require_once get_stylesheet_directory() . '/inc/v125-final.php';

// v3.8.11.26 final cross-theme component grids, hero image/pagination and process-card recovery.
require_once get_stylesheet_directory() . '/inc/v126-final.php';

// v3.8.11.27 final live-regression hardening: robust card grids, process-card shape, hero pagination and Business/Building hero fade.
require_once get_stylesheet_directory() . '/inc/v127-final.php';

// v3.8.11.28 final live component recovery: commerce grids, cart/checkout, process cards and stable hero media/pagination.
require_once get_stylesheet_directory() . '/inc/v128-final.php';

// v3.8.11.29 Automotive targeted live repair: row 31, process badges and homepage product grid.
require_once get_stylesheet_directory() . '/inc/v129-final.php';

// v3.8.11.30 Automotive commerce/account finish: two-column cart, clean checkout and canonical My Account endpoints.
require_once get_stylesheet_directory() . '/inc/v130-final.php';

// v3.8.11.31 Automotive final live hardening: homepage finder/catalogue, shop compare, product, cart and checkout.
require_once get_stylesheet_directory() . '/inc/v131-final.php';

// v3.8.11.32 Automotive deterministic homepage + WooCommerce repair.
require_once get_stylesheet_directory() . '/inc/v132-final.php';

// v3.8.11.33 final live homepage/card/catalogue/hero ownership repair.
require_once get_stylesheet_directory() . '/inc/v133-final.php';

// v3.8.11.34 final cross-theme hero, grid, process and WooCommerce ownership layer.
require_once get_stylesheet_directory() . '/inc/v134-final.php';


// v3.8.11.35 final duplicate/process/hero cleanup.
require_once get_stylesheet_directory() . '/inc/v135-final.php';

// v3.8.11.36 full-width hero, stable process and cross-theme grid ownership.
require_once get_stylesheet_directory() . '/inc/v136-final.php';

// 3.8.11.37 scoped Automotive layout recovery.
require_once get_stylesheet_directory() . '/inc/v137-final.php';

// v3.8.11.38 Automotive hero pagination and compact homepage section rhythm.
require_once get_stylesheet_directory() . '/inc/v138-final.php';

// v3.8.11.39 Automotive mega-menu, basket, account endpoints and article CTA finish.
require_once get_stylesheet_directory() . '/inc/v139-final.php';
