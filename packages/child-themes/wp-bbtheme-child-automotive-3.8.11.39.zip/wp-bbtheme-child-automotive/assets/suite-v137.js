(function(W,D){
  'use strict';
  var CFG=W.wpbbSuiteV137||{};
  var ROOT=D.documentElement;
  function q(sel,root){try{return(root||D).querySelector(sel);}catch(e){return null;}}
  function qa(sel,root){try{return Array.prototype.slice.call((root||D).querySelectorAll(sel));}catch(e){return[];}}
  function kids(el){return el?Array.prototype.slice.call(el.children||[]):[];}
  function txt(el){return String(el&&el.textContent||'').replace(/\s+/g,' ').trim();}
  function norm(v){return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();}
  function unique(arr){return arr.filter(function(x,i,a){return x&&a.indexOf(x)===i;});}
  function topLevel(arr){return unique(arr).filter(function(item){return !arr.some(function(other){return other!==item&&other.contains&&other.contains(item);});});}

  function measureGrid(){
    var candidates=[
      q('.wp-theme-header-main > .container'),
      q('.wp-theme-header-main .container'),
      q('.wp-theme-site-header .container'),
      q('.wp-theme-site-footer .container')
    ].filter(Boolean);
    var best=null;
    candidates.some(function(el){
      var r=el.getBoundingClientRect();
      if(r.width>320&&r.width<=W.innerWidth+2){best=r;return true;}
      return false;
    });
    if(!best)return;
    ROOT.style.setProperty('--wpbb-v137-left',Math.max(16,Math.round(best.left))+'px');
    ROOT.style.setProperty('--wpbb-v137-right',Math.max(16,Math.round(W.innerWidth-best.right))+'px');
  }

  function removeMalformedBlockText(){
    var main=q('#wp-theme-main');
    if(!main||!D.createTreeWalker)return;
    var walker=D.createTreeWalker(main,NodeFilter.SHOW_TEXT),node,remove=[];
    while((node=walker.nextNode())){
      var value=String(node.nodeValue||'');
      if(/wp:wpbb\/icon-card|svgCode|wpbb-sector-proof-card/.test(value)&&(/<!--|<!-|wp:wpbb/.test(value)))remove.push(node);
    }
    remove.forEach(function(node){if(node.parentNode)node.parentNode.removeChild(node);});
  }

  function replacePlaceholderCards(){
    var main=q('#wp-theme-main');
    var cards=Array.isArray(CFG.cards)?CFG.cards:[];
    if(!main||!cards.length)return;
    var titles=qa('h1,h2,h3,h4,h5,h6,.wpbb-icon-card__title,.wp-theme-sector-card__title',main).filter(function(el){return txt(el)==='Card title';});
    var bodies=qa('p,.wpbb-icon-card__text,.wp-theme-sector-card__text',main).filter(function(el){return txt(el)==='Add a short description.';});
    titles.forEach(function(el,i){el.textContent=cards[i%cards.length].title;});
    bodies.forEach(function(el,i){el.textContent=cards[i%cards.length].text;});
  }

  function bestHost(scope,cards){
    cards=topLevel(cards||[]);
    if(!scope||cards.length<2)return null;
    var candidates=unique(cards.reduce(function(out,card){
      var node=card;
      for(var depth=0;node&&node!==scope&&depth<6;depth++,node=node.parentElement){
        if(node.matches&&node.matches('.row,.wpbb-row,.wpbb-v62-card-grid,.wpbb-sector-grid,.products,.wp-block-post-template'))out.push(node);
      }
      return out;
    },[]));
    var best=null;
    candidates.forEach(function(host){
      var direct=kids(host).filter(function(child){return cards.some(function(card){return child===card||child.contains(card);});});
      if(direct.length<2)return;
      if(!best||direct.length>best.items.length)best={host:host,items:direct};
    });
    if(best)return best;

    var parent=cards[0].parentElement;
    if(parent&&cards.every(function(card){return card.parentElement===parent;}))return{host:parent,items:cards.slice()};
    return null;
  }

  function markGrid(host,items,cols,extra){
    if(!host||!items||items.length<2)return;
    host.classList.add('wpbb-v137-grid','wpbb-v137-cols-'+Math.max(2,Math.min(4,cols||items.length)));
    if(extra)host.classList.add(extra);
    items.forEach(function(item){item.classList.add('wpbb-v137-grid-cell');});
  }

  function markSectionCards(){
    var groups=[
      ['.wp-theme-services-section,.wp-theme-sector-services-section','.wp-theme-sector-card,.wpbb-icon-card',4],
      ['.wp-theme-industries-section,.wp-theme-sector-industries-section','.wp-theme-sector-card,.wpbb-icon-card',4],
      ['.wp-theme-case-studies-section','.wp-theme-case-card,.wpbb-icon-card',3],
      ['.wp-theme-process-section','.wp-theme-process-card,.wpbb-icon-card',3]
    ];
    groups.forEach(function(group){
      qa('#wp-theme-main '+group[0]).forEach(function(section){
        var cards=topLevel(qa(group[1],section));
        var pick=bestHost(section,cards);
        if(pick)markGrid(pick.host,pick.items,group[2]);
      });
    });

    qa('#wp-theme-main .wp-theme-sector-services,#wp-theme-main .wp-theme-sector-industries,#wp-theme-main .wp-theme-sector-process-grid,#wp-theme-main .wp-theme-case-grid,#wp-theme-main .wp-theme-case-studies-grid').forEach(function(host){
      if(host.closest('.swiper,.wpbb-swiper--hero'))return;
      var items=kids(host).filter(function(item){return txt(item)||q('article,.card,.wpbb-icon-card,img',item);});
      if(items.length>=2&&items.length<=6)markGrid(host,items,items.length===3?3:4);
    });
  }

  function markStats(){
    qa('#wp-theme-main .wp-theme-sector-proof,#wp-theme-main .wp-theme-home-stats').forEach(function(section){
      var cards=topLevel(qa('.wp-theme-sector-proof__item,.wpbb-fun-fact',section));
      var pick=bestHost(section,cards);
      if(pick)markGrid(pick.host,pick.items,4,'wpbb-v137-stats-grid');
    });
  }

  function proofTitles(){
    return (Array.isArray(CFG.cards)?CFG.cards:[]).map(function(card){return String(card&&card.title||'').trim();}).filter(Boolean);
  }
  function markProof(){
    var expected=proofTitles();
    qa('#wp-theme-main .wpbb-sector-proof-band').forEach(function(section){
      var cards=topLevel(qa('.wpbb-sector-proof-card,.wpbb-v137-sector-proof-card,.wpbb-icon-card,.wp-theme-sector-card',section).filter(function(card){
        var h=q('h1,h2,h3,h4,h5,h6,.wpbb-icon-card__title,.wp-theme-sector-card__title',card);
        return card.classList.contains('wpbb-v137-sector-proof-card')||card.classList.contains('wpbb-sector-proof-card')||(h&&expected.indexOf(txt(h))!==-1);
      }));
      var pick=bestHost(section,cards);
      if(pick)markGrid(pick.host,pick.items,3,'wpbb-v137-proof-grid');
    });
  }

  function productCards(section){
    return topLevel(qa('.wpbb-catalogue-card,.product.type-product,.type-product.product,.product-card,.iws-product-card',section));
  }
  function markProducts(){
    qa('#wp-theme-main .wp-theme-home-product-catalogue').forEach(function(section){
      var cards=productCards(section);
      var pick=bestHost(section,cards);
      if(pick){
        markGrid(pick.host,pick.items,4,'wpbb-v137-product-grid');
        cards.forEach(function(card){card.classList.add('wpbb-v137-product-card');});
      }
      qa('h2,h3,h4',section).forEach(function(h){
        if(txt(h))return;
        var box=h.parentElement;
        if(box&&!q('article,.card,.wpbb-catalogue-card,img,form,button,input,select',box))box.classList.add('wpbb-v137-hidden');
        else h.classList.add('wpbb-v137-hidden');
      });
    });
  }

  function markFinder(){
    qa('#wp-theme-main .wpbb-sector-finder').forEach(function(finder){
      var direct=q('.wpbb-sector-grid',finder);
      if(direct){
        var items=kids(direct).filter(function(item){return txt(item)||q('.wpbb-sector-card,article,.card,img',item);});
        if(items.length>=2)markGrid(direct,items,3,'wpbb-v137-finder-grid');
        return;
      }
      var cards=topLevel(qa('.wpbb-sector-card,.wp-theme-sector-card',finder));
      var pick=bestHost(finder,cards);
      if(pick)markGrid(pick.host,pick.items,3,'wpbb-v137-finder-grid');
    });
  }

  function markEditorial(){
    qa('#wp-theme-main .wp-theme-insights-section .wp-block-post-template,#wp-theme-main .wp-theme-blog-preview-section .wp-block-post-template').forEach(function(host){
      var items=kids(host).filter(function(item){return txt(item)||q('article,img,a',item);});
      if(items.length>=2)markGrid(host,items,3,'wpbb-v137-blog-grid');
    });
    qa('#wp-theme-main .wp-theme-gallery-section').forEach(function(section){
      if(q('.swiper,.wpbb-swiper--gallery',section))return;
      var cards=topLevel(qa('.wp-theme-gallery-card',section));
      var pick=bestHost(section,cards);
      if(pick)markGrid(pick.host,pick.items,4,'wpbb-v137-gallery-grid');
    });
  }

  function removeDuplicateManagedFinder(){
    if(!D.body||!D.body.classList.contains('home'))return;
    var sections=qa('#wp-theme-main .wpbb-automotive-finder-section');
    if(sections.length>1)sections.slice(1).forEach(function(section){section.classList.add('wpbb-v137-hidden');});
  }

  function cleanArchiveDuplicateHeading(){
    var main=q('#wp-theme-main');
    if(!main)return;
    var hero=q('.wp-theme-inner-hero',main);
    var finder=q('.wpbb-sector-finder',main);
    if(!hero||!finder||norm(txt(hero)).indexOf('search new used and rental vehicles')===-1)return;
    qa('h1,h2,h3,h4,p,.wp-theme-sector-eyebrow',finder).forEach(function(el){
      var value=norm(txt(el));
      if(value==='search new used and rental vehicles'||value==='vehicle finder'||value==='filter stock by condition make type budget and fuel')el.classList.add('wpbb-v137-archive-duplicate-title');
    });
  }

  function run(){
    measureGrid();
    removeMalformedBlockText();
    replacePlaceholderCards();
    markSectionCards();
    markStats();
    markProof();
    markProducts();
    markFinder();
    markEditorial();
    removeDuplicateManagedFinder();
    cleanArchiveDuplicateHeading();
  }

  var timer=0;
  function schedule(){clearTimeout(timer);timer=W.setTimeout(run,40);}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
  W.addEventListener('load',function(){run();W.setTimeout(run,300);W.setTimeout(run,1100);});
  W.addEventListener('resize',function(){clearTimeout(timer);timer=W.setTimeout(run,100);},{passive:true});
  var main=q('#wp-theme-main');
  if(main&&W.MutationObserver){
    var stopTimer;
    var observer=new MutationObserver(function(ms){
      if(!ms.some(function(m){return m.addedNodes&&m.addedNodes.length;}))return;
      schedule();clearTimeout(stopTimer);stopTimer=W.setTimeout(function(){observer.disconnect();},4200);
    });
    observer.observe(main,{childList:true,subtree:true});
    stopTimer=W.setTimeout(function(){observer.disconnect();},4800);
  }
})(window,document);
