(function (W, D) {
  'use strict';

  var cfg = W.wpbbSuiteV131 || {};
  if (String(cfg.themeSlug || '').toLowerCase().indexOf('automotive') === -1) return;

  function qa(sel, root) {
    try { return Array.prototype.slice.call((root || D).querySelectorAll(sel)); }
    catch (e) { return []; }
  }
  function q(sel, root) {
    try { return (root || D).querySelector(sel); }
    catch (e) { return null; }
  }
  function norm(value) {
    return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function text(el) { return String(el && el.textContent || '').replace(/\s+/g, ' ').trim(); }
  function directChildren(el) { return el ? Array.prototype.slice.call(el.children || []) : []; }

  function markTheme() {
    if (D.body) D.body.classList.add('wpbb-v131-theme-automotive');
  }

  /* Old managed home imports can contain the vehicle finder twice. Keep the
     first real finder and hide later finder shells with the same heading. */
  function repairDuplicateFinder() {
    var finders = qa('#wp-theme-main .wpbb-sector-finder').filter(function (finder) {
      return norm(text(q('h1,h2,h3,.wp-theme-section-heading', finder))).indexOf('search new used and rental vehicles') !== -1 ||
        norm(text(finder)).indexOf('search new used and rental vehicles') !== -1;
    });
    if (finders.length > 1) {
      finders.slice(1).forEach(function (finder) { finder.classList.add('wpbb-v131-duplicate-finder'); });
      return;
    }

    /* Fallback for stale markup where the finder wrapper class was lost. */
    var headings = qa('#wp-theme-main h1,#wp-theme-main h2,#wp-theme-main h3').filter(function (heading) {
      return norm(text(heading)) === 'search new used and rental vehicles';
    });
    if (headings.length < 2) return;
    headings.slice(1).forEach(function (heading) {
      var shell = heading.closest('.wpbb-v67-section-inner,.wp-theme-section-shell,section');
      if (!shell) return;
      var t = norm(text(shell));
      if (t.indexOf('find vehicles') === -1 && t.indexOf('filter stock') === -1) return;
      shell.classList.add('wpbb-v131-duplicate-finder');
    });
  }

  function repairProcessBadges() {
    qa('#wp-theme-main .wp-theme-process-section,#wp-theme-main .wp-theme-sector-process-grid').forEach(function (section) {
      var badges = qa('.wp-theme-process-badge', section).slice(0, 3);
      badges.forEach(function (badge, idx) {
        badge.classList.add('wpbb-v131-process-badge');
        if (!norm(text(badge))) badge.textContent = String(idx + 1).padStart(2, '0');
      });
    });
  }

  function productCards(section) {
    return qa('.wpbb-catalogue-card,.product.type-product,.type-product.product,.product-card,.iws-product-card', section).filter(function (card, idx, arr) {
      return arr.indexOf(card) === idx;
    });
  }
  function chooseHost(section, cards) {
    var candidates = qa('.wpbb-v129-home-product-grid,.wpbb-v128-home-catalogue-grid,.row,.wpbb-row,ul.products,.products', section);
    var best = null;
    candidates.forEach(function (host) {
      var kids = directChildren(host).filter(function (kid) {
        return cards.some(function (card) { return kid === card || kid.contains(card); });
      });
      if (kids.length < 2) return;
      if (!best || kids.length > best.items.length) best = { host: host, items: kids };
    });
    return best;
  }
  function repairHomeCatalogue() {
    qa('#wp-theme-main .wp-theme-home-product-catalogue').forEach(function (section) {
      var cards = productCards(section);
      if (cards.length < 2) return;
      var pick = chooseHost(section, cards);
      if (!pick) return;
      pick.host.classList.add('wpbb-v131-home-product-grid');
      pick.items.forEach(function (item) { item.classList.add('wpbb-v131-home-product-cell'); });
      cards.forEach(function (card) { card.classList.add('wpbb-v131-home-product-card'); });
    });
  }

  function repairCompareControls() {
    var controls = qa('#wp-theme-main .iws-compare-open--search,#wp-theme-main .iws-compare-toggle,#wp-theme-main .iws-compare-button,#wp-theme-main .iws-product-compare-toggle');
    controls.forEach(function (control) { control.classList.add('wpbb-v131-compare-control'); });

    qa('#wp-theme-main .iws-compare-icon').forEach(function (icon) {
      var owner = icon.closest('.iws-compare-open--search,.iws-compare-toggle,.iws-compare-button,.iws-product-compare-toggle,button,a');
      if (owner) owner.classList.add('wpbb-v131-compare-control');
      else icon.classList.add('wpbb-v131-compare-control');
    });
  }

  function repairShopGrid() {
    qa('#wp-theme-main.wp-theme-woo-legacy--catalog ul.products,#wp-theme-main.wp-theme-woo-legacy--catalog .products').forEach(function (grid) {
      if (qa(':scope > li.product', grid).length > 1) grid.classList.add('wpbb-v131-shop-grid');
    });
  }

  function repairProductPage() {
    var main = q('#wp-theme-main.wp-theme-woo-legacy--product');
    if (!main) return;
    var product = q('.wpbb-complete-product', main);
    if (product) product.classList.add('wpbb-v131-product-page');
  }

  function repairCart() {
    qa('#wp-theme-main.wp-theme-woo-legacy--cart .woocommerce,.woocommerce-cart #wp-theme-main .woocommerce').forEach(function (wrap) {
      var form = q('.woocommerce-cart-form', wrap);
      var totals = q('.cart-collaterals', wrap);
      if (!form || !totals) return;
      wrap.classList.add('wpbb-v131-cart-owner');

      var shell = q(':scope > .wpbb-v131-cart-shell', wrap);
      if (!shell) {
        shell = D.createElement('div');
        shell.className = 'wpbb-v131-cart-shell';
        wrap.insertBefore(shell, form);
      }
      if (form.parentElement !== shell) shell.appendChild(form);
      if (totals.parentElement !== shell) shell.appendChild(totals);
    });
  }

  /* v130's first build removed the closest generic DIV when it found the
     newsletter sentence. On Checkout that DIV can be the whole payment/order
     panel. v131 only removes the exact field/label wrapper and never an
     ancestor that owns #payment or #order_review. */
  function safeCheckoutConsentCleanup() {
    qa('#wp-theme-main.wp-theme-woo-legacy--checkout form.checkout,.woocommerce-checkout #wp-theme-main form.checkout').forEach(function (form) {
      qa('.wpbb-v128-newsletter-consent,.wp-newslatter-campaigns-consent,.wp-newsletter-campaigns-consent', form).forEach(function (node) {
        var field = node.closest('.form-row,.woocommerce-form-row,label,p') || node;
        if (field && !field.contains(q('#payment', field)) && !field.contains(q('#order_review', field))) field.remove();
      });

      qa('label,p', form).forEach(function (node) {
        var value = norm(text(node));
        var isMarketing = value.indexOf('i agree to receive occasional email updates') !== -1 ||
          value.indexOf('i agree to receive email updates and can unsubscribe') !== -1 ||
          value.indexOf('send me wordpress newsletter updates') !== -1 ||
          value.indexOf('newsletter updates by email') !== -1;
        if (!isMarketing) return;
        var field = node.closest('.form-row,.woocommerce-form-row,label,p') || node;
        if (field && !q('#payment', field) && !q('#order_review', field)) field.remove();
      });

      form.classList.add('wpbb-v131-checkout-grid');
    });
  }

  function run() {
    markTheme();
    repairDuplicateFinder();
    repairProcessBadges();
    repairHomeCatalogue();
    repairCompareControls();
    repairShopGrid();
    repairProductPage();
    repairCart();
    safeCheckoutConsentCleanup();
  }

  var queued = false;
  function schedule() {
    if (queued) return;
    queued = true;
    W.setTimeout(function () { queued = false; run(); }, 20);
  }

  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', schedule, { once: true });
  else schedule();
  W.addEventListener('load', function () {
    run();
    W.setTimeout(run, 250);
    W.setTimeout(run, 900);
  });

  if (W.MutationObserver) {
    var observer = new MutationObserver(function (mutations) {
      if (!mutations.some(function (m) { return m.addedNodes && m.addedNodes.length; })) return;
      schedule();
    });
    observer.observe(D.documentElement, { childList: true, subtree: true });
  }
})(window, document);
