(function (W, D) {
  'use strict';

  var cfg = W.wpbbSuiteV129 || {};
  var raf = W.requestAnimationFrame || function (fn) { return W.setTimeout(fn, 16); };
  var slug = String(cfg.themeSlug || '').toLowerCase();
  if (slug.indexOf('automotive') === -1) return;

  function qa(sel, root) {
    try { return Array.prototype.slice.call((root || D).querySelectorAll(sel)); }
    catch (e) { return []; }
  }
  function q(sel, root) {
    try { return (root || D).querySelector(sel); }
    catch (e) { return null; }
  }
  function directChildren(el) { return el ? Array.prototype.slice.call(el.children || []) : []; }
  function norm(s) {
    return String(s || '').toLowerCase().replace(/[\u2013\u2014]/g, '-').replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function text(el) { return String(el && el.textContent || '').replace(/\s+/g, ' ').trim(); }
  function cardForCell(cell) {
    return q('.wp-theme-sector-card,.wpbb-icon-card,.wpbb-card,.card,[class*="card"]', cell) || cell.firstElementChild || cell;
  }
  function titleFor(card) {
    return q('.wpbb-icon-card__title,.card-title,h2,h3,h4,h5,h6,strong', card);
  }
  function bodyFor(card) {
    return q('.wpbb-icon-card__text,.card-text,p', card);
  }

  function markTheme() {
    if (D.body) D.body.classList.add('wpbb-v129-theme-automotive');
  }

  /* Explicit live row requested by ID. We repair the existing imported row
     in place rather than rebuilding the page or depending on generated IDs. */
  var AUTO_DEMO = [
    ['Vehicle discovery', 'Browse new, used and rental stock with useful filters for make, fuel, transmission and budget.'],
    ['Ownership services', 'Keep servicing, diagnostics, repair and rental enquiries connected to the same vehicle journey.'],
    ['Parts & accessories', 'Shop practical parts and accessories through the same WooCommerce basket, checkout and account.']
  ];

  function repairRow31() {
    var row = D.getElementById('wpbb-row-31');
    if (!row) return;
    var cells = directChildren(row).filter(function (el) {
      return el.nodeType === 1 && (el.matches('.wpbb-column,.wp-block-wpbb-column,[class*="col-"]') || q('.wp-theme-sector-card,.wpbb-icon-card,.wpbb-card,.card,[class*="card"]', el));
    });
    if (cells.length < 3) return;

    row.classList.add('wpbb-v129-auto-demo-grid');
    cells.slice(0, 3).forEach(function (cell, idx) {
      cell.classList.add('wpbb-v129-auto-demo-cell');
      var card = cardForCell(cell);
      if (!card) return;
      card.classList.add('wpbb-v129-auto-demo-card');
      var title = titleFor(card);
      var body = bodyFor(card);
      if (title) title.textContent = AUTO_DEMO[idx][0];
      if (body) body.textContent = AUTO_DEMO[idx][1];
    });
  }

  function processCellsFromBadges() {
    var badges = qa('.wpbb-badge.wp-theme-process-badge,.wp-block-wpbb-badge.wp-theme-process-badge,.wp-theme-process-badge.wpbb-badge');
    var cells = [];
    badges.forEach(function (badge) {
      var cell = badge.closest('.wpbb-column,.wp-block-wpbb-column,[class*="col-"]');
      if (!cell) return;
      if (cells.indexOf(cell) === -1) cells.push(cell);
      var card = q('.wp-theme-process-card,.wp-theme-sector-card,.wpbb-icon-card,.wpbb-card,.card', cell);
      if (!card) return;
      cell.classList.add('wpbb-v129-process-cell');
      card.classList.add('wpbb-v129-process-card');
      badge.classList.add('wpbb-v129-process-badge');

      // Put the badge inside the visual card so old absolute-position rules
      // cannot leave it floating outside or on top of the title.
      if (!card.contains(badge)) {
        var body = q('.card-body,.wpbb-icon-card__body,.wpbb-icon-card__content', card) || card;
        body.insertBefore(badge, body.firstChild || null);
      }
    });
    return cells;
  }

  function commonRow(cells) {
    if (cells.length < 3) return null;
    var counts = new Map();
    cells.forEach(function (cell) {
      var p = cell.parentElement;
      var depth = 0;
      while (p && p !== D.body && depth < 5) {
        counts.set(p, (counts.get(p) || 0) + 1);
        p = p.parentElement;
        depth++;
      }
    });
    var best = null;
    counts.forEach(function (count, el) {
      if (count >= 3 && (!best || best.contains(el))) best = el;
    });
    return best;
  }

  function repairProcessBadges() {
    var cells = processCellsFromBadges();
    if (cells.length >= 3) {
      var row = commonRow(cells.slice(0, 3));
      if (row) row.classList.add('wpbb-v129-process-grid');
    }

    // Also normalize modern generated process rows where the badge may already
    // be inside the card and no generic Bootstrap row class survives.
    qa('.wp-theme-process-section,.wp-theme-sector-process-grid').forEach(function (section) {
      var localBadges = qa('.wp-theme-process-badge', section).slice(0, 3);
      if (localBadges.length !== 3) return;
      var localCells = localBadges.map(function (badge) {
        return badge.closest('.wpbb-column,.wp-block-wpbb-column,[class*="col-"]') || badge.parentElement;
      }).filter(Boolean);
      localCells.forEach(function (cell) {
        cell.classList.add('wpbb-v129-process-cell');
        var card = cardForCell(cell);
        if (card) card.classList.add('wpbb-v129-process-card');
      });
      var row = commonRow(localCells);
      if (row) row.classList.add('wpbb-v129-process-grid');
      localBadges.forEach(function (badge) { badge.classList.add('wpbb-v129-process-badge'); });
    });
  }

  function productCards(section) {
    return qa('.wpbb-catalogue-card,.product.type-product,.type-product.product,.product-card,.iws-product-card', section).filter(function (card, idx, arr) {
      return arr.indexOf(card) === idx;
    });
  }

  function chooseProductHost(section, cards) {
    if (cards.length < 2) return null;
    var cardSet = new Set(cards);
    var node = cards[0].parentElement;
    var candidates = [];
    while (node && node !== section.parentElement && node !== D.body) {
      var kids = directChildren(node);
      var productKids = kids.filter(function (kid) {
        var found = cards.filter(function (card) { return kid === card || kid.contains(card); });
        return found.length === 1;
      });
      if (productKids.length >= 2) candidates.push({ host: node, items: productKids, score: productKids.length });
      if (node === section) break;
      node = node.parentElement;
    }
    if (!candidates.length) {
      var rows = qa('.row,.wpbb-row,ul.products,.products', section);
      rows.forEach(function (row) {
        var kids = directChildren(row);
        var items = kids.filter(function (kid) { return cards.some(function (card) { return kid === card || kid.contains(card); }); });
        if (items.length >= 2) candidates.push({ host: row, items: items, score: items.length });
      });
    }
    if (!candidates.length) return null;
    candidates.sort(function (a, b) { return b.score - a.score; });
    return candidates[0];
  }

  function repairHomeCatalogue() {
    qa('.wp-theme-home-product-catalogue').forEach(function (section) {
      var cards = productCards(section);
      if (cards.length < 2) return;
      var pick = chooseProductHost(section, cards);
      if (!pick) return;
      pick.host.classList.add('wpbb-v129-home-product-grid');
      pick.items.forEach(function (item) { item.classList.add('wpbb-v129-home-product-cell'); });
      cards.forEach(function (card) { card.classList.add('wpbb-v129-home-product-card'); });
    });
  }

  function run() {
    markTheme();
    repairRow31();
    repairProcessBadges();
    repairHomeCatalogue();
  }

  var queued = false;
  function schedule() {
    if (queued) return;
    queued = true;
    raf(function () {
      queued = false;
      run();
    });
  }

  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', schedule, { once: true });
  else schedule();
  W.addEventListener('load', function () { schedule(); W.setTimeout(schedule, 300); W.setTimeout(schedule, 1000); });
  if (W.MutationObserver) {
    var observer = new MutationObserver(function (mutations) {
      if (mutations.some(function (m) { return m.addedNodes && m.addedNodes.length; })) schedule();
    });
    observer.observe(D.documentElement, { childList: true, subtree: true });
  }
})(window, document);
