(function(W,D){
  'use strict';
  var cfg=W.wpbbAutoV133||{};
  var urls=Array.isArray(cfg.heroUrls)?cfg.heroUrls.filter(Boolean):[];
  var process=Array.isArray(cfg.process)?cfg.process:[];
  function q(s,r){try{return(r||D).querySelector(s);}catch(e){return null;}}
  function qa(s,r){try{return Array.prototype.slice.call((r||D).querySelectorAll(s));}catch(e){return[];}}
  function kids(n){return n?Array.prototype.slice.call(n.children||[]):[];}
  function txt(n){return String(n&&n.textContent||'').replace(/\s+/g,' ').trim();}
  function norm(v){return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();}
  function mark(){if(D.body)D.body.classList.add('wpbb-v133-theme-automotive');}

  function finderOwner(h){
    var n=h, best=null, depth=0;
    while(n&&n!==D.body&&depth<8){
      var controls=qa('input,select,button,form',n).length;
      var same=qa('h1,h2,h3,h4',n).filter(function(x){return norm(txt(x))==='search new used and rental vehicles';}).length;
      if(controls>=3&&same===1)best=n;
      if(best&&n.classList&&(n.classList.contains('wpbb-sector-finder')||n.classList.contains('wp-theme-section-shell')||n.tagName==='SECTION'))break;
      n=n.parentElement;depth++;
    }
    return best||h.parentElement;
  }
  function repairDuplicateFinder(){
    var hs=qa('#wp-theme-main h1,#wp-theme-main h2,#wp-theme-main h3,#wp-theme-main h4').filter(function(h){return norm(txt(h))==='search new used and rental vehicles';});
    if(hs.length>1){
      hs.slice(1).forEach(function(h){var o=finderOwner(h);if(o)o.classList.add('wpbb-v133-duplicate-finder');});
    }
    var finders=qa('#wp-theme-main .wpbb-sector-finder');
    if(finders.length>1)finders.slice(1).forEach(function(f){f.classList.add('wpbb-v133-duplicate-finder');});
  }

  var ROW31=[
    ['Vehicle discovery','Browse new, used and rental stock with useful filters for make, fuel, transmission and budget.'],
    ['Ownership services','Keep servicing, diagnostics, repair and rental enquiries connected to the same vehicle journey.'],
    ['Parts & accessories','Shop practical parts and accessories through the same WooCommerce basket, checkout and account.']
  ];
  function repairRow31(){
    var row=D.getElementById('wpbb-row-31');if(!row)return;
    row.classList.add('wpbb-v133-row31');
    kids(row).filter(function(x){return x.nodeType===1;}).slice(0,3).forEach(function(cell,i){
      var card=q('.wp-theme-sector-card,.wpbb-icon-card,.wpbb-card,.card,[class*="card"]',cell)||cell.firstElementChild||cell;
      if(!card)return;card.classList.add('wpbb-v133-row31-card');
      qa('.wpbb-badge,.wp-theme-process-badge,[class*="process-badge"],[class*="step-badge"]',card).forEach(function(n){n.remove();});
      var title=q('.wpbb-icon-card__title,.card-title,h2,h3,h4,h5,h6,strong',card);
      var body=q('.wpbb-icon-card__text,.card-text,p',card);
      if(title)title.textContent=ROW31[i][0];
      if(body)body.textContent=ROW31[i][1];
    });
  }

  function directBestRow(section,selector){
    var best=null,score=0;
    qa('.row,.wpbb-row',section).forEach(function(row){
      var c=qa(selector,row).length;
      if(c>score){score=c;best=row;}
    });
    return best;
  }
  function repairStats(){
    qa('#wp-theme-main .wp-theme-home-stats').forEach(function(section){
      var row=directBestRow(section,'.wpbb-fun-fact,.wp-theme-sector-proof__item');
      if(row)row.classList.add('wpbb-v133-stats-grid');
    });
  }

  function rebuildProcess(){
    if(!process.length)return;
    qa('#wp-theme-main .wp-theme-process-section').forEach(function(section){
      if(q('.wpbb-v133-process-grid',section))return;
      qa('.row,.wpbb-row',section).forEach(function(row){
        if(qa('.wp-theme-process-card,.wp-theme-process-badge,[class*="process-badge"]',row).length)row.classList.add('wpbb-v133-process-source');
      });
      var grid=D.createElement('div');grid.className='wpbb-v133-process-grid';
      process.slice(0,3).forEach(function(item){
        var card=D.createElement('article');card.className='wpbb-v133-process-card';
        var b=D.createElement('span');b.className='wpbb-v133-process-badge';b.textContent=item[0]||'';
        var h=D.createElement('h3');h.textContent=item[1]||'';
        var p=D.createElement('p');p.textContent=item[2]||'';
        card.appendChild(b);card.appendChild(h);card.appendChild(p);grid.appendChild(card);
      });
      var heading=q('.wp-theme-section-heading',section);
      if(heading&&heading.parentNode)heading.parentNode.insertBefore(grid,heading.nextSibling);else section.appendChild(grid);
    });
  }

  function uniqueCards(section){
    var arr=qa('.wpbb-catalogue-card,.product.type-product,.type-product.product,.product-card,.iws-product-card',section);
    return arr.filter(function(c,i,a){return a.indexOf(c)===i&&!a.some(function(o){return o!==c&&o.contains(c);});});
  }
  function rebuildCatalogue(){
    qa('#wp-theme-main .wp-theme-home-product-catalogue').forEach(function(section){
      var existing=q(':scope > .wpbb-v133-catalogue-grid',section);if(existing)return;
      var cards=uniqueCards(section);if(cards.length<2)return;
      var grid=D.createElement('div');grid.className='wpbb-v133-catalogue-grid';
      var anchor=cards[0];var oldParents=[];
      cards.forEach(function(card){
        var p=card.parentElement;if(p&&oldParents.indexOf(p)===-1)oldParents.push(p);
        card.classList.add('wpbb-v133-catalogue-card');grid.appendChild(card);
      });
      section.appendChild(grid);
      oldParents.forEach(function(p){if(p&&p!==section&&!txt(p)&&!q('img,a,button,input,select',p))p.classList.add('wpbb-v133-empty-shell');});
    });
  }

  function heroSlides(hero){
    var arr=qa('.wpbb-swiper-slide--hero,.swiper-slide',hero).filter(function(s){return !s.classList.contains('swiper-slide-duplicate');});
    return arr.filter(function(x,i,a){return a.indexOf(x)===i;});
  }
  function repairHero(){
    qa('#wp-theme-main .wpbb-swiper--hero,#wp-theme-main .wp-theme-sector-hero .swiper').forEach(function(hero){
      hero.classList.add('wpbb-v133-hero');
      var slides=heroSlides(hero);
      slides.forEach(function(slide,i){
        var img=q('.wpbb-swiper-slide__media img,.wp-theme-hero__media img,img',slide);
        if(img&&urls.length){var u=urls[i%urls.length];img.src=u;img.removeAttribute('srcset');img.removeAttribute('sizes');img.setAttribute('fetchpriority',i===0?'high':'auto');}
      });
      if(q('.wpbb-v133-hero-pagination',hero))return;
      var count=Math.max(3,slides.length);var p=D.createElement('div');p.className='wpbb-v133-hero-pagination';
      for(var i=0;i<count;i++)(function(idx){
        var b=D.createElement('button');b.type='button';b.className='wpbb-v133-hero-bullet'+(idx===0?' is-active':'');b.setAttribute('aria-label','Go to slide '+(idx+1));
        b.addEventListener('click',function(){
          var sw=hero.swiper||(q('.swiper',hero)&&q('.swiper',hero).swiper);
          if(sw&&typeof sw.slideToLoop==='function')sw.slideToLoop(idx);else if(sw&&typeof sw.slideTo==='function')sw.slideTo(idx);
          qa('.wpbb-v133-hero-bullet',p).forEach(function(x,j){x.classList.toggle('is-active',j===idx);});
        });p.appendChild(b);
      })(i);
      hero.appendChild(p);
      var sw=hero.swiper||(q('.swiper',hero)&&q('.swiper',hero).swiper);
      if(sw&&typeof sw.on==='function')sw.on('slideChange',function(){var ai=Number.isFinite(sw.realIndex)?sw.realIndex:sw.activeIndex;qa('.wpbb-v133-hero-bullet',p).forEach(function(x,j){x.classList.toggle('is-active',j===((ai%count)+count)%count);});});
    });
  }

  function run(){mark();repairDuplicateFinder();repairRow31();repairStats();rebuildProcess();rebuildCatalogue();repairHero();}
  var queued=false;function schedule(){if(queued)return;queued=true;W.setTimeout(function(){queued=false;run();},35);}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
  W.addEventListener('load',function(){run();W.setTimeout(run,300);W.setTimeout(run,1100);});
  if(W.MutationObserver)new MutationObserver(function(ms){if(ms.some(function(m){return m.addedNodes&&m.addedNodes.length;}))schedule();}).observe(D.documentElement,{childList:true,subtree:true});
})(window,document);
