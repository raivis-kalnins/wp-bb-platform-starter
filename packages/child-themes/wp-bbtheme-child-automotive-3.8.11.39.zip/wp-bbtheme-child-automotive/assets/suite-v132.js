(function(W,D){
  'use strict';
  var cfg=W.wpbbSuiteV132||{};
  if(String(cfg.themeSlug||'').toLowerCase().indexOf('automotive')===-1)return;
  function qa(sel,root){try{return Array.prototype.slice.call((root||D).querySelectorAll(sel));}catch(e){return[];}}
  function q(sel,root){try{return(root||D).querySelector(sel);}catch(e){return null;}}
  function norm(v){return String(v||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();}
  function txt(el){return String(el&&el.textContent||'').replace(/\s+/g,' ').trim();}
  function kids(el){return el?Array.prototype.slice.call(el.children||[]):[];}
  function markTheme(){if(D.body)D.body.classList.add('wpbb-v132-theme-automotive');}

  function nearestSection(el){
    if(!el)return null;
    return el.closest('.wpbb-sector-finder,.wp-theme-section-shell,.wpbb-v67-section-inner,.wp-block-group,section,.wpbb-row,.row')||el.parentElement;
  }
  function repairDuplicateFinder(){
    var heads=qa('#wp-theme-main h1,#wp-theme-main h2,#wp-theme-main h3,#wp-theme-main h4').filter(function(h){
      return norm(txt(h)).indexOf('search new used and rental vehicles')!==-1;
    });
    if(heads.length<2){
      var finders=qa('#wp-theme-main .wpbb-sector-finder');
      if(finders.length>1)finders.slice(1).forEach(function(x){x.classList.add('wpbb-v132-duplicate-finder');});
      return;
    }
    var firstShell=nearestSection(heads[0]);
    heads.slice(1).forEach(function(h){
      var shell=nearestSection(h);
      if(shell&&shell!==firstShell)shell.classList.add('wpbb-v132-duplicate-finder');
      else if(h.parentElement)h.parentElement.classList.add('wpbb-v132-duplicate-finder');
    });
  }

  var ROW31=[
    ['Vehicle discovery','Browse new, used and rental stock with useful filters for make, fuel, transmission and budget.'],
    ['Ownership services','Keep servicing, diagnostics, repair and rental enquiries connected to the same vehicle journey.'],
    ['Parts & accessories','Shop practical parts and accessories through the same WooCommerce basket, checkout and account.']
  ];
  function repairRow31(){
    var row=D.getElementById('wpbb-row-31'); if(!row)return;
    row.classList.add('wpbb-v132-row31');
    var cells=kids(row).filter(function(el){return el.nodeType===1;}).slice(0,3);
    cells.forEach(function(cell,i){
      var card=q('.wp-theme-sector-card,.wpbb-icon-card,.wpbb-card,.card,[class*="card"]',cell)||cell.firstElementChild||cell;
      if(!card)return;
      var title=q('.wpbb-icon-card__title,.card-title,h2,h3,h4,h5,h6,strong',card);
      var body=q('.wpbb-icon-card__text,.card-text,p',card);
      if(title)title.textContent=ROW31[i][0];
      if(body)body.textContent=ROW31[i][1];
    });
  }

  function commonHost(cells){
    if(cells.length<2)return null;
    var node=cells[0].parentElement,best=null,depth=0;
    while(node&&node!==D.body&&depth<6){
      var direct=kids(node).filter(function(k){return cells.some(function(c){return k===c||k.contains(c);});});
      if(direct.length>=Math.min(3,cells.length)){best=node;break;}
      node=node.parentElement;depth++;
    }
    return best;
  }
  function repairProcess(){
    qa('#wp-theme-main .wp-theme-process-section,#wp-theme-main .wp-theme-sector-process-grid').forEach(function(section){
      var badges=qa('.wp-theme-process-badge',section).slice(0,3); if(!badges.length)return;
      var cells=[];
      badges.forEach(function(b,i){
        b.classList.add('wpbb-v132-process-badge');
        if(!txt(b)||txt(b).length>4)b.textContent=String(i+1).padStart(2,'0');
        var cell=b.closest('.wpbb-column,.wp-block-wpbb-column,[class*="col-"]')||b.parentElement;
        if(cell&&cells.indexOf(cell)===-1)cells.push(cell);
        var card=cell&&(q('.wp-theme-process-card,.wp-theme-sector-card,.wpbb-icon-card,.wpbb-card,.card',cell)||cell.firstElementChild);
        if(card){card.classList.add('wpbb-v132-process-card');if(!card.contains(b))card.insertBefore(b,card.firstChild||null);}
      });
      var host=commonHost(cells)||q('.row,.wpbb-row',section); if(host)host.classList.add('wpbb-v132-process-grid');
    });
  }

  function productCards(section){
    return qa('.wpbb-catalogue-card,.product.type-product,.type-product.product,.product-card,.iws-product-card',section).filter(function(c,i,a){return a.indexOf(c)===i;});
  }
  function productHost(section,cards){
    var candidates=[];
    qa('.row,.wpbb-row,ul.products,.products',section).forEach(function(host){
      var direct=kids(host).filter(function(k){return cards.some(function(c){return k===c||k.contains(c);});});
      if(direct.length>=2)candidates.push({host:host,count:direct.length});
    });
    if(candidates.length){candidates.sort(function(a,b){return b.count-a.count;});return candidates[0].host;}
    var p=cards[0]&&cards[0].parentElement,depth=0;
    while(p&&p!==section.parentElement&&depth<6){
      if(kids(p).filter(function(k){return cards.some(function(c){return k===c||k.contains(c);});}).length>=2)return p;
      p=p.parentElement;depth++;
    }
    return null;
  }
  function repairCatalogue(){
    qa('#wp-theme-main .wp-theme-home-product-catalogue').forEach(function(section){
      var cards=productCards(section); if(cards.length<2)return;
      var host=productHost(section,cards); if(host)host.classList.add('wpbb-v132-product-grid');
      cards.forEach(function(c){c.classList.add('wpbb-v132-product-card');});
    });
  }

  function repairShop(){
    qa('#wp-theme-main.wp-theme-woo-legacy--catalog ul.products,#wp-theme-main.wp-theme-woo-legacy--catalog .products').forEach(function(g){if(qa(':scope > li.product',g).length>1)g.classList.add('wpbb-v132-shop-grid');});
    qa('#wp-theme-main .iws-compare-icon').forEach(function(icon){icon.setAttribute('aria-hidden','true');});
  }

  function repairCart(){
    var main=q('#wp-theme-main.wp-theme-woo-legacy--cart');if(!main)return;
    var wrap=q('.woocommerce',main);if(!wrap)return;
    var form=q('.woocommerce-cart-form',wrap),tot=q('.cart-collaterals',wrap);
    if(form)form.classList.add('wpbb-v132-cart-form');
    if(tot)tot.classList.add('wpbb-v132-cart-totals');
  }

  function safeCheckout(){
    var main=q('#wp-theme-main.wp-theme-woo-legacy--checkout');if(!main)return;
    var form=q('form.checkout.woocommerce-checkout',main);if(!form)return;
    qa('.wpbb-v128-newsletter-consent,.wp-newslatter-campaigns-consent,.wp-newsletter-campaigns-consent,[class*="newsletter"][class*="consent"],[class*="newslatter"][class*="consent"]',form).forEach(function(n){
      var box=n.closest('.form-row,.woocommerce-form-row,label,p')||n;
      if(box&&!q('#payment,#order_review',box))box.remove();
    });
    qa('label,p',form).forEach(function(n){
      var v=norm(txt(n));
      if(v.indexOf('i agree to receive occasional email updates')===-1&&v.indexOf('send me wordpress newsletter updates')===-1&&v.indexOf('newsletter updates by email')===-1)return;
      var box=n.closest('.form-row,.woocommerce-form-row,label,p')||n;
      if(box&&!q('#payment,#order_review',box))box.remove();
    });
  }

  function run(){markTheme();repairDuplicateFinder();repairRow31();repairProcess();repairCatalogue();repairShop();repairCart();safeCheckout();}
  var queued=false;function schedule(){if(queued)return;queued=true;W.setTimeout(function(){queued=false;run();},20);}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
  W.addEventListener('load',function(){run();W.setTimeout(run,250);W.setTimeout(run,900);});
  if(W.MutationObserver){new MutationObserver(function(ms){if(ms.some(function(m){return m.addedNodes&&m.addedNodes.length;}))schedule();}).observe(D.documentElement,{childList:true,subtree:true});}
})(window,document);
