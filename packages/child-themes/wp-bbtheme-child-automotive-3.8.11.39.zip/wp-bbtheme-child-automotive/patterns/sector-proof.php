<?php
/**
 * Title: Automotive Dealer & Parts proof band
 * Slug: wp-bbtheme-child-automotive/sector-proof
 * Categories: wp-patterns-main, wp-theme-current
 */
?>
<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wpbb-sector-proof-band"} -->
<!-- wp:wpbb/row {"containerClass":"container","gutterX":"gx-4","gutterY":"gy-4"} -->
<!-- wp:wpbb/column {"xs":12,"md":4} -->
<!-- wp:wpbb/icon-card {"mediaType":"svg","svgCode":"<svg viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"12\" cy=\"12\" r=\"8\"/><path d=\"M8 12h8M12 8v8\"/></svg>","title":"Vehicle discovery","text":"Browse new, used and rental stock with useful filters for make, fuel, transmission and budget.","iconSize":"48px","contentAlign":"left","autoTextColor":true,"boxShadowClass":"shadow-sm","className":"wpbb-sector-proof-card"} /-->
<!-- /wp:wpbb/column -->
<!-- wp:wpbb/column {"xs":12,"md":4} -->
<!-- wp:wpbb/icon-card {"mediaType":"svg","svgCode":"<svg viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"12\" cy=\"12\" r=\"8\"/><path d=\"M8 12h8M12 8v8\"/></svg>","title":"Ownership services","text":"Keep servicing, diagnostics, repair and rental enquiries connected to the same vehicle journey.","iconSize":"48px","contentAlign":"left","autoTextColor":true,"boxShadowClass":"shadow-sm","className":"wpbb-sector-proof-card"} /-->
<!-- /wp:wpbb/column -->
<!-- wp:wpbb/column {"xs":12,"md":4} -->
<!-- wp:wpbb/icon-card {"mediaType":"svg","svgCode":"<svg viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"12\" cy=\"12\" r=\"8\"/><path d=\"M8 12h8M12 8v8\"/></svg>","title":"Parts & accessories","text":"Shop practical parts and accessories through the same WooCommerce basket, checkout and account.","iconSize":"48px","contentAlign":"left","autoTextColor":true,"boxShadowClass":"shadow-sm","className":"wpbb-sector-proof-card"} /-->
<!-- /wp:wpbb/column -->
<!-- /wp:wpbb/row -->
<!-- /wp:wpbb/bootstrap-div -->
