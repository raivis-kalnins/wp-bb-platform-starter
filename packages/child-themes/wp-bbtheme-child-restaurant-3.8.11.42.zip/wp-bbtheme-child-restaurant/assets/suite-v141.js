/* Restaurant 3.8.11.41 - Events-parity measurement and scoped grid ownership. */
(function(W,D){
  'use strict';
  var ROOT=D.documentElement;
  function q(sel,root){try{return(root||D).querySelector(sel);}catch(e){return null;}}
  function qa(sel,root){try{return Array.prototype.slice.call((root||D).querySelectorAll(sel));}catch(e){return[];}}
  function kids(el){return el?Array.prototype.slice.call(el.children||[]):[];}
  function unique(arr){return arr.filter(function(x,i,a){return x&&a.indexOf(x)===i;});}
  function topLevel(arr){return unique(arr).filter(function(item){return !arr.some(function(other){return other!==item&&other.contains&&other.contains(item);});});}

  function measureGrid(){
    var candidates=[
      q('.wp-theme-header-main > .container'),
      q('.wp-theme-header-main .container'),
      q('.wp-theme-site-header .container'),
      q('.wp-theme-footer-main > .container'),
      q('.wp-theme-site-footer .container')
    ].filter(Boolean);
    var best=null;
    candidates.some(function(el){
      var r=el.getBoundingClientRect();
      if(r.width>320&&r.width<=W.innerWidth+2){best=r;return true;}
      return false;
    });
    if(!best)return;
    ROOT.style.setProperty('--wpbb-v141-left',Math.max(16,Math.round(best.left))+'px');
    ROOT.style.setProperty('--wpbb-v141-right',Math.max(16,Math.round(W.innerWidth-best.right))+'px');
  }

  function bestHost(scope,cards){
    cards=topLevel(cards||[]);if(!scope||cards.length<2)return null;
    var candidates=unique(cards.reduce(function(out,card){
      var node=card;
      for(var depth=0;node&&node!==scope&&depth<6;depth++,node=node.parentElement){
        if(node.matches&&node.matches('.row,.wpbb-row,.wpbb-v62-card-grid,.wpbb-sector-grid,.wp-block-post-template'))out.push(node);
      }
      return out;
    },[]));
    var best=null;
    candidates.forEach(function(host){
      var direct=kids(host).filter(function(child){return cards.some(function(card){return child===card||child.contains(card);});});
      if(direct.length<2)return;
      if(!best||direct.length>best.items.length)best={host:host,items:direct};
    });
    if(best)return best;
    var parent=cards[0].parentElement;
    if(parent&&cards.every(function(card){return card.parentElement===parent;}))return{host:parent,items:cards.slice()};
    return null;
  }

  function markGrid(host,items,cols,extra){
    if(!host||!items||items.length<2)return;
    host.classList.add('wpbb-v141-grid','wpbb-v141-cols-'+Math.max(2,Math.min(4,cols||items.length)));
    if(extra)host.classList.add(extra);
    items.forEach(function(item){item.classList.add('wpbb-v141-grid-cell');});
  }

  function markSectionCards(){
    var groups=[
      ['.wp-theme-services-section','.wp-theme-sector-card,.wpbb-icon-card',4],
      ['.wp-theme-industries-section','.wp-theme-sector-card,.wpbb-icon-card',4],
      ['.wp-theme-process-section','.wp-theme-process-card,.wp-theme-sector-card,.wpbb-icon-card',3]
    ];
    groups.forEach(function(group){
      qa('#wp-theme-main '+group[0]).forEach(function(section){
        var cards=topLevel(qa(group[1],section)),pick=bestHost(section,cards);
        if(pick)markGrid(pick.host,pick.items,group[2]);
      });
    });
  }

  function markStats(){
    qa('#wp-theme-main .wp-theme-home-stats,#wp-theme-main .wp-theme-sector-proof').forEach(function(section){
      var cards=topLevel(qa('.wp-theme-sector-proof__item,.wpbb-fun-fact',section)),pick=bestHost(section,cards);
      if(pick)markGrid(pick.host,pick.items,4,'wpbb-v141-stats-grid');
    });
  }

  function markEditorial(){
    qa('#wp-theme-main .wp-theme-insights-section .wp-block-post-template,#wp-theme-main .wp-theme-blog-preview-section .wp-block-post-template,#wp-theme-main .wp-theme-blog-section .wp-block-post-template').forEach(function(host){
      var items=kids(host).filter(function(item){return item.textContent.trim()||q('article,img,a',item);});
      if(items.length>=2)markGrid(host,items,3,'wpbb-v141-blog-grid');
    });
  }

  function run(){
    if(D.body)D.body.classList.add('wpbb-v141');
    measureGrid();markSectionCards();markStats();markEditorial();
  }
  var timer=0;
  function schedule(){clearTimeout(timer);timer=W.setTimeout(run,40);}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
  W.addEventListener('load',function(){run();W.setTimeout(run,350);});
  W.addEventListener('resize',function(){clearTimeout(timer);timer=W.setTimeout(run,100);},{passive:true});
})(window,document);
