/* Restaurant 3.8.11.42 - direct HQ hero sources + deterministic hero pager. */
(function(W,D){
  'use strict';
  var CFG=W.wpbbSuiteV142||{};
  function q(sel,root){try{return(root||D).querySelector(sel);}catch(e){return null;}}
  function qa(sel,root){try{return Array.prototype.slice.call((root||D).querySelectorAll(sel));}catch(e){return[];}}
  function heroBlocks(){return qa('#wp-theme-main .wpbb-swiper--hero');}
  function swiperEl(block){return block&&(block.matches&&block.matches('.swiper')?block:q('.swiper',block));}
  function liveSwiper(block,el){return(el&&el.swiper)||(block&&block.swiper)||null;}
  function uniqueSlides(el){
    if(!el)return[];
    var slides=qa('.swiper-wrapper > .swiper-slide',el);if(!slides.length)slides=qa('.swiper-slide',el);
    var seen={},out=[];
    slides.forEach(function(slide,index){
      if(slide.classList.contains('swiper-slide-duplicate'))return;
      var raw=slide.getAttribute('data-swiper-slide-index');
      var key=(raw===null||raw==='')?'dom-'+index:String(raw);
      if(seen[key])return;seen[key]=1;out.push(slide);
    });
    return out.length?out:slides;
  }
  function slideIndex(slide,domIndex,count){
    var raw=slide.getAttribute('data-swiper-slide-index'),i=parseInt(raw,10);
    if(!isFinite(i)||i<0)i=domIndex;
    return count?i%count:i;
  }
  function activeIndex(sw,count){
    if(!count)return 0;
    var n=sw&&typeof sw.realIndex==='number'?sw.realIndex:(sw&&typeof sw.activeIndex==='number'?sw.activeIndex:0);
    n=parseInt(n,10);if(!isFinite(n)||n<0)n=0;return n%count;
  }
  function forceSources(block){
    var el=swiperEl(block),urls=Array.isArray(CFG.heroUrls)?CFG.heroUrls.filter(Boolean):[];
    if(!el||!urls.length)return;
    var slides=qa('.swiper-wrapper > .swiper-slide',el);if(!slides.length)slides=qa('.swiper-slide',el);
    slides.forEach(function(slide,domIndex){
      var img=q('.wpbb-swiper-slide__media img',slide);if(!img)return;
      var i=slideIndex(slide,domIndex,urls.length),wanted=urls[i];if(!wanted)return;
      if(img.getAttribute('src')!==wanted)img.setAttribute('src',wanted);
      ['srcset','sizes','data-src','data-srcset','data-sizes'].forEach(function(name){img.removeAttribute(name);});
      var picture=img.parentElement&&img.parentElement.tagName==='PICTURE'?img.parentElement:null;
      if(picture)qa('source',picture).forEach(function(source){source.setAttribute('srcset',wanted);source.removeAttribute('sizes');});
      img.decoding='async';img.loading=i===0?'eager':'lazy';
      if(i===0){try{img.fetchPriority='high';}catch(e){img.setAttribute('fetchpriority','high');}}
    });
  }
  function paintPager(pager,sw,count){
    var active=activeIndex(sw,count);
    qa('.wpbb-v142-hero-pagination__bullet',pager).forEach(function(button,index){
      var on=index===active;button.classList.toggle('is-active',on);
      if(on)button.setAttribute('aria-current','true');else button.removeAttribute('aria-current');
    });
  }
  function ensurePager(block){
    var el=swiperEl(block);if(!el)return;
    var count=uniqueSlides(el).length;if(count<2)return;
    var pager=q(':scope > .wpbb-v142-hero-pagination',el);
    if(!pager){
      pager=D.createElement('div');pager.className='wpbb-v142-hero-pagination';
      pager.setAttribute('role','group');pager.setAttribute('aria-label','Hero slides');el.appendChild(pager);
    }
    if(pager.children.length!==count){
      pager.innerHTML='';
      for(var i=0;i<count;i++){
        var b=D.createElement('button');b.type='button';b.className='wpbb-v142-hero-pagination__bullet';
        b.setAttribute('data-wpbb-v142-slide',String(i));
        b.setAttribute('aria-label','Go to hero slide '+(i+1)+' of '+count);
        pager.appendChild(b);
      }
    }
    if(!pager.dataset.wpbbV142PagerBound){
      pager.dataset.wpbbV142PagerBound='1';
      pager.addEventListener('click',function(event){
        var button=event.target&&event.target.closest?event.target.closest('[data-wpbb-v142-slide]'):null;if(!button)return;
        var index=parseInt(button.getAttribute('data-wpbb-v142-slide'),10)||0,sw=liveSwiper(block,swiperEl(block));
        if(sw){try{if(typeof sw.slideToLoop==='function')sw.slideToLoop(index);else if(typeof sw.slideTo==='function')sw.slideTo(index);}catch(e){}}
        paintPager(pager,sw,count);
      });
    }
    var sw=liveSwiper(block,el);
    if(sw&&pager._wpbbV142Swiper!==sw){
      pager._wpbbV142Swiper=sw;
      if(typeof sw.on==='function'){
        var update=function(){paintPager(pager,sw,count);};
        try{sw.on('slideChange',update);sw.on('realIndexChange',update);sw.on('transitionEnd',update);}catch(e){}
      }
    }
    paintPager(pager,sw,count);
  }
  function tune(block){forceSources(block);ensurePager(block);}
  function run(){if(D.body)D.body.classList.add('wpbb-v142');heroBlocks().forEach(tune);}
  var timer=0;function schedule(delay){clearTimeout(timer);timer=W.setTimeout(run,typeof delay==='number'?delay:40);}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',function(){run();[120,420,900,1700].forEach(function(ms){W.setTimeout(run,ms);});},{once:true});
  else{run();[120,420,900,1700].forEach(function(ms){W.setTimeout(run,ms);});}
  W.addEventListener('load',function(){run();W.setTimeout(run,500);},{once:true});
  W.addEventListener('resize',function(){schedule(90);},{passive:true});
  if(W.MutationObserver){
    var queued=false,observer=new MutationObserver(function(ms){
      if(!ms.some(function(m){return(m.addedNodes&&m.addedNodes.length)||(m.type==='attributes');}))return;
      if(queued)return;queued=true;W.setTimeout(function(){queued=false;run();},70);
    });
    var root=q('#wp-theme-main')||D.body||D.documentElement;
    if(root)observer.observe(root,{childList:true,subtree:true,attributes:true,attributeFilter:['src','srcset','class']});
    W.setTimeout(function(){observer.disconnect();},8000);
  }
})(window,document);
