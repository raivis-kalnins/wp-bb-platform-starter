(function(W,D){
  'use strict';
  var cfg=W.wpbbSuiteV137||{};
  var heroUrls=Array.isArray(cfg.heroUrls)?cfg.heroUrls.filter(Boolean):[];
  var fallback=Array.isArray(cfg.fallbackCards)?cfg.fallbackCards:[];
  var theme=String(cfg.themeKey||'restaurant');
  function q(s,r){try{return(r||D).querySelector(s);}catch(e){return null;}}
  function qa(s,r){try{return Array.prototype.slice.call((r||D).querySelectorAll(s));}catch(e){return[];}}
  function kids(n){return n?Array.prototype.slice.call(n.children||[]):[];}
  function txt(n){return String(n&&n.textContent||'').replace(/\s+/g,' ').trim();}
  function norm(s){return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();}
  function uniq(a){return a.filter(function(x,i){return x&&a.indexOf(x)===i;});}
  function hide(n){if(n&&n.classList)n.classList.add('wpbb-v137-hidden');}
  function mark(){if(D.body)D.body.classList.add('wpbb-v137','wpbb-v137-theme-'+theme.replace(/[^a-z0-9_-]/gi,'-'));}

  function removeMalformedBlockText(){
    var main=q('#wp-theme-main');if(!main||!D.createTreeWalker)return;
    var walker=D.createTreeWalker(main,NodeFilter.SHOW_TEXT),n,remove=[];
    while((n=walker.nextNode())){var t=String(n.nodeValue||'');if(/wp:wpbb\/icon-card|svgCode|wpbb-sector-proof-card/.test(t)&&(/<!--|<!–|wp:wpbb/.test(t)))remove.push(n);}
    remove.forEach(function(x){if(x.parentNode)x.parentNode.removeChild(x);});
  }

  function commonHost(cards,root){
    cards=uniq(cards);if(cards.length<2)return null;
    var p=cards[0].parentElement,depth=0;
    while(p&&p!==D.body&&depth<9){
      if(root&&root!==p&&!root.contains(p))break;
      var direct=kids(p).filter(function(k){return cards.some(function(c){return k===c||k.contains(c);});});
      if(direct.length>=2)return p;
      p=p.parentElement;depth++;
    }
    return null;
  }
  function inferCols(host,cards){
    var direct=kids(host).filter(function(k){return cards.some(function(c){return k===c||k.contains(c);});});
    var cls=direct.map(function(c){return c.className||'';}).join(' ');
    if(/(?:^|\s)col-(?:xl-|xxl-)?3(?:\s|$)|(?:^|\s)col-lg-3(?:\s|$)/.test(cls))return 4;
    if(/(?:^|\s)col-(?:xl-|xxl-)?4(?:\s|$)|(?:^|\s)col-lg-4(?:\s|$)/.test(cls))return 3;
    if(/(?:^|\s)col-(?:xl-|xxl-)?6(?:\s|$)|(?:^|\s)col-lg-6(?:\s|$)/.test(cls))return 2;
    if(direct.length===2)return 2;
    if(direct.length===3)return 3;
    return direct.length>=4?4:Math.max(2,direct.length);
  }
  function addGrid(host,cards,cols){
    if(!host||!cards||cards.length<2)return;
    cards=uniq(cards);
    var direct=kids(host).filter(function(k){return cards.some(function(c){return k===c||k.contains(c);});});
    if(direct.length<2)return;
    cols=Math.max(2,Math.min(4,cols||inferCols(host,cards)));
    host.classList.add('wpbb-v137-grid','wpbb-v137-cols-'+cols);
    direct.forEach(function(cell){cell.classList.add('wpbb-v137-grid-cell');});
    cards.forEach(function(card){card.classList.add('wpbb-v137-equal-card');});
  }

  function heroBlocks(){
    return uniq(qa('#wp-theme-main .wpbb-swiper--hero,#wp-theme-main .wp-theme-sector-hero .swiper,#wp-theme-main .wp-theme-hero .swiper').filter(function(b){return !b.closest('.wpbb-swiper--hero')||b.classList.contains('wpbb-swiper--hero');}));
  }
  function heroShell(block){return block&&block.closest('.wp-theme-sector-hero,.wp-theme-hero,.wp-theme-section-shell,section')||block&&block.parentElement||block;}
  function heroSlides(block){return qa('.swiper-slide',block).filter(function(s){return !s.classList.contains('swiper-slide-duplicate');});}
  function heroMedia(slide){return q('.wpbb-swiper-slide__media,.wp-theme-hero__media,.wpbb-hero-media',slide);}
  function ensureHeroImage(slide,url,index){
    if(!slide||!url)return;
    var media=heroMedia(slide)||slide,img=q('img',media);
    if(!img){img=D.createElement('img');img.className='wpbb-v137-hero-image';media.appendChild(img);}
    img.src=url;img.removeAttribute('srcset');img.removeAttribute('sizes');img.removeAttribute('width');img.removeAttribute('height');
    img.loading='eager';img.decoding='async';try{img.fetchPriority=index===0?'high':'auto';}catch(e){}
    if(media.style)media.style.removeProperty('background-image');
  }
  function repairHero(){
    var blocks=heroBlocks();if(!blocks.length)return;
    blocks.forEach(function(block,i){
      var shell=heroShell(block);if(i>0){hide(shell||block);return;}
      block.classList.add('wpbb-v137-hero');if(shell)shell.classList.add('wpbb-v137-hero-shell');
      var ss=heroSlides(block);ss.forEach(function(s,idx){if(heroUrls.length)ensureHeroImage(s,heroUrls[idx%heroUrls.length],idx);});
      var host=shell||block.parentElement||block;
      qa('.wpbb-v136-hero-pagination,.wpbb-v135-hero-pagination,.wpbb-v134-hero-pagination,.wpbb-v133-hero-pagination,.wpbb-v128-hero-pagination,.wpbb-v127-hero-pagination,.wpbb-v126-hero-pagination,.swiper-pagination',host).forEach(hide);
      var count=Math.max(1,Math.min(3,heroUrls.length||ss.length||3)),pager=q('.wpbb-v137-hero-pagination',host);
      if(!pager){
        pager=D.createElement('div');pager.className='wpbb-v137-hero-pagination';pager.setAttribute('aria-label','Hero slides');host.appendChild(pager);
        for(var bi=0;bi<count;bi++)(function(index){
          var b=D.createElement('button');b.type='button';b.className='wpbb-v137-hero-bullet';b.setAttribute('aria-label','Go to slide '+(index+1));
          b.addEventListener('click',function(){var node=block.classList.contains('swiper')?block:(q('.swiper',block)||block),sw=node&&node.swiper||block.swiper;if(sw&&typeof sw.slideToLoop==='function')sw.slideToLoop(index);else if(sw&&typeof sw.slideTo==='function')sw.slideTo(index);paint();});
          pager.appendChild(b);
        })(bi);
      }
      function paint(){var node=block.classList.contains('swiper')?block:(q('.swiper',block)||block),sw=node&&node.swiper||block.swiper,idx=0;if(sw&&typeof sw.realIndex==='number')idx=((sw.realIndex%count)+count)%count;else{var a=q('.swiper-slide-active',block),arr=heroSlides(block),p=arr.indexOf(a);if(p>=0)idx=p%count;}qa('.wpbb-v137-hero-bullet',pager).forEach(function(b,j){b.classList.toggle('is-active',j===idx);});}
      paint();var node=block.classList.contains('swiper')?block:(q('.swiper',block)||block),sw=node&&node.swiper||block.swiper;
      if(sw&&typeof sw.on==='function'&&!block.__wpbbV137Bound){block.__wpbbV137Bound=true;sw.on('slideChange',paint);sw.on('transitionEnd',paint);}
    });
  }

  function processData(){var out=[];for(var i=0;i<3;i++){var f=fallback[i]||[];out.push([String(f[0]||('0'+(i+1))).replace(/^([1-9])$/,'0$1'),String(f[1]||('Step '+(i+1))),String(f[2]||'')]);}return out;}
  function findProcessSections(){
    var out=[];qa('#wp-theme-main .wp-theme-process-section').forEach(function(s){if(out.indexOf(s)<0)out.push(s);});
    qa('#wp-theme-main .wp-theme-sector-process-grid,#wp-theme-main [class*="process-grid"]').forEach(function(g){var s=g.closest('.wp-theme-process-section,section,.wp-theme-section-shell');if(s&&out.indexOf(s)<0)out.push(s);});
    if(!out.length){qa('#wp-theme-main section,#wp-theme-main .wp-theme-section-shell').forEach(function(s){var h=norm(txt(q('.wp-theme-section-heading,h2,h3',s)));if(/delivery model|simple process|how it works|how we work|choose .* describe|find .* compare .* book|choose .* learn .* check|choose .* request .* confirm/.test(h))out.push(s);});}
    return out;
  }
  function cloneHeading(section){var h=q('.wp-theme-section-heading',section);if(h)return h.cloneNode(true);var eyebrow=q('.wp-theme-sector-eyebrow,.wp-theme-eyebrow,[class*="eyebrow"]',section),title=q('h2,h3',section),wrap=D.createElement('div');wrap.className='wp-theme-section-heading';if(eyebrow)wrap.appendChild(eyebrow.cloneNode(true));if(title)wrap.appendChild(title.cloneNode(true));return wrap.children.length?wrap:null;}
  function rebuildProcess(){
    findProcessSections().forEach(function(section){
      if(section.dataset.wpbbV137Owned==='1')return;
      var heading=cloneHeading(section),shell=D.createElement('div'),grid=D.createElement('div');shell.className='wpbb-v137-process-shell';grid.className='wpbb-v137-process-grid';if(heading)shell.appendChild(heading);
      processData().forEach(function(item){var card=D.createElement('article');card.className='wpbb-v137-process-card';var badge=D.createElement('span');badge.className='wpbb-v137-process-badge';badge.textContent=item[0];var h=D.createElement('h3');h.textContent=item[1];var p=D.createElement('p');p.textContent=item[2];card.appendChild(badge);card.appendChild(h);card.appendChild(p);grid.appendChild(card);});
      shell.appendChild(grid);while(section.firstChild)section.removeChild(section.firstChild);section.appendChild(shell);section.classList.add('wpbb-v137-process-section');section.dataset.wpbbV137Owned='1';
    });
  }

  function repairStats(){
    qa('#wp-theme-main .wp-theme-sector-proof,#wp-theme-main .wp-theme-home-stats').forEach(function(scope){
      var cards=uniq(qa('.wp-theme-sector-proof__item,.wpbb-fun-fact',scope));if(cards.length<2)return;var host=commonHost(cards,scope)||scope;
      host.classList.add('wpbb-v137-stats-grid');kids(host).forEach(function(c){if(cards.some(function(x){return c===x||c.contains(x);})){c.classList.add('wpbb-v137-grid-cell');}});cards.forEach(function(c){c.classList.add('wpbb-v137-stat-card');});
    });
  }

  function repairMediaText(){
    qa('#wp-theme-main .wp-theme-sector-media-text').forEach(function(row){row.classList.add('wpbb-v137-media-grid');kids(row).forEach(function(c){c.classList.add('wpbb-v137-grid-cell');});});
  }

  function repairKnownGrids(){
    var cardSelector='.wp-theme-sector-card,.wpbb-icon-card,.wp-theme-case-card,.wp-theme-blog-card,.wpbb-sector-card,.wpbb-catalogue-card,.product.type-product,.product-card';
    qa('#wp-theme-main .wp-theme-services-section,#wp-theme-main .wp-theme-industries-section,#wp-theme-main .wp-theme-insights-section,#wp-theme-main .wp-theme-blog-section,#wp-theme-main .wp-theme-related-posts,#wp-theme-main .wp-theme-section-shell').forEach(function(section){
      if(section.classList.contains('wp-theme-process-section')||section.classList.contains('wpbb-v137-process-section')||section.classList.contains('wp-theme-gallery-section'))return;
      var cards=uniq(qa(cardSelector,section).filter(function(c){return !c.closest('.wpbb-v137-process-grid,.swiper,.wpbb-swiper--hero');}));
      if(cards.length>=2&&cards.length<=12){var host=commonHost(cards,section);if(host)addGrid(host,cards,inferCols(host,cards));}
    });
    qa('#wp-theme-main .wpbb-v62-card-grid,#wp-theme-main .wp-theme-case-grid,#wp-theme-main .wp-theme-case-studies-grid,#wp-theme-main .wp-theme-insights-grid,#wp-theme-main .wp-theme-blog-grid,#wp-theme-main .wp-theme-sector-cards,#wp-theme-main .wp-theme-feature-grid,#wp-theme-main .wp-theme-card-grid,#wp-theme-main .wpbb-sector-grid,#wp-theme-main ul.products').forEach(function(host){
      if(host.closest('.swiper,.wpbb-swiper--hero')||host.classList.contains('swiper-wrapper'))return;
      var cards=uniq(qa(cardSelector,host));if(cards.length>=2)addGrid(host,cards,inferCols(host,cards));
      else{var cells=kids(host).filter(function(c){return txt(c)||q('img,article,.card,form',c);});if(cells.length>=2&&cells.length<=8)addGrid(host,cells,Math.min(4,cells.length));}
    });
    qa('#wp-theme-main .wp-theme-home-product-catalogue').forEach(function(scope){var row=q(':scope > .row,:scope > .wpbb-row',scope)||q('.row,.wpbb-row',scope);if(!row)return;var cards=uniq(qa('.wpbb-catalogue-card,.product.type-product,.product-card',row));if(cards.length>=2)addGrid(row,cards,4);});
  }

  function isDecorativeImage(img){
    var c=String(img.className||'')+' '+String(img.parentElement&&img.parentElement.className||'');
    return /logo|icon|avatar|flag|badge|rating|star|payment|thumbnail-nav/i.test(c)||img.closest('.wp-theme-site-header,.wp-theme-site-footer,.wpbb-v137-hero');
  }
  function mediaFrameFor(img){
    return img.closest('.wpbb-swiper-slide__media,.wp-theme-card__media,.wpbb-sector-card__media,.wp-theme-blog-card__media,.wp-theme-case-card__media,.wp-theme-sector-media-text__media,.wpbb-catalogue-card__media,figure,picture')||img.parentElement;
  }
  function normalizeImages(){
    qa('#wp-theme-main img').forEach(function(img){
      if(isDecorativeImage(img))return;
      var inRepeating=img.closest('.wp-theme-services-section,.wp-theme-industries-section,.wp-theme-insights-section,.wp-theme-blog-section,.wp-theme-gallery-section,.wp-theme-sector-media-text,.wp-theme-home-product-catalogue,.wp-theme-products-section,.wpbb-sector-grid,.wpbb-v137-grid');
      if(!inRepeating)return;
      var frame=mediaFrameFor(img);if(!frame)return;
      frame.classList.add('wpbb-v137-media-frame');img.classList.add('wpbb-v137-card-image');img.decoding='async';
      if(!img.hasAttribute('loading')&&!img.closest('.wp-theme-sector-media-text'))img.loading='lazy';
      if(img.hasAttribute('srcset')&&!img.hasAttribute('sizes'))img.setAttribute('sizes','(min-width:1040px) 30vw, (min-width:700px) 48vw, 100vw');
    });
  }

  function alignSections(){
    qa('#wp-theme-main section,#wp-theme-main .wp-theme-section-shell,#wp-theme-main .wpbb-v67-section-shell,#wp-theme-main .wp-theme-home-stats').forEach(function(s){
      if(s.classList.contains('wpbb-v137-hero-shell')||s.closest('.wpbb-v137-hero-shell'))return;
      s.classList.add('wpbb-v137-align-section');
      var direct=q(':scope > .container,:scope > .wpbb-v67-section-inner,:scope > .wp-block-group__inner-container',s);
      if(direct)return;
      var eligible=kids(s).filter(function(c){return !c.classList.contains('wpbb-v137-hidden')&&!c.matches('script,style');});
      if(!eligible.length||s.classList.contains('wpbb-v137-process-section'))return;
      if(eligible.length===1&&eligible[0].matches('.container,.container-fluid,.wpbb-v67-section-inner'))return;
      // Only wrap plain content sections. Components with their own viewport/full-bleed
      // behaviour keep their DOM untouched.
      if(s.matches('.wp-theme-home-cta,.wp-theme-sector-hero,.wp-theme-hero'))return;
      var wrap=D.createElement('div');wrap.className='wpbb-v137-section-inner';eligible[0].parentNode.insertBefore(wrap,eligible[0]);eligible.forEach(function(c){wrap.appendChild(c);});
    });
  }

  function cleanupDuplicateHeroLikeSections(){var primary=heroBlocks()[0];qa('#wp-theme-main .wp-theme-sector-hero,#wp-theme-main .wp-theme-hero').forEach(function(s){if(primary&&!s.contains(primary)&&q('.swiper,.wpbb-swiper--hero',s))hide(s);});}

  function run(){mark();removeMalformedBlockText();repairHero();cleanupDuplicateHeroLikeSections();rebuildProcess();alignSections();repairStats();repairMediaText();repairKnownGrids();normalizeImages();}
  var pending=false;function schedule(){if(pending)return;pending=true;W.setTimeout(function(){pending=false;run();},60);}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
  W.addEventListener('load',function(){run();W.setTimeout(run,350);W.setTimeout(run,1100);});
  if(W.MutationObserver)new MutationObserver(function(ms){if(ms.some(function(m){return m.addedNodes&&m.addedNodes.length;}))schedule();}).observe(D.documentElement,{childList:true,subtree:true});
})(window,document);
