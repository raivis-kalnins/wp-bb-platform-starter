<?php
/**
 * WP BBTheme child suite 3.8.11.38 — restaurant front-page stabilisation.
 *
 * v138 deliberately stops the historical "repair stack" from owning the
 * homepage.  The front page now uses the stable base/sector styles plus one
 * CSS-first layout layer.  No DOM wrapping, process rebuilding, or mutation
 * observer is used here.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'wpbb_child_v138_is_front' ) ) {
    function wpbb_child_v138_is_front() {
        return is_front_page() || is_home();
    }
}

if ( ! function_exists( 'wpbb_child_v138_hero_urls' ) ) {
    function wpbb_child_v138_hero_urls() {
        $dir  = get_stylesheet_directory();
        $uri  = get_stylesheet_directory_uri();
        $urls = array();
        foreach ( array( 1, 2, 3 ) as $i ) {
            foreach ( array( 'assets/img/hero-v136/slide-' . $i . '.jpg', 'assets/img/hero-v134/slide-' . $i . '.jpg', 'assets/img/hero-v118/slide-' . $i . '.jpg' ) as $rel ) {
                $path = $dir . '/' . $rel;
                if ( is_readable( $path ) ) {
                    $urls[] = add_query_arg( 'v', (string) filemtime( $path ), trailingslashit( $uri ) . $rel );
                    break;
                }
            }
        }
        return $urls;
    }
}

if ( ! function_exists( 'wpbb_child_v138_normalize_hero_attrs' ) ) {
    function wpbb_child_v138_normalize_hero_attrs( $attrs ) {
        if ( ! is_array( $attrs ) || 'hero' !== sanitize_key( (string) ( $attrs['demoStyle'] ?? '' ) ) ) return $attrs;
        $urls = wpbb_child_v138_hero_urls();
        if ( ! $urls ) return $attrs;
        $attrs['autoplay']       = true;
        $attrs['autoplayDelay']  = 8500;
        $attrs['pauseOnHover']   = true;
        $attrs['showPagination'] = false;
        $attrs['showNavigation'] = false;
        $attrs['loop']           = count( $urls ) > 1;
        $attrs['rewind']         = true;
        if ( ! empty( $attrs['slides'] ) && is_array( $attrs['slides'] ) ) {
            foreach ( $attrs['slides'] as $index => $slide ) {
                if ( is_array( $slide ) ) $attrs['slides'][ $index ]['image'] = $urls[ $index % count( $urls ) ];
            }
        }
        if ( ! empty( $attrs['slidesJson'] ) && is_string( $attrs['slidesJson'] ) ) {
            $slides = json_decode( $attrs['slidesJson'], true );
            if ( is_array( $slides ) ) {
                foreach ( $slides as $index => $slide ) {
                    if ( is_array( $slide ) ) $slides[ $index ]['image'] = $urls[ $index % count( $urls ) ];
                }
                $attrs['slidesJson'] = wp_json_encode( $slides, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            }
        }
        return $attrs;
    }
}

if ( ! function_exists( 'wpbb_child_v138_render_block_data' ) ) {
    function wpbb_child_v138_render_block_data( $parsed_block, $source_block, $parent_block = null ) {
        if ( wpbb_child_v138_is_front() && is_array( $parsed_block ) && 'wpbb/swiper' === (string) ( $parsed_block['blockName'] ?? '' ) ) {
            $parsed_block['attrs'] = wpbb_child_v138_normalize_hero_attrs( (array) ( $parsed_block['attrs'] ?? array() ) );
        }
        return $parsed_block;
    }
    add_filter( 'render_block_data', 'wpbb_child_v138_render_block_data', PHP_INT_MAX, 3 );
}

if ( ! function_exists( 'wpbb_child_v138_enqueue' ) ) {
    function wpbb_child_v138_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();

        // Retire every historical repair runtime. They were independently
        // moving/wrapping the same live DOM and are not needed by v138.
        foreach ( range( 98, 137 ) as $n ) {
            $handle = 'wpbb-suite-v' . $n;
            wp_dequeue_script( $handle );
            wp_deregister_script( $handle );
        }

        // On the homepage also retire the accumulated layout CSS stack. Keep
        // the stable base system and sector identity layers (v62/v82/v83/v97).
        if ( wpbb_child_v138_is_front() ) {
            foreach ( range( 98, 137 ) as $n ) {
                $handle = 'wpbb-suite-v' . $n;
                wp_dequeue_style( $handle );
                wp_deregister_style( $handle );
            }
        }

        $css = '/assets/suite-v138.css';
        wp_enqueue_style(
            'wpbb-suite-v138',
            $uri . $css,
            array(),
            is_file( $dir . $css ) ? (string) filemtime( $dir . $css ) : '3.8.11.38'
        );
    }
    add_action( 'wp_enqueue_scripts', 'wpbb_child_v138_enqueue', PHP_INT_MAX );
}

if ( ! function_exists( 'wpbb_child_v138_body_class' ) ) {
    function wpbb_child_v138_body_class( $classes ) {
        // Do not let class-gated v134-v137 CSS retain ownership if a cache or
        // optimiser concatenates an older file after the queue was cleaned.
        $classes = array_values( array_filter( (array) $classes, static function( $class ) {
            return ! preg_match( '/^wpbb-v13[4-7](?:$|-)/', (string) $class );
        } ) );
        $classes[] = 'wpbb-v138';
        return array_values( array_unique( $classes ) );
    }
    add_filter( 'body_class', 'wpbb_child_v138_body_class', PHP_INT_MAX );
}
