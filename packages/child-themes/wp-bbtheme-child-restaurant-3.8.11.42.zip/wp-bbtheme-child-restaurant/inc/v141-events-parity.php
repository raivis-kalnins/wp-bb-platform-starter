<?php
/**
 * WP BBTheme Child Restaurant 3.8.11.41 - Events-parity frontend owner.
 *
 * The working Woo Events child keeps the stable v98-v118 frontend stack and
 * retires only the later emergency layout layers. Restaurant now uses the same
 * ownership model: v118 remains the stable hero/grid runtime and v141 applies
 * only scoped Restaurant layout, finder, gallery and footer finishing rules.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v141_retired_versions' ) ) {
    function wpbb_child_v141_retired_versions() {
        return array_merge( range( 119, 128 ), range( 134, 140 ) );
    }
}

if ( ! function_exists( 'wpbb_child_v141_disable_superseded_assets' ) ) {
    function wpbb_child_v141_disable_superseded_assets() {
        foreach ( wpbb_child_v141_retired_versions() as $version ) {
            $enqueue = 'wpbb_child_v' . $version . '_enqueue';
            $body    = 'wpbb_child_v' . $version . '_body_class';
            remove_action( 'wp_enqueue_scripts', $enqueue, PHP_INT_MAX );
            remove_action( 'wp_enqueue_scripts', $enqueue, 999 );
            remove_filter( 'body_class', $body, PHP_INT_MAX );
            remove_filter( 'body_class', $body, 999 );
        }
    }
}
wpbb_child_v141_disable_superseded_assets();
add_action( 'after_setup_theme', 'wpbb_child_v141_disable_superseded_assets', PHP_INT_MAX );
add_action( 'init', 'wpbb_child_v141_disable_superseded_assets', -9999 );

if ( ! function_exists( 'wpbb_child_v141_enqueue' ) ) {
    function wpbb_child_v141_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();

        /* Defensive cleanup in case another integration re-registered one of
         * the retired handles after the callbacks above were removed. */
        foreach ( wpbb_child_v141_retired_versions() as $version ) {
            $handle = 'wpbb-suite-v' . $version;
            wp_dequeue_style( $handle );
            wp_deregister_style( $handle );
            wp_dequeue_script( $handle );
            wp_deregister_script( $handle );
        }

        /* Match the working Events theme: keep/re-assert v118 as the stable
         * frontend base instead of removing the whole v98-v118 repair stack. */
        $base_css = $dir . '/assets/suite-v118.css';
        $base_js  = $dir . '/assets/suite-v118.js';
        if ( is_readable( $base_css ) ) {
            wp_enqueue_style( 'wpbb-suite-v118', $uri . '/assets/suite-v118.css', array(), (string) filemtime( $base_css ) );
        }
        if ( is_readable( $base_js ) ) {
            wp_enqueue_script( 'wpbb-suite-v118', $uri . '/assets/suite-v118.js', array(), (string) filemtime( $base_js ), false );
        }

        $css = $dir . '/assets/suite-v141.css';
        $js  = $dir . '/assets/suite-v141.js';
        if ( is_readable( $css ) ) {
            wp_enqueue_style(
                'wpbb-suite-v141',
                $uri . '/assets/suite-v141.css',
                is_readable( $base_css ) ? array( 'wpbb-suite-v118' ) : array(),
                (string) filemtime( $css )
            );
        }
        if ( is_readable( $js ) ) {
            wp_enqueue_script(
                'wpbb-suite-v141',
                $uri . '/assets/suite-v141.js',
                is_readable( $base_js ) ? array( 'wpbb-suite-v118' ) : array(),
                (string) filemtime( $js ),
                true
            );
        }
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v141_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v141_body_class' ) ) {
    function wpbb_child_v141_body_class( $classes ) {
        $classes = array_values( array_filter( (array) $classes, static function( $class ) {
            return ! preg_match( '/^wpbb-v(?:119|12[0-8]|13[4-9]|140)(?:$|-)/', (string) $class );
        } ) );
        $classes[] = 'wpbb-v141';
        $classes[] = 'wpbb-v141-theme-restaurant';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v141_body_class', PHP_INT_MAX );
