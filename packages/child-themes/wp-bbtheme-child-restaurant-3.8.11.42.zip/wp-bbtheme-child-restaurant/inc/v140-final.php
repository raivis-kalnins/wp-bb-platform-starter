<?php
/**
 * WP BBTheme child Restaurant 3.8.11.40 — screenshot-guided visual finish.
 *
 * v140 is intentionally CSS-only: it corrects the current hero/menu/section
 * presentation without mutating or rebuilding the live DOM.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'wpbb_child_v140_is_front' ) ) {
    function wpbb_child_v140_is_front() {
        return is_front_page() || is_home();
    }
}

if ( ! function_exists( 'wpbb_child_v140_enqueue' ) ) {
    function wpbb_child_v140_enqueue() {
        if ( ! wpbb_child_v140_is_front() ) return;

        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v140.css';

        wp_enqueue_style(
            'wpbb-suite-v140',
            $uri . $css,
            array( 'wpbb-suite-v138' ),
            is_file( $dir . $css ) ? (string) filemtime( $dir . $css ) : '3.8.11.40'
        );
    }
    add_action( 'wp_enqueue_scripts', 'wpbb_child_v140_enqueue', PHP_INT_MAX );
}

if ( ! function_exists( 'wpbb_child_v140_body_class' ) ) {
    function wpbb_child_v140_body_class( $classes ) {
        if ( wpbb_child_v140_is_front() ) $classes[] = 'wpbb-v140';
        return array_values( array_unique( (array) $classes ) );
    }
    add_filter( 'body_class', 'wpbb_child_v140_body_class', PHP_INT_MAX );
}
