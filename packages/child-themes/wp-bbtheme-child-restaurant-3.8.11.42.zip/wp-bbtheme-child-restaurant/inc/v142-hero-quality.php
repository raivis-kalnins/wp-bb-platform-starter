<?php
/**
 * WP BBTheme Child Restaurant 3.8.11.42 - sharp hero media + deterministic pager.
 *
 * v141 keeps the working Events-style frontend ownership model. v142 only owns
 * the Restaurant hero sources and the visible slider pagination so the stable
 * v118 layout stack remains untouched.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v142_hero_relatives' ) ) {
    function wpbb_child_v142_hero_relatives() {
        $files = array(
            'assets/img/hero-v142/slide-1.jpg',
            'assets/img/hero-v142/slide-2.jpg',
            'assets/img/hero-v142/slide-3.jpg',
        );
        return array_values( array_filter( $files, static function( $relative ) {
            return is_readable( get_stylesheet_directory() . '/' . $relative );
        } ) );
    }
}

if ( ! function_exists( 'wpbb_child_v142_asset_url' ) ) {
    function wpbb_child_v142_asset_url( $relative ) {
        $relative = ltrim( str_replace( '\\', '/', (string) $relative ), '/' );
        if ( '' === $relative || false !== strpos( $relative, '../' ) ) return '';
        $path = get_stylesheet_directory() . '/' . $relative;
        if ( ! is_readable( $path ) ) return '';
        return add_query_arg(
            'v',
            (string) filemtime( $path ),
            trailingslashit( get_stylesheet_directory_uri() ) . $relative
        );
    }
}

if ( ! function_exists( 'wpbb_child_v142_hero_urls' ) ) {
    function wpbb_child_v142_hero_urls() {
        $urls = array();
        foreach ( wpbb_child_v142_hero_relatives() as $relative ) {
            $url = wpbb_child_v142_asset_url( $relative );
            if ( $url ) $urls[] = $url;
        }
        return array_values( array_unique( $urls ) );
    }
}

if ( ! function_exists( 'wpbb_child_v142_normalize_hero_attrs' ) ) {
    function wpbb_child_v142_normalize_hero_attrs( $attrs ) {
        if ( ! is_array( $attrs ) || 'hero' !== sanitize_key( (string) ( $attrs['demoStyle'] ?? '' ) ) ) return $attrs;
        $urls = wpbb_child_v142_hero_urls();
        if ( ! $urls ) return $attrs;

        $attrs['showPagination'] = true;
        $attrs['autoplay']       = true;
        $attrs['autoplayDelay']  = 8500;
        $attrs['pauseOnHover']   = true;
        $attrs['loop']           = true;
        $attrs['rewind']         = true;

        if ( ! empty( $attrs['slides'] ) && is_array( $attrs['slides'] ) ) {
            foreach ( $attrs['slides'] as $index => $slide ) {
                if ( is_array( $slide ) ) {
                    $attrs['slides'][ $index ]['image'] = $urls[ $index % count( $urls ) ];
                }
            }
        }

        if ( ! empty( $attrs['slidesJson'] ) && is_string( $attrs['slidesJson'] ) ) {
            $slides = json_decode( $attrs['slidesJson'], true );
            if ( is_array( $slides ) ) {
                foreach ( $slides as $index => $slide ) {
                    if ( is_array( $slide ) ) {
                        $slides[ $index ]['image'] = $urls[ $index % count( $urls ) ];
                    }
                }
                $attrs['slidesJson'] = wp_json_encode( $slides, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            }
        }

        return $attrs;
    }
}

if ( ! function_exists( 'wpbb_child_v142_render_block_data' ) ) {
    function wpbb_child_v142_render_block_data( $parsed_block ) {
        if ( is_array( $parsed_block ) && 'wpbb/swiper' === (string) ( $parsed_block['blockName'] ?? '' ) ) {
            $parsed_block['attrs'] = wpbb_child_v142_normalize_hero_attrs( (array) ( $parsed_block['attrs'] ?? array() ) );
        }
        return $parsed_block;
    }
}
add_filter( 'render_block_data', 'wpbb_child_v142_render_block_data', PHP_INT_MAX, 1 );

if ( ! function_exists( 'wpbb_child_v142_demo_profile' ) ) {
    function wpbb_child_v142_demo_profile( $profile ) {
        if ( ! is_array( $profile ) || ( $profile['id'] ?? '' ) !== 'restaurant' ) return $profile;
        $urls = wpbb_child_v142_hero_urls();
        if ( ! $urls ) return $profile;
        $profile['hero_image'] = $urls[0];
        if ( ! empty( $profile['hero_slides'] ) && is_array( $profile['hero_slides'] ) ) {
            foreach ( $profile['hero_slides'] as $index => $slide ) {
                if ( is_array( $slide ) ) {
                    $profile['hero_slides'][ $index ]['image'] = $urls[ $index % count( $urls ) ];
                }
            }
        }
        return $profile;
    }
}
add_filter( 'wp_theme_demo_profile', 'wpbb_child_v142_demo_profile', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v142_preload_hero' ) ) {
    function wpbb_child_v142_preload_hero() {
        if ( is_admin() || ! is_front_page() ) return;
        $urls = wpbb_child_v142_hero_urls();
        if ( empty( $urls[0] ) ) return;
        echo '<link rel="preload" as="image" href="' . esc_url( $urls[0] ) . '" fetchpriority="high">' . "\n";
    }
}
add_action( 'wp_head', 'wpbb_child_v142_preload_hero', 2 );

if ( ! function_exists( 'wpbb_child_v142_enqueue' ) ) {
    function wpbb_child_v142_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = $dir . '/assets/suite-v142.css';
        $js  = $dir . '/assets/suite-v142.js';

        if ( is_readable( $css ) ) {
            wp_enqueue_style(
                'wpbb-suite-v142',
                $uri . '/assets/suite-v142.css',
                wp_style_is( 'wpbb-suite-v141', 'enqueued' ) ? array( 'wpbb-suite-v141' ) : array( 'wpbb-suite-v118' ),
                (string) filemtime( $css )
            );
        }

        if ( is_readable( $js ) ) {
            wp_enqueue_script(
                'wpbb-suite-v142',
                $uri . '/assets/suite-v142.js',
                wp_script_is( 'wpbb-suite-v141', 'enqueued' ) ? array( 'wpbb-suite-v141' ) : array( 'wpbb-suite-v118' ),
                (string) filemtime( $js ),
                true
            );
            wp_add_inline_script(
                'wpbb-suite-v142',
                'window.wpbbSuiteV142=' . wp_json_encode(
                    array(
                        'version'  => '3.8.11.42',
                        'heroUrls' => wpbb_child_v142_hero_urls(),
                    ),
                    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
                ) . ';',
                'before'
            );
        }
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v142_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v142_body_class' ) ) {
    function wpbb_child_v142_body_class( $classes ) {
        $classes[] = 'wpbb-v142';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v142_body_class', PHP_INT_MAX );
