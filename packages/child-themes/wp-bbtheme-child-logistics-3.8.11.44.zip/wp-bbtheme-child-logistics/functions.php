<?php
defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/inc/frontend-password-protection.php';

function wpbb_logistics_project_mode( $mode ) { return 'logistics'; }
add_filter( 'wp_theme_project_mode', 'wpbb_logistics_project_mode' );

function wpbb_logistics_assets() {
    $theme = wp_get_theme();
    $manifest = get_stylesheet_directory() . '/dist/.vite/manifest.json';
    if ( ! is_readable( $manifest ) ) return;
    $data = json_decode( (string) file_get_contents( $manifest ), true );
    if ( ! is_array( $data ) ) return;
    if ( ! empty( $data['src/scss/public.scss']['file'] ) ) {
        wp_enqueue_style( 'wpbb-logistics-app', get_stylesheet_directory_uri() . '/dist/' . ltrim( $data['src/scss/public.scss']['file'], '/' ), array(), $theme->get( 'Version' ) );
        if ( function_exists( 'wp_theme_sector_customizer_css' ) ) wp_add_inline_style( 'wpbb-logistics-app', wp_theme_sector_customizer_css( '#123C69', '18px', '--sector-primary', '--sector-radius' ) );
    }
    if ( ! empty( $data['src/js/main.js']['file'] ) ) wp_enqueue_script( 'wpbb-logistics-app', get_stylesheet_directory_uri() . '/dist/' . ltrim( $data['src/js/main.js']['file'], '/' ), array(), $theme->get( 'Version' ), true );
}
add_action( 'wp_enqueue_scripts', 'wpbb_logistics_assets', 30 );

function wpbb_logistics_dark_mode_bootstrap() { echo '<script>(function(){try{var m=localStorage.getItem("wpThemeMode");if(m==="dark"){document.documentElement.classList.add("is-dark-theme");document.documentElement.setAttribute("data-theme","dark");}}catch(e){}})();</script>'; }
add_action( 'wp_head', 'wpbb_logistics_dark_mode_bootstrap', 1 );


function wpbb_logistics_demo_profile( $profile ) {
    $assets = trailingslashit( get_stylesheet_directory_uri() ) . 'assets/img/demo/';
    return array_merge( $profile, array(
        'id'=>'logistics', 'name'=>__( 'Logistics & Delivery', 'wp-bbtheme-child-logistics' ), 'commerce'=>false,
        'eyebrow'=>__( 'Freight across road networks', 'wp-bbtheme-child-logistics' ), 'hero_title'=>__( 'Logistics services built around the load, route and deadline.', 'wp-bbtheme-child-logistics' ), 'hero_text'=>__( 'Show fleet capability, cargo types and coverage clearly, then capture the practical details needed for a useful freight quote.', 'wp-bbtheme-child-logistics' ),
        'hero_image'=>$assets . 'hero-photo.jpg', 'about_image'=>$assets . 'about-photo.jpg',
        'primary_label'=>__( 'Explore logistics', 'wp-bbtheme-child-logistics' ), 'primary_url'=>'#finder',
        'secondary_label'=>__( 'Explore services', 'wp-bbtheme-child-logistics' ), 'secondary_url'=>wp_theme_demo_page_url( 'services' ),
        'services_eyebrow'=>__( 'What we do', 'wp-bbtheme-child-logistics' ), 'services_heading'=>__( 'Road freight, specialist trailers, distribution and last-mile delivery.', 'wp-bbtheme-child-logistics' ),
        'about_eyebrow'=>__( 'Why choose us', 'wp-bbtheme-child-logistics' ), 'about_title'=>__( 'A logistics website that explains capability before asking for the quote.', 'wp-bbtheme-child-logistics' ), 'about_text'=>__( 'Inspired by established European logistics sites: fleet types, cargo suitability, service coverage and proof points are easy to compare.', 'wp-bbtheme-child-logistics' ),
        'industries_eyebrow'=>__( 'Built around your needs', 'wp-bbtheme-child-logistics' ), 'industries_heading'=>__( 'Transport for temperature-controlled, high-value, general and specialist cargo.', 'wp-bbtheme-child-logistics' ),
        'process_eyebrow'=>__( 'How it works', 'wp-bbtheme-child-logistics' ), 'process_heading'=>__( 'Match the load to a service, send route details and receive a useful response.', 'wp-bbtheme-child-logistics' ), 'faq_heading'=>__( 'Freight, timing, cargo and service questions answered early.', 'wp-bbtheme-child-logistics' ),
        'services'=>array(array( __( 'European road freight', 'wp-bbtheme-child-logistics' ), __( 'Full-load and part-load transport across regional networks.', 'wp-bbtheme-child-logistics' ) ),
array( __( 'Temperature controlled', 'wp-bbtheme-child-logistics' ), __( 'Refrigerated and bi-thermal equipment for sensitive goods.', 'wp-bbtheme-child-logistics' ) ),
array( __( 'Distribution & vans', 'wp-bbtheme-child-logistics' ), __( 'Flexible delivery for pallets, parcels and time-sensitive consignments.', 'wp-bbtheme-child-logistics' ) ),
array( __( 'Specialist transport', 'wp-bbtheme-child-logistics' ), __( 'Oversized, vehicle and high-value cargo capability.', 'wp-bbtheme-child-logistics' ) )), 'industries'=>array(array( __( 'Food & perishables', 'wp-bbtheme-child-logistics' ), __( 'Temperature-controlled equipment and planning.', 'wp-bbtheme-child-logistics' ) ),
array( __( 'Medical & cosmetics', 'wp-bbtheme-child-logistics' ), __( 'Controlled handling for sensitive consignments.', 'wp-bbtheme-child-logistics' ) ),
array( __( 'Automotive', 'wp-bbtheme-child-logistics' ), __( 'Vehicle transport and time-critical parts movement.', 'wp-bbtheme-child-logistics' ) ),
array( __( 'Retail & general cargo', 'wp-bbtheme-child-logistics' ), __( 'Flexible full-load, part-load and distribution services.', 'wp-bbtheme-child-logistics' ) )), 'stats'=>array(array( '220k+', __( 'Annual transports', 'wp-bbtheme-child-logistics' ) ),
array( '24/7', __( 'Operations visibility', 'wp-bbtheme-child-logistics' ) ),
array( '5', __( 'Fleet categories', 'wp-bbtheme-child-logistics' ) ),
array( 'EU', __( 'Road coverage', 'wp-bbtheme-child-logistics' ) )), 'process'=>array(array( '01', __( 'Match', 'wp-bbtheme-child-logistics' ), __( 'Choose a fleet and service suited to the cargo.', 'wp-bbtheme-child-logistics' ) ),
array( '02', __( 'Quote', 'wp-bbtheme-child-logistics' ), __( 'Send pickup, delivery, load and timing details.', 'wp-bbtheme-child-logistics' ) ),
array( '03', __( 'Move', 'wp-bbtheme-child-logistics' ), __( 'Coordinate transport with clear operational contact points.', 'wp-bbtheme-child-logistics' ) )),
        'cta_title'=>__( 'Send the load details. Get the right transport response.', 'wp-bbtheme-child-logistics' ), 'cta_text'=>__( 'Use the service directory and freight quote workflow as a complete logistics starting point for lorries, vans and specialist transport.', 'wp-bbtheme-child-logistics' ), 'footer_text'=>__( 'Road freight, delivery and distribution services for businesses that need dependable transport.', 'wp-bbtheme-child-logistics' ),
        'page_labels'=>array('about'=>__( 'About', 'wp-bbtheme-child-logistics' ),'services'=>__( 'Services', 'wp-bbtheme-child-logistics' ),'industries'=>__( 'Solutions', 'wp-bbtheme-child-logistics' ),'contact'=>__( 'Contact', 'wp-bbtheme-child-logistics' ),'blog'=>__( 'Insights', 'wp-bbtheme-child-logistics' )),
        'palette'=>array('theme_brand_color'=>'#123C69','theme_accent_color'=>'#E47B25','theme_background_color'=>'#f7f8fb','theme_surface_color'=>'#ffffff','theme_border_color'=>'#dfe4ee','theme_radius'=>'22px')
    ) );
}
add_filter( 'wp_theme_demo_profile', 'wpbb_logistics_demo_profile', 20 );


function wpbb_logistics_pattern_markup( $name ) {
    $path = get_stylesheet_directory() . '/patterns/' . sanitize_file_name( $name ) . '.php';
    if ( ! is_readable( $path ) ) return '';
    ob_start(); include $path; return trim( (string) ob_get_clean() );
}

function wpbb_logistics_extra_home_sections( $content, $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'logistics' ) return $content;
    return $content . wpbb_logistics_pattern_markup( 'sector-proof' );
}
add_filter( 'wp_theme_demo_extra_home_sections', 'wpbb_logistics_extra_home_sections', 25, 2 );

function wpbb_logistics_blog_profile( $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'logistics' ) return $profile;
    $profile['blog_eyebrow'] = __( 'Insights', 'wp-bbtheme-child-logistics' );
    $profile['blog_archive_title'] = __( 'Logistics insight, fleet updates and shipping guidance.', 'wp-bbtheme-child-logistics' );
    $profile['blog_archive_intro'] = __( 'Useful information on transport planning, cargo handling and efficient delivery.', 'wp-bbtheme-child-logistics' );
    return $profile;
}
add_filter( 'wp_theme_demo_profile', 'wpbb_logistics_blog_profile', 90 );


function wpbb_logistics_demo_attachment( $filename, $title ) {
    $slug = sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) );
    $existing = get_page_by_path( 'wpbb-logistics-' . $slug, OBJECT, 'attachment' );
    if ( $existing ) return $existing->ID;
    $source = get_stylesheet_directory() . '/assets/img/demo/' . basename( $filename );
    if ( ! is_readable( $source ) ) return 0;
    $uploads = wp_upload_dir(); $dir = trailingslashit( $uploads['basedir'] ) . 'wpbb-logistics'; wp_mkdir_p( $dir );
    $target = $dir . '/' . basename( $filename ); if ( ! file_exists( $target ) ) copy( $source, $target );
    $filetype = wp_check_filetype( $target );
    if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';
    $id = wp_insert_attachment( array( 'post_mime_type'=>$filetype['type'] ?: 'image/jpeg', 'post_title'=>$title, 'post_name'=>'wpbb-logistics-' . $slug, 'post_status'=>'inherit' ), $target );
    if ( $id && ! is_wp_error( $id ) ) {
        if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';
        $meta = wpbb_child_381048_generate_attachment_metadata( $id, $target ); if ( $meta ) wp_update_attachment_metadata( $id, $meta ); update_post_meta( $id, '_wp_attachment_image_alt', $title );
        return (int) $id;
    }
    return 0;
}

function wpbb_logistics_register_directory() {
    register_post_type( 'logistics_service', array(
        'labels'=>array('name'=>__( 'Logistics Services', 'wp-bbtheme-child-logistics' ),'singular_name'=>__( 'Logistics Service', 'wp-bbtheme-child-logistics' ),'add_new_item'=>__( 'Add Logistics Service', 'wp-bbtheme-child-logistics' )),
        'public'=>true,'show_in_rest'=>true,'has_archive'=>'logistics-services','rewrite'=>array('slug'=>'logistics-services'),'menu_icon'=>'dashicons-location-alt','supports'=>array('title','editor','excerpt','thumbnail','page-attributes')
    ) );
    register_taxonomy( 'fleet_type', 'logistics_service', array( 'label'=>__( 'Fleet types', 'wp-bbtheme-child-logistics' ), 'public'=>true, 'show_in_rest'=>true, 'hierarchical'=>true, 'rewrite'=>array('slug'=>'fleet-type') ) ); register_taxonomy( 'cargo_type', 'logistics_service', array( 'label'=>__( 'Cargo types', 'wp-bbtheme-child-logistics' ), 'public'=>true, 'show_in_rest'=>true, 'hierarchical'=>true, 'rewrite'=>array('slug'=>'cargo-type') ) );
}
add_action( 'init', 'wpbb_logistics_register_directory', 12 );

function wpbb_logistics_meta_fields() { return array('payload'=>__( 'Typical payload', 'wp-bbtheme-child-logistics' ),'temperature'=>__( 'Temperature range', 'wp-bbtheme-child-logistics' ),'coverage'=>__( 'Coverage', 'wp-bbtheme-child-logistics' ),'lead_time'=>__( 'Typical dispatch', 'wp-bbtheme-child-logistics' ),'vehicle'=>__( 'Vehicle / trailer', 'wp-bbtheme-child-logistics' )); }
function wpbb_logistics_meta_box() { add_meta_box( 'wpbb-logistics-details', __( 'Logistics Service details', 'wp-bbtheme-child-logistics' ), 'wpbb_logistics_meta_box_render', 'logistics_service', 'normal', 'high' ); }
add_action( 'add_meta_boxes', 'wpbb_logistics_meta_box' );
function wpbb_logistics_meta_box_render( $post ) {
    wp_nonce_field( 'wpbb_logistics_save', 'wpbb_logistics_nonce' ); echo '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px">';
    foreach ( wpbb_logistics_meta_fields() as $key=>$label ) { $value=get_post_meta($post->ID,'_logistics_'.$key,true); echo '<label><strong>'.esc_html($label).'</strong><input class="widefat" type="text" name="wpbb_logistics['.esc_attr($key).']" value="'.esc_attr($value).'"></label>'; } echo '</div>';
}
function wpbb_logistics_save_meta( $post_id ) {
    if ( empty($_POST['wpbb_logistics_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wpbb_logistics_nonce'])),'wpbb_logistics_save') || !current_user_can('edit_post',$post_id) ) return;
    $values=isset($_POST['wpbb_logistics'])&&is_array($_POST['wpbb_logistics'])?wp_unslash($_POST['wpbb_logistics']):array(); foreach(wpbb_logistics_meta_fields() as $key=>$label) update_post_meta($post_id,'_logistics_'.$key,sanitize_text_field($values[$key]??''));
}
add_action( 'save_post_logistics_service', 'wpbb_logistics_save_meta' );

function wpbb_logistics_directory_configs( $configs ) {
    $configs['logistics'] = array(
      'post_type'=>'logistics_service','eyebrow'=>__( 'Logistics services', 'wp-bbtheme-child-logistics' ),'title'=>__( 'Match your cargo to the right transport service.', 'wp-bbtheme-child-logistics' ),'intro'=>__( 'Filter by fleet, cargo type and payload to narrow the right operating model.', 'wp-bbtheme-child-logistics' ),'keyword_label'=>__( 'Search services', 'wp-bbtheme-child-logistics' ),'keyword_placeholder'=>__( 'Refrigerated, van, oversized…', 'wp-bbtheme-child-logistics' ),'button_label'=>__( 'Find service', 'wp-bbtheme-child-logistics' ),'results_label'=>__( 'transport services', 'wp-bbtheme-child-logistics' ),'limit'=>8,'default_sort'=>'featured',
      'filters'=>array(array('type'=>'taxonomy','key'=>'fleet','label'=>__( 'Fleet type', 'wp-bbtheme-child-logistics' ),'taxonomy'=>'fleet_type','all_label'=>'Any fleet'),array('type'=>'taxonomy','key'=>'cargo','label'=>__( 'Cargo type', 'wp-bbtheme-child-logistics' ),'taxonomy'=>'cargo_type','all_label'=>'Any cargo'),array('type'=>'meta_min','key'=>'payload','label'=>__( 'Min payload (kg)', 'wp-bbtheme-child-logistics' ),'meta_key'=>'_logistics_payload','placeholder'=>'Any','step'=>500),array('type'=>'meta_select','key'=>'coverage','label'=>__( 'Coverage', 'wp-bbtheme-child-logistics' ),'meta_key'=>'_logistics_coverage','all_label'=>'Any region','options'=>array('UK'=>__( 'UK', 'wp-bbtheme-child-logistics' ),'Europe'=>__( 'Europe', 'wp-bbtheme-child-logistics' ),'UK & Europe'=>__( 'UK & Europe', 'wp-bbtheme-child-logistics' )))),'sorts'=>array('featured'=>array('label'=>__( 'Recommended', 'wp-bbtheme-child-logistics' ),'orderby'=>'menu_order','order'=>'ASC'),'payload'=>array('label'=>__( 'Payload: high to low', 'wp-bbtheme-child-logistics' ),'orderby'=>'meta_value_num','order'=>'DESC','meta_key'=>'_logistics_payload')),'card_taxonomies'=>array('fleet_type','cargo_type'),'card_meta'=>array(array('key'=>'_logistics_vehicle','label'=>__( 'Equipment', 'wp-bbtheme-child-logistics' )),array('key'=>'_logistics_payload','label'=>__( 'Payload', 'wp-bbtheme-child-logistics' ),'suffix'=>' kg'),array('key'=>'_logistics_temperature','label'=>__( 'Temperature', 'wp-bbtheme-child-logistics' )),array('key'=>'_logistics_coverage','label'=>__( 'Coverage', 'wp-bbtheme-child-logistics' ))),'card_button'=>__( 'View service', 'wp-bbtheme-child-logistics' )
    ); return $configs;
}
add_filter( 'wp_theme_sector_directory_configs', 'wpbb_logistics_directory_configs' );

function wpbb_logistics_seed_directory( $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'logistics' ) return;
    $rows=array(array('title'=>'Refrigerated FTL','slug'=>'refrigerated-ftl','excerpt'=>'Temperature-controlled full-load transport for food, medical and sensitive cargo.','content'=>'Temperature-controlled full-load transport for food, medical and sensitive cargo.','terms'=>array('fleet_type'=>'Refrigerated semi-trailer','cargo_type'=>'Temperature controlled'),'meta'=>array('payload'=>'22000','temperature'=>'-25°C to +25°C','coverage'=>'Europe','lead_time'=>'Same / next day','vehicle'=>'Reefer semi-trailer'),'image'=>'item-1.jpg'),array('title'=>'Bi-Thermal Distribution','slug'=>'bi-thermal-distribution','excerpt'=>'Separate temperature zones for mixed chilled and frozen consignments.','content'=>'Separate temperature zones for mixed chilled and frozen consignments.','terms'=>array('fleet_type'=>'Bi-thermal trailer','cargo_type'=>'Temperature controlled'),'meta'=>array('payload'=>'19000','temperature'=>'Dual zone','coverage'=>'Europe','lead_time'=>'Planned routes','vehicle'=>'Bi-thermal semi-trailer'),'image'=>'item-2.jpg'),array('title'=>'Two-Level High Volume','slug'=>'two-level-high-volume','excerpt'=>'High-volume two-level trailer configuration for efficient pallet movements.','content'=>'High-volume two-level trailer configuration for efficient pallet movements.','terms'=>array('fleet_type'=>'Two-level trailer','cargo_type'=>'General cargo'),'meta'=>array('payload'=>'21000','temperature'=>'Ambient','coverage'=>'Europe','lead_time'=>'24–48h','vehicle'=>'Double-deck trailer'),'image'=>'item-3.jpg'),array('title'=>'Oversized Road Transport','slug'=>'oversized-road-transport','excerpt'=>'Planning and transport for out-of-gauge machinery and specialist loads.','content'=>'Planning and transport for out-of-gauge machinery and specialist loads.','terms'=>array('fleet_type'=>'Oversized trailer','cargo_type'=>'Oversized'),'meta'=>array('payload'=>'30000','temperature'=>'Ambient','coverage'=>'UK & Europe','lead_time'=>'Project planned','vehicle'=>'Low-loader / extendable'),'image'=>'item-4.jpg'),array('title'=>'Vehicle Transporter','slug'=>'vehicle-transporter','excerpt'=>'Multi-vehicle road transport for dealer, fleet and remarketing movements.','content'=>'Multi-vehicle road transport for dealer, fleet and remarketing movements.','terms'=>array('fleet_type'=>'Car transporter','cargo_type'=>'Automotive'),'meta'=>array('payload'=>'18000','temperature'=>'Ambient','coverage'=>'Europe','lead_time'=>'Scheduled','vehicle'=>'Car transporter'),'image'=>'item-5.jpg'),array('title'=>'Express Van Delivery','slug'=>'express-van-delivery','excerpt'=>'Direct van delivery for urgent, valuable or lower-volume consignments.','content'=>'Direct van delivery for urgent, valuable or lower-volume consignments.','terms'=>array('fleet_type'=>'Van','cargo_type'=>'Express'),'meta'=>array('payload'=>'1200','temperature'=>'Ambient','coverage'=>'UK & Europe','lead_time'=>'Same day','vehicle'=>'LWB van'),'image'=>'item-6.jpg'));
    foreach($rows as $i=>$row){
      foreach($row['terms'] as $tax=>$term) if(taxonomy_exists($tax)&&!term_exists($term,$tax)) wp_insert_term($term,$tax);
      $existing=get_page_by_path($row['slug'],OBJECT,'logistics_service'); $args=array('post_type'=>'logistics_service','post_status'=>'publish','post_title'=>$row['title'],'post_name'=>$row['slug'],'menu_order'=>$i,'post_excerpt'=>$row['excerpt'],'post_content'=>'<!-- wp:paragraph --><p>'.esc_html($row['content']).'</p><!-- /wp:paragraph -->');
      if($existing){$args['ID']=$existing->ID;$id=wp_update_post($args);}else{$id=wp_insert_post($args);} if(!$id||is_wp_error($id))continue;
      foreach($row['terms'] as $tax=>$term)wp_set_object_terms($id,$term,$tax); foreach($row['meta'] as $key=>$value)update_post_meta($id,'_logistics_'.$key,$value); $img=wpbb_logistics_demo_attachment($row['image'],$row['title']); if($img)set_post_thumbnail($id,$img); update_post_meta($id,'_wp_theme_demo_logistics_service',1);
    }
}
add_action( 'wp_theme_seed_sector_pages', 'wpbb_logistics_seed_directory', 25 );

function wpbb_logistics_after_hero_finder( $content, $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'logistics' ) return $content;
    return $content . '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wpbb-logistics-finder-section","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container"} --><!-- wp:wpbb/column {"xs":12} --><!-- wp:wpbb/sector-finder {"context":"logistics","limit":8} /--><!-- /wp:wpbb/column --><!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';
}
add_filter( 'wp_theme_demo_after_hero_sections', 'wpbb_logistics_after_hero_finder', 20, 2 );

function wpbb_logistics_navigation( $items, $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'logistics' ) return $items;
    array_splice( $items, 1, 0, array( array('key'=>'logistics_service','title'=>__( 'Logistics', 'wp-bbtheme-child-logistics' ),'type'=>'post_type_archive','object'=>'logistics_service','locations'=>array('header','footer')) ) ); return $items;
}
add_filter( 'wp_theme_demo_navigation_items', 'wpbb_logistics_navigation', 20, 2 );

function wpbb_logistics_header_search_types( $types ) { if(post_type_exists('logistics_service'))$types[]='logistics_service'; return array_values(array_unique($types)); }
add_filter( 'wp_theme_header_search_post_types', 'wpbb_logistics_header_search_types' );

function wpbb_logistics_single_content( $content ) {
    if ( !is_singular('logistics_service') || !in_the_loop() || !is_main_query() ) return $content; $content=wpbb_child_381043_dedupe_single_body($content,get_the_excerpt()); $id=get_the_ID(); $image=get_the_post_thumbnail_url($id,'large'); $gallery = function_exists( 'wpbb_child_381045_gallery_single_markup' ) ? wpbb_child_381045_gallery_single_markup( $id ) : ''; if ( ! $gallery && function_exists( 'wp_theme_item_gallery_single_markup' ) ) $gallery = wp_theme_item_gallery_single_markup( $id );
    $facts=''; foreach(wpbb_logistics_meta_fields() as $key=>$label){$value=get_post_meta($id,'_logistics_'.$key,true);if(''!==trim((string)$value))$facts.='<div><small>'.esc_html($label).'</small><strong>'.esc_html($value).'</strong></div>';}
    $html='<section class="wpbb-sector-single"><div class="container"><div class="wpbb-sector-single__hero"><div class="wpbb-sector-single__media">'.($gallery?:($image?'<img src="'.esc_url($image).'" alt="'.esc_attr(get_the_title()).'">':'')).'</div><div><p class="wp-theme-sector-eyebrow">'.esc_html('Logistics Service').'</p><h1>'.esc_html(get_the_title()).'</h1><p class="wp-theme-sector-lead">'.esc_html(get_the_excerpt()).'</p><div class="wpbb-sector-single__facts">'.$facts.'</div></div></div><div class="wpbb-sector-single__content">'.$content.'</div>';
    if(function_exists('wpbb_logistics_request_form'))$html.=wpbb_logistics_request_form($id); return $html.'</div></section>';
}
add_filter( 'the_content', 'wpbb_logistics_single_content', 25 );

function wpbb_logistics_polylang_post_types( $types, $settings ) { $types['logistics_service']='logistics_service'; return $types; }
add_filter( 'pll_get_post_types', 'wpbb_logistics_polylang_post_types', 10, 2 );
function wpbb_logistics_pll_fleet_type( $tax, $settings ) { $tax['fleet_type']='fleet_type'; return $tax; }
add_filter( 'pll_get_taxonomies', 'wpbb_logistics_pll_fleet_type', 10, 2 );
function wpbb_logistics_pll_cargo_type( $tax, $settings ) { $tax['cargo_type']='cargo_type'; return $tax; }
add_filter( 'pll_get_taxonomies', 'wpbb_logistics_pll_cargo_type', 10, 2 );

function wpbb_logistics_register_requests() { register_post_type('freight_quote',array('labels'=>array('name'=>__( 'Freight Quotes', 'wp-bbtheme-child-logistics' ),'singular_name'=>__( 'Freight Quote', 'wp-bbtheme-child-logistics' )),'public'=>false,'show_ui'=>true,'show_in_menu'=>'edit.php?post_type=logistics_service','supports'=>array('title'))); }
add_action('init','wpbb_logistics_register_requests',14);
function wpbb_logistics_request_form( $object_id ) {
    $success=isset($_GET['request'])&&'received'===sanitize_key(wp_unslash($_GET['request'])); ob_start(); ?>
    <div class="wpbb-sector-request" id="request"><p class="wp-theme-sector-eyebrow"><?php echo esc_html(__( 'Freight quote', 'wp-bbtheme-child-logistics' )); ?></p><h2><?php echo esc_html(__( 'Send the route and load details.', 'wp-bbtheme-child-logistics' )); ?></h2><?php if($success):?><div class="alert alert-success"><?php echo esc_html(__( 'Thanks. Your freight quote request has been received.', 'wp-bbtheme-child-logistics' )); ?></div><?php endif;?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="wpbb_logistics_submit_request"><input type="hidden" name="object_id" value="<?php echo esc_attr($object_id); ?>"><?php wp_nonce_field('wpbb_logistics_request_'.$object_id,'wpbb_logistics_request_nonce'); ?>
      <?php echo '<label class=""><span>'.esc_html(__( 'Name', 'wp-bbtheme-child-logistics' )).'</span><input type="text" name="name" required></label>' . '<label class=""><span>'.esc_html(__( 'Email', 'wp-bbtheme-child-logistics' )).'</span><input type="email" name="email" required></label>' . '<label class=""><span>'.esc_html(__( 'Pickup location', 'wp-bbtheme-child-logistics' )).'</span><input type="text" name="pickup" required></label>' . '<label class=""><span>'.esc_html(__( 'Delivery location', 'wp-bbtheme-child-logistics' )).'</span><input type="text" name="delivery" required></label>' . '<label class=""><span>'.esc_html(__( 'Weight (kg)', 'wp-bbtheme-child-logistics' )).'</span><input type="number" name="weight" min="1"></label>' . '<label class=""><span>'.esc_html(__( 'Collection date', 'wp-bbtheme-child-logistics' )).'</span><input type="date" name="collection_date"></label>' . '<label class="is-wide"><span>'.esc_html(__( 'Cargo, pallets, temperature or special handling', 'wp-bbtheme-child-logistics' )).'</span><textarea name="message" rows="5"></textarea></label>'; ?><button class="btn btn-primary" type="submit"><?php echo esc_html(__( 'Request freight quote', 'wp-bbtheme-child-logistics' )); ?></button>
    </form></div><?php return ob_get_clean();
}
function wpbb_logistics_submit_request() {
    $object_id=absint($_POST['object_id']??0); if(!$object_id||'logistics_service'!==get_post_type($object_id))wp_die(esc_html(__( 'Invalid request.', 'wp-bbtheme-child-logistics' ))); if(empty($_POST['wpbb_logistics_request_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wpbb_logistics_request_nonce'])),'wpbb_logistics_request_'.$object_id))wp_die(esc_html(__( 'The form expired. Please try again.', 'wp-bbtheme-child-logistics' )));
    $name=sanitize_text_field(wp_unslash($_POST['name']??'')); $email=sanitize_email(wp_unslash($_POST['email']??'')); $pickup=sanitize_text_field(wp_unslash($_POST['pickup']??'')); $delivery=sanitize_text_field(wp_unslash($_POST['delivery']??'')); $weight=absint(wp_unslash($_POST['weight']??'')); $collection_date=sanitize_text_field(wp_unslash($_POST['collection_date']??'')); $message=sanitize_textarea_field(wp_unslash($_POST['message']??'')); if('' === (string) $name || ! is_email( $email ) || '' === (string) $pickup || '' === (string) $delivery)wp_die(esc_html(__( 'Please complete the required fields.', 'wp-bbtheme-child-logistics' )));
    $request_id=wp_insert_post(array('post_type'=>'freight_quote','post_status'=>'publish','post_title'=>sprintf('%s — %s',get_the_title($object_id),isset($name)?$name:current_time('mysql')))); if($request_id&&!is_wp_error($request_id)){foreach(array('object_id'=>$object_id,'name'=>$name,'email'=>$email,'pickup'=>$pickup,'delivery'=>$delivery,'weight'=>$weight,'collection_date'=>$collection_date,'message'=>$message,'status'=>'new') as $key=>$value)update_post_meta($request_id,'_logistics_request_'.$key,$value);}
    wp_safe_redirect(add_query_arg('request','received',get_permalink($object_id)).'#request'); exit;
}
add_action('admin_post_wpbb_logistics_submit_request','wpbb_logistics_submit_request'); add_action('admin_post_nopriv_wpbb_logistics_submit_request','wpbb_logistics_submit_request');

function wpbb_logistics_mega_menu( $definitions, $profile ) {
    if ( ( $profile['id'] ?? '' ) !== 'logistics' ) return $definitions; $archive=get_post_type_archive_link('logistics_service')?:home_url('/logistics-services/');
    $definitions['logistics_service']=array('title'=>__( 'Logistics navigation', 'wp-bbtheme-child-logistics' ),'target_key'=>'logistics_service','eyebrow'=>__( 'Logistics', 'wp-bbtheme-child-logistics' ),'heading'=>__( 'Choose the transport capability you need.', 'wp-bbtheme-child-logistics' ),'intro'=>__( 'Explore fleet types, cargo suitability and quote routes.', 'wp-bbtheme-child-logistics' ),'columns'=>array(
      array('title'=>__( 'Explore', 'wp-bbtheme-child-logistics' ),'links'=>array(array(__( 'Logistics', 'wp-bbtheme-child-logistics' ),__( 'Filter by fleet, cargo type and payload to narrow the right operating model.', 'wp-bbtheme-child-logistics' ),$archive),array(__( 'Services', 'wp-bbtheme-child-logistics' ),__( 'Road freight, specialist trailers, distribution and last-mile delivery.', 'wp-bbtheme-child-logistics' ),wp_theme_demo_page_url('services')),array(__( 'Solutions', 'wp-bbtheme-child-logistics' ),__( 'Transport for temperature-controlled, high-value, general and specialist cargo.', 'wp-bbtheme-child-logistics' ),wp_theme_demo_page_url('industries')))),
      array('title'=>__( 'Plan', 'wp-bbtheme-child-logistics' ),'links'=>array(array(__( 'How it works', 'wp-bbtheme-child-logistics' ),__( 'Match the load to a service, send route details and receive a useful response.', 'wp-bbtheme-child-logistics' ),wp_theme_demo_page_url('services')),array(__( 'About', 'wp-bbtheme-child-logistics' ),__( 'Inspired by established European logistics sites: fleet types, cargo suitability, service coverage and proof points are easy to compare.', 'wp-bbtheme-child-logistics' ),wp_theme_demo_page_url('about')),array(__( 'Contact', 'wp-bbtheme-child-logistics' ),__( 'Talk to the team about the next step.', 'wp-bbtheme-child-logistics' ),wp_theme_demo_page_url('contact')))),
      array('title'=>__( 'Useful', 'wp-bbtheme-child-logistics' ),'links'=>array(array(__( 'Insights', 'wp-bbtheme-child-logistics' ),__( 'Useful information on transport planning, cargo handling and efficient delivery.', 'wp-bbtheme-child-logistics' ),get_permalink(get_option('page_for_posts'))?:home_url('/blog/')),array(__( 'Search', 'wp-bbtheme-child-logistics' ),__( 'Use the live finder to narrow the catalogue.', 'wp-bbtheme-child-logistics' ),$archive),array(__( 'Enquire', 'wp-bbtheme-child-logistics' ),__( 'Send the details needed for a useful response.', 'wp-bbtheme-child-logistics' ),wp_theme_demo_page_url('contact'))))
    )); return $definitions;
}
add_filter('wp_theme_demo_mega_menu_definitions','wpbb_logistics_mega_menu',20,2);

/**
 * v3.8.10.20: keep editable Mega Menu content out of public discovery / SEO.
 * The parent already registers these objects as private; child filters make the
 * intent explicit for Core XML sitemaps and common SEO plugins too.
 */
function wpbb_child_private_megamenu_post_type_args( $args, $post_type ) {
    if ( 'megamenu' !== $post_type ) return $args;
    $args['public'] = false;
    $args['publicly_queryable'] = false;
    $args['exclude_from_search'] = true;
    $args['has_archive'] = false;
    $args['rewrite'] = false;
    $args['query_var'] = false;
    return $args;
}
add_filter( 'register_post_type_args', 'wpbb_child_private_megamenu_post_type_args', 20, 2 );

function wpbb_child_private_megamenu_taxonomy_args( $args, $taxonomy ) {
    if ( 'megamenu-cat' !== $taxonomy ) return $args;
    $args['public'] = false;
    $args['publicly_queryable'] = false;
    $args['rewrite'] = false;
    $args['query_var'] = false;
    return $args;
}
add_filter( 'register_taxonomy_args', 'wpbb_child_private_megamenu_taxonomy_args', 20, 2 );

function wpbb_child_core_sitemap_post_types( $post_types ) {
    unset( $post_types['megamenu'] );
    return $post_types;
}
add_filter( 'wp_sitemaps_post_types', 'wpbb_child_core_sitemap_post_types', 20 );

function wpbb_child_core_sitemap_taxonomies( $taxonomies ) {
    unset( $taxonomies['megamenu-cat'] );
    return $taxonomies;
}
add_filter( 'wp_sitemaps_taxonomies', 'wpbb_child_core_sitemap_taxonomies', 20 );

function wpbb_child_mega_robots( $robots ) {
    if ( is_singular( 'megamenu' ) || is_tax( 'megamenu-cat' ) ) {
        $robots['noindex'] = true;
        $robots['nofollow'] = true;
    }
    return $robots;
}
add_filter( 'wp_robots', 'wpbb_child_mega_robots', 20 );

function wpbb_child_yoast_exclude_megamenu_post_type( $excluded, $post_type ) {
    return 'megamenu' === $post_type ? true : $excluded;
}
add_filter( 'wpseo_sitemap_exclude_post_type', 'wpbb_child_yoast_exclude_megamenu_post_type', 20, 2 );

function wpbb_child_yoast_exclude_megamenu_taxonomy( $excluded, $taxonomy ) {
    return 'megamenu-cat' === $taxonomy ? true : $excluded;
}
add_filter( 'wpseo_sitemap_exclude_taxonomy', 'wpbb_child_yoast_exclude_megamenu_taxonomy', 20, 2 );

function wpbb_child_yoast_mega_robots( $robots ) {
    if ( is_singular( 'megamenu' ) || is_tax( 'megamenu-cat' ) ) return 'noindex, nofollow';
    return $robots;
}
add_filter( 'wpseo_robots', 'wpbb_child_yoast_mega_robots', 20 );


/**
 * v3.8.10.21: global request-a-quote UI is opt-in by child theme.
 * Sector themes with their own quote journeys can keep it; the rest do not
 * expose an unrelated floating "My Quote" control or public route.
 */
if ( ! function_exists( 'wpbb_child_request_quote_enabled' ) ) {
    function wpbb_child_request_quote_enabled() {
        $enabled_themes = array(
            'wp-bbtheme-child-automotive',
            'wp-bbtheme-child-building-services',
            'wp-bbtheme-child-insurance',
            'wp-bbtheme-child-logistics',
            'wp-bbtheme-child-medicine',
            'wp-bbtheme-child-woo-tech-shop',
        );
        $enabled = in_array( get_stylesheet(), $enabled_themes, true );
        return (bool) apply_filters( 'wpbb_child_request_quote_enabled', $enabled, get_stylesheet() );
    }
}

function wpbb_child_request_quote_body_class( $classes ) {
    $classes[] = wpbb_child_request_quote_enabled() ? 'wpbb-request-quote-enabled' : 'wpbb-request-quote-disabled';
    return $classes;
}
add_filter( 'body_class', 'wpbb_child_request_quote_body_class', 30 );

function wpbb_child_request_quote_menu_items( $items ) {
    if ( wpbb_child_request_quote_enabled() ) return $items;
    $target = trim( (string) wp_parse_url( home_url( '/request-a-quote/' ), PHP_URL_PATH ), '/' );
    foreach ( $items as $key => $item ) {
        $path = trim( (string) wp_parse_url( $item->url, PHP_URL_PATH ), '/' );
        if ( $target && $path === $target ) unset( $items[ $key ] );
    }
    return $items;
}
add_filter( 'wp_nav_menu_objects', 'wpbb_child_request_quote_menu_items', 30 );

function wpbb_child_request_quote_disable_route() {
    if ( wpbb_child_request_quote_enabled() ) return;
    $request = isset( $GLOBALS['wp']->request ) ? trim( (string) $GLOBALS['wp']->request, '/' ) : '';
    if ( ! is_page( 'request-a-quote' ) && 'request-a-quote' !== $request ) return;

    global $wp_query;
    if ( $wp_query ) $wp_query->set_404();
    status_header( 404 );
    nocache_headers();
    $template = get_404_template();
    if ( $template ) {
        include $template;
        exit;
    }
    wp_die( esc_html__( 'Page not found.', 'wp-bbtheme-child' ), esc_html__( 'Not found', 'wp-bbtheme-child' ), array( 'response' => 404 ) );
}
add_action( 'template_redirect', 'wpbb_child_request_quote_disable_route', 1 );

function wpbb_child_request_quote_sitemap_args( $args, $post_type ) {
    if ( wpbb_child_request_quote_enabled() || 'page' !== $post_type ) return $args;
    $page = get_page_by_path( 'request-a-quote' );
    if ( $page ) {
        $excluded = isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array();
        $excluded[] = (int) $page->ID;
        $args['post__not_in'] = array_values( array_unique( $excluded ) );
    }
    return $args;
}
add_filter( 'wp_sitemaps_posts_query_args', 'wpbb_child_request_quote_sitemap_args', 30, 2 );

require_once get_stylesheet_directory() . '/inc/seo-guardrails.php';

/** v3.8.10.24: identify generated legal pages independently of translated slugs. */
function wpbb_child_legal_page_body_class_v381024( $classes ) {
    if ( ! is_page() ) return $classes;
    $post = get_queried_object();
    if ( ! $post instanceof WP_Post ) return $classes;

    $is_legal = function_exists( 'is_privacy_policy' ) && is_privacy_policy();
    if ( ! $is_legal && false !== strpos( (string) $post->post_content, 'wp-theme-legal-section' ) ) {
        $is_legal = true;
    }
    if ( $is_legal ) $classes[] = 'wpbb-legal-page';
    return array_values( array_unique( $classes ) );
}
add_filter( 'body_class', 'wpbb_child_legal_page_body_class_v381024', 40 );

/** v3.8.10.25: remove generated empty spacing without touching authored copy. */
if ( ! function_exists( 'wpbb_child_remove_empty_paragraphs_v381025' ) ) {
    function wpbb_child_remove_empty_paragraphs_v381025( $content ) {
        if ( is_admin() || ! is_string( $content ) || '' === $content ) return $content;
        return (string) preg_replace(
            '~<p(?:\\s[^>]*)?>(?:\\s|&nbsp;|&#160;|<br\\s*/?>)*</p>~i',
            '',
            $content
        );
    }
}
add_filter( 'the_content', 'wpbb_child_remove_empty_paragraphs_v381025', 120 );

/** v3.8.10.25: do not output a completely empty CTA block above the footer. */
if ( ! function_exists( 'wpbb_child_remove_empty_cta_v381025' ) ) {
    function wpbb_child_remove_empty_cta_v381025( $block_content, $block ) {
        if ( empty( $block['blockName'] ) || 'wpbb/cta-section' !== $block['blockName'] || ! is_string( $block_content ) ) return $block_content;
        if ( preg_match( '~<(?:img|picture|video|iframe|form|button|a)\\b~i', $block_content ) ) return $block_content;
        $plain = trim( html_entity_decode( wp_strip_all_tags( $block_content ), ENT_QUOTES | ENT_HTML5, get_bloginfo( 'charset' ) ) );
        return '' === $plain ? '' : $block_content;
    }
}
add_filter( 'render_block', 'wpbb_child_remove_empty_cta_v381025', 120, 2 );



/** v3.8.10.29: make demo switching/imports self-healing across child themes. */
if ( ! function_exists( 'wpbb_child_demo_refresh_on_activation_v381029' ) ) {
    function wpbb_child_demo_refresh_on_activation_v381029() {
        // The parent importer stores one global version/profile. When a different
        // child theme is activated, invalidate that marker so its own profile is
        // imported instead of reusing the previous child's demo state.
        delete_option( 'wp_theme_demo_import_version' );
        delete_option( 'wp_theme_demo_menu_profile' );
    }
    add_action( 'after_switch_theme', 'wpbb_child_demo_refresh_on_activation_v381029', 5 );
}

if ( ! function_exists( 'wpbb_child_demo_integrity_guard_v381029' ) ) {
    function wpbb_child_demo_integrity_guard_v381029( $page_id = 0, $profile = array() ) {
        $page_id = absint( $page_id ?: get_option( 'page_on_front' ) );
        if ( ! $page_id || 'page' !== get_post_type( $page_id ) ) return;

        $content = (string) get_post_field( 'post_content', $page_id );
        // Never rewrite a real imported or edited homepage. This is only a guard
        // for the genuinely empty/near-empty page seen after switching demos.
        if ( strlen( trim( $content ) ) >= 120 ) return;

        if ( ! is_array( $profile ) ) $profile = array();
        $eyebrow = (string) ( $profile['eyebrow'] ?? __( 'Welcome', 'wp-theme' ) );
        $title = (string) ( $profile['hero_title'] ?? get_bloginfo( 'name' ) );
        $intro = (string) ( $profile['hero_text'] ?? __( 'A practical WordPress starter site ready to edit.', 'wp-theme' ) );
        $primary_label = (string) ( $profile['primary_label'] ?? __( 'Get started', 'wp-theme' ) );
        $primary_url = (string) ( $profile['primary_url'] ?? home_url( '/contact/' ) );
        $secondary_label = (string) ( $profile['secondary_label'] ?? __( 'Explore', 'wp-theme' ) );
        $secondary_url = (string) ( $profile['secondary_url'] ?? home_url( '/services/' ) );
        $services_heading = (string) ( $profile['services_heading'] ?? __( 'Useful services, clearly presented.', 'wp-theme' ) );
        $about_title = (string) ( $profile['about_title'] ?? __( 'A flexible starting point for the real site.', 'wp-theme' ) );
        $about_text = (string) ( $profile['about_text'] ?? $intro );
        $hero_image = esc_url( (string) ( $profile['hero_image'] ?? '' ) );
        $about_image = esc_url( (string) ( $profile['about_image'] ?? $hero_image ) );
        $services = ! empty( $profile['services'] ) && is_array( $profile['services'] ) ? array_slice( $profile['services'], 0, 4 ) : array();
        $stats = ! empty( $profile['stats'] ) && is_array( $profile['stats'] ) ? array_slice( $profile['stats'], 0, 4 ) : array();

        $out = '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wp-theme-sector-hero wp-theme-demo-repair","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container","customClasses":"align-items-center"} --><!-- wp:wpbb/column {"xs":12,"lg":6} --><p class="wp-theme-sector-eyebrow">' . esc_html( $eyebrow ) . '</p><h1>' . esc_html( $title ) . '</h1><p class="wp-theme-sector-lead">' . esc_html( $intro ) . '</p><div class="wp-theme-demo-buttons"><a class="btn btn-primary" href="' . esc_url( $primary_url ) . '">' . esc_html( $primary_label ) . '</a><a class="btn btn-outline-primary" href="' . esc_url( $secondary_url ) . '">' . esc_html( $secondary_label ) . '</a></div><!-- /wp:wpbb/column -->';
        if ( $hero_image ) $out .= '<!-- wp:wpbb/column {"xs":12,"lg":6} --><figure class="wp-theme-sector-page-image"><img src="' . $hero_image . '" alt="" loading="eager" decoding="async"></figure><!-- /wp:wpbb/column -->';
        $out .= '<!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';

        if ( 'automotive' === ( $profile['id'] ?? '' ) ) {
            $out .= '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wpbb-automotive-finder-section","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container"} --><!-- wp:wpbb/column {"xs":12} --><!-- wp:wpbb/sector-finder {"context":"automotive","limit":8} /--><!-- /wp:wpbb/column --><!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';
        }

        $out .= '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wp-theme-services-section","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container"} --><!-- wp:wpbb/column {"xs":12} --><p class="wp-theme-sector-eyebrow">' . esc_html( (string) ( $profile['services_eyebrow'] ?? __( 'Services', 'wp-theme' ) ) ) . '</p><h2>' . esc_html( $services_heading ) . '</h2><!-- wp:wpbb/row {"gutterX":"gx-4","gutterY":"gy-4"} -->';
        foreach ( $services as $service ) {
            $service_title = is_array( $service ) ? (string) ( $service[0] ?? '' ) : '';
            $service_text = is_array( $service ) ? (string) ( $service[1] ?? '' ) : '';
            if ( '' === trim( $service_title ) ) continue;
            $out .= '<!-- wp:wpbb/column {"xs":12,"md":6,"lg":3} --><article class="wp-theme-sector-card"><h3>' . esc_html( $service_title ) . '</h3><p>' . esc_html( $service_text ) . '</p></article><!-- /wp:wpbb/column -->';
        }
        $out .= '<!-- /wp:wpbb/row --><!-- /wp:wpbb/column --><!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';

        $out .= '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wp-theme-about-section","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container","customClasses":"align-items-center"} -->';
        if ( $about_image ) $out .= '<!-- wp:wpbb/column {"xs":12,"lg":6} --><figure class="wp-theme-sector-page-image"><img src="' . $about_image . '" alt="" loading="lazy" decoding="async"></figure><!-- /wp:wpbb/column -->';
        $out .= '<!-- wp:wpbb/column {"xs":12,"lg":6} --><p class="wp-theme-sector-eyebrow">' . esc_html( (string) ( $profile['about_eyebrow'] ?? __( 'About', 'wp-theme' ) ) ) . '</p><h2>' . esc_html( $about_title ) . '</h2><p class="wp-theme-sector-lead">' . esc_html( $about_text ) . '</p><!-- /wp:wpbb/column --><!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';

        if ( $stats ) {
            $out .= '<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wp-theme-sector-proof","className":"wpbb-v62-section"} --><!-- wp:wpbb/row {"containerClass":"container","gutterX":"gx-3","gutterY":"gy-3"} -->';
            foreach ( $stats as $stat ) {
                $number = is_array( $stat ) ? (string) ( $stat[0] ?? '' ) : '';
                $label = is_array( $stat ) ? (string) ( $stat[1] ?? '' ) : '';
                $out .= '<!-- wp:wpbb/column {"xs":6,"lg":3} --><div class="wp-theme-sector-proof__item"><h3>' . esc_html( $number ) . '</h3><p>' . esc_html( $label ) . '</p></div><!-- /wp:wpbb/column -->';
            }
            $out .= '<!-- /wp:wpbb/row --><!-- /wp:wpbb/bootstrap-div -->';
        }

        $out .= '<!-- wp:wpbb/cta-section {"title":"' . esc_attr( (string) ( $profile['cta_title'] ?? __( 'Ready to make it yours?', 'wp-theme' ) ) ) . '","titleTag":"h2","text":"' . esc_attr( (string) ( $profile['cta_text'] ?? $intro ) ) . '","buttonText":"' . esc_attr( $primary_label ) . '","buttonUrl":"' . esc_url( $primary_url ) . '","className":"wp-theme-home-cta wp-theme-home-cta--bbuilder"} /-->';

        wp_update_post( array( 'ID' => $page_id, 'post_content' => $out ) );
        update_post_meta( $page_id, '_wp_theme_demo_repaired_381029', current_time( 'mysql' ) );
    }
    add_action( 'wp_theme_after_demo_import', 'wpbb_child_demo_integrity_guard_v381029', 99, 2 );
}


/* v3.8.10.30 visual icon configuration */
function wpbb_logistics_visual_icon_config() {
    $config = array( 'base' => get_stylesheet_directory_uri(), 'icons' => array('truck', 'route', 'map-pin', 'calendar', 'building', 'shield', 'users', 'chart-line') );
    echo '<script>window.wpbbChildVisuals=' . wp_json_encode( $config ) . ';</script>';
}
add_action( 'wp_footer', 'wpbb_logistics_visual_icon_config', 1 );


/* v3.8.10.30: realistic demo blog featured images. Runs only after the theme's explicit demo import. */
function wpbb_logistics_demo_blog_photo_attachment( $filename, $title ) {
    $slug = sanitize_title( pathinfo( $filename, PATHINFO_FILENAME ) );
    $existing = get_page_by_path( 'logistics-blog-' . $slug, OBJECT, 'attachment' );
    if ( $existing ) {
        if ( function_exists( 'wpbb_logistics_refresh_bundled_attachment_v381041' ) ) wpbb_logistics_refresh_bundled_attachment_v381041( (int) $existing->ID, 'assets/img/blog' );
        return (int) $existing->ID;
    }
    $source = get_stylesheet_directory() . '/assets/img/blog/' . basename( $filename );
    if ( ! is_readable( $source ) ) return 0;
    $uploads = wp_upload_dir();
    $dir = trailingslashit( $uploads['basedir'] ) . 'logistics-blog';
    wp_mkdir_p( $dir );
    $target = $dir . '/' . basename( $filename );
    if ( ! file_exists( $target ) ) copy( $source, $target );
    $filetype = wp_check_filetype( $target );
    if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';
    $id = wp_insert_attachment( array(
        'post_mime_type' => $filetype['type'] ?: 'image/jpeg',
        'post_title' => $title,
        'post_name' => 'logistics-blog-' . $slug,
        'post_status' => 'inherit',
    ), $target );
    if ( $id && ! is_wp_error( $id ) ) {
        if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';
        $meta = wpbb_child_381048_generate_attachment_metadata( $id, $target );
        if ( $meta ) wp_update_attachment_metadata( $id, $meta );
        update_post_meta( $id, '_wp_attachment_image_alt', $title );
        return (int) $id;
    }
    return 0;
}
function wpbb_logistics_seed_demo_blog_photos( $page_id = 0, $profile = array() ) {
    $posts = get_posts( array( 'post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>12, 'orderby'=>'date', 'order'=>'DESC' ) );
    if ( ! $posts ) return;
    $images = array( 'blog-1.jpg','blog-2.jpg','blog-3.jpg','blog-4.jpg','blog-5.jpg','blog-6.jpg' );
    foreach ( $posts as $index => $post ) {
        $filename = $images[ $index % count( $images ) ];
        $attachment = wpbb_logistics_demo_blog_photo_attachment( $filename, get_the_title( $post ) );
        if ( $attachment ) set_post_thumbnail( $post->ID, $attachment );
    }
}
add_action( 'wp_theme_after_demo_import', 'wpbb_logistics_seed_demo_blog_photos', 70, 2 );


/** v3.8.10.31: apply bundled realistic media to already-imported demos after theme upgrade. */

/**
 * Refresh an already-imported demo attachment from the current child-theme asset.
 *
 * Image optimisation may have changed `_wp_attached_file` from e.g. item-1.jpg to
 * item-1.avif/webp. Resolve the bundled source by filename stem instead of requiring
 * the child theme to ship every generated format, then regenerate all WP sub-sizes.
 */
function wpbb_logistics_refresh_bundled_attachment_v381041( $attachment_id, $asset_dir ) {
    $attachment_id = absint( $attachment_id );
    if ( ! $attachment_id || 'attachment' !== get_post_type( $attachment_id ) ) return false;

    $attached = (string) get_post_meta( $attachment_id, '_wp_attached_file', true );
    $stem = pathinfo( basename( $attached ), PATHINFO_FILENAME );
    if ( '' === $stem ) return false;

    $base = trailingslashit( get_stylesheet_directory() ) . trailingslashit( $asset_dir ) . $stem;
    $source = '';
    foreach ( array( '.jpg', '.jpeg', '.png', '.webp', '.avif' ) as $extension ) {
        if ( is_readable( $base . $extension ) ) {
            $source = $base . $extension;
            break;
        }
    }
    if ( ! $source ) return false;

    $target = get_attached_file( $attachment_id );
    if ( ! $target ) return false;

    if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) require_once ABSPATH . 'wp-admin/includes/image.php';

    $source_ext = strtolower( (string) pathinfo( $source, PATHINFO_EXTENSION ) );
    $target_ext = strtolower( (string) pathinfo( $target, PATHINFO_EXTENSION ) );
    $written = false;

    if ( $source_ext === $target_ext ) {
        $written = (bool) @copy( $source, $target );
    } else {
        $target_type = wp_check_filetype( $target );
        $target_mime = ! empty( $target_type['type'] ) ? (string) $target_type['type'] : '';
        $editor = wp_get_image_editor( $source );
        if ( ! is_wp_error( $editor ) && 0 === strpos( $target_mime, 'image/' ) ) {
            $saved = $editor->save( $target, $target_mime );
            $written = ! is_wp_error( $saved ) && is_readable( $target );
        }
    }

    // Some hosts can read AVIF/WebP but cannot encode it. Fall back to the bundled
    // source extension and update WordPress to the new original file explicitly.
    if ( ! $written ) {
        $fallback = trailingslashit( dirname( $target ) ) . $stem . '.' . $source_ext;
        if ( ! @copy( $source, $fallback ) ) return false;
        update_attached_file( $attachment_id, $fallback );
        $filetype = wp_check_filetype( $fallback );
        if ( ! empty( $filetype['type'] ) ) {
            wp_update_post( array( 'ID' => $attachment_id, 'post_mime_type' => $filetype['type'] ) );
        }
        $target = $fallback;
    }

    // Remove old generated sizes first. Otherwise stale JPG thumbnails can remain
    // referenced after the original was converted to AVIF/WebP by an optimiser.
    $old_meta = wp_get_attachment_metadata( $attachment_id );
    if ( is_array( $old_meta ) && ! empty( $old_meta['sizes'] ) && is_array( $old_meta['sizes'] ) ) {
        foreach ( $old_meta['sizes'] as $old_size ) {
            if ( empty( $old_size['file'] ) ) continue;
            $old_file = trailingslashit( dirname( $target ) ) . basename( (string) $old_size['file'] );
            if ( is_file( $old_file ) && wp_normalize_path( $old_file ) !== wp_normalize_path( $target ) ) @unlink( $old_file );
        }
    }

    $meta = wpbb_child_381048_generate_attachment_metadata( $attachment_id, $target );
    if ( $meta ) wp_update_attachment_metadata( $attachment_id, $meta );
    clean_attachment_cache( $attachment_id );
    return true;
}

function wpbb_logistics_realistic_media_upgrade_v381041() {
    if ( ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) ) return;
    $done_key = 'wpbb_logistics_realistic_media_upgrade_v381041';
    if ( get_option( $done_key ) ) return;
    if ( ! current_user_can( 'manage_options' ) ) return;

    $pairs = array(array('wpbb-logistics','assets/img/demo'),array('logistics-blog','assets/img/blog'));
    foreach ( $pairs as $pair ) {
        $upload_prefix = $pair[0];
        $asset_dir = $pair[1];
        $ids = get_posts( array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => array( array( 'key'=>'_wp_attached_file', 'value'=>$upload_prefix . '/', 'compare'=>'LIKE' ) ),
        ) );
        foreach ( $ids as $attachment_id ) {
            wpbb_logistics_refresh_bundled_attachment_v381041( $attachment_id, $asset_dir );
        }
    }
    if ( function_exists( 'wpbb_logistics_seed_directory' ) ) wpbb_logistics_seed_directory( array( 'id'=>'logistics' ) );
    if ( function_exists( 'wpbb_logistics_seed_demo_blog_photos' ) ) wpbb_logistics_seed_demo_blog_photos( 0, array() );
    update_option( $done_key, current_time( 'mysql' ), false );
}
add_action( 'admin_init', 'wpbb_logistics_realistic_media_upgrade_v381041', 120 );


/* v3.8.10.42: full-width single-column demo rows + optional frontend demo protection. */
function wpbb_child_381042_repair_single_columns( $blocks ) {
    foreach ( $blocks as &$block ) {
        if ( 'wpbb/row' === ( $block['blockName'] ?? '' ) && ! empty( $block['innerBlocks'] ) ) {
            $column_indexes = array();
            foreach ( $block['innerBlocks'] as $index => $inner ) {
                if ( 'wpbb/column' === ( $inner['blockName'] ?? '' ) ) $column_indexes[] = $index;
            }
            if ( 1 === count( $column_indexes ) ) {
                $idx = $column_indexes[0];
                $attrs = $block['innerBlocks'][ $idx ]['attrs'] ?? array();
                if ( 12 === (int) ( $attrs['xs'] ?? 12 ) ) {
                    $attrs['xs'] = 12;
                    foreach ( array( 'sm', 'md', 'lg', 'xl', 'xxl' ) as $breakpoint ) unset( $attrs[ $breakpoint ] );
                    $block['innerBlocks'][ $idx ]['attrs'] = $attrs;
                }
            }
        }
        if ( ! empty( $block['innerBlocks'] ) ) $block['innerBlocks'] = wpbb_child_381042_repair_single_columns( $block['innerBlocks'] );
    }
    unset( $block );
    return $blocks;
}

function wpbb_child_381042_repair_demo_page_widths() {
    $pages = get_posts( array(
        'post_type' => 'page', 'post_status' => 'any', 'posts_per_page' => -1,
        'meta_key' => '_wp_theme_demo_managed', 'meta_value' => '1', 'fields' => 'ids',
    ) );
    foreach ( $pages as $page_id ) {
        $content = (string) get_post_field( 'post_content', $page_id );
        if ( false === strpos( $content, 'wpbb/column' ) ) continue;
        $blocks = parse_blocks( $content );
        $repaired = serialize_blocks( wpbb_child_381042_repair_single_columns( $blocks ) );
        if ( $repaired !== $content ) wp_update_post( array( 'ID' => $page_id, 'post_content' => $repaired ) );
    }
}
add_action( 'wp_theme_after_demo_import', 'wpbb_child_381042_repair_demo_page_widths', 140 );
function wpbb_child_381042_repair_demo_page_widths_once() {
    if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) return;
    $key = 'wpbb_381042_single_col_' . sanitize_key( get_stylesheet() );
    if ( get_option( $key ) ) return;
    wpbb_child_381042_repair_demo_page_widths();
    update_option( $key, 1, false );
}
add_action( 'admin_init', 'wpbb_child_381042_repair_demo_page_widths_once', 40 );

/**
 * v3.8.10.43: repair shared demo alignment and force one fresh media pass.
 *
 * The previous media migration was intentionally one-shot. This release uses a
 * new per-theme marker so sites that already ran v381041 receive the current
 * child-owned room/product/project/blog images as well.
 */
if ( ! function_exists( 'wpbb_child_381043_normalize_text' ) ) {
    function wpbb_child_381043_normalize_text( $value ) {
        $value = html_entity_decode( wp_strip_all_tags( (string) $value ), ENT_QUOTES | ENT_HTML5, get_bloginfo( 'charset' ) );
        return trim( preg_replace( '/\\s+/u', ' ', $value ) );
    }
}

if ( ! function_exists( 'wpbb_child_381043_dedupe_single_body' ) ) {
    function wpbb_child_381043_dedupe_single_body( $content, $excerpt = '' ) {
        $excerpt_text = wpbb_child_381043_normalize_text( $excerpt );
        if ( '' === $excerpt_text ) return $content;

        $content_text = wpbb_child_381043_normalize_text( $content );
        if ( $content_text === $excerpt_text ) return '';

        if ( preg_match( '~^\\s*<p(?:\\s[^>]*)?>(.*?)</p>~is', (string) $content, $match ) ) {
            if ( wpbb_child_381043_normalize_text( $match[1] ) === $excerpt_text ) {
                return ltrim( substr( (string) $content, strlen( $match[0] ) ) );
            }
        }
        return $content;
    }
}

if ( ! function_exists( 'wpbb_child_381043_repair_block_alignment' ) ) {
    function wpbb_child_381043_repair_block_alignment( $blocks ) {
        foreach ( $blocks as &$block ) {
            if ( 'wpbb/row' === ( $block['blockName'] ?? '' ) ) {
                $attrs = $block['attrs'] ?? array();
                $classes = preg_split( '/\\s+/', trim( (string) ( $attrs['customClasses'] ?? '' ) ) );
                $classes = array_values( array_filter( array_map( 'sanitize_html_class', $classes ) ) );
                if ( in_array( 'wp-theme-sector-media-text', $classes, true ) ) {
                    $classes = array_values( array_diff( $classes, array( 'align-items-center', 'align-items-end' ) ) );
                    if ( ! in_array( 'align-items-start', $classes, true ) ) $classes[] = 'align-items-start';
                    $attrs['customClasses'] = implode( ' ', $classes );
                    $block['attrs'] = $attrs;
                }
            }
            if ( ! empty( $block['innerBlocks'] ) ) {
                $block['innerBlocks'] = wpbb_child_381043_repair_block_alignment( $block['innerBlocks'] );
            }
        }
        unset( $block );
        return $blocks;
    }
}

if ( ! function_exists( 'wpbb_child_381043_repair_demo_pages' ) ) {
    function wpbb_child_381043_repair_demo_pages() {
        // Repair every page that actually contains the theme's media/text row.
        // This also covers front pages imported before the managed-page marker existed.
        $page_ids = get_posts( array(
            'post_type' => 'page',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids',
        ) );
        foreach ( $page_ids as $page_id ) {
            $content = (string) get_post_field( 'post_content', $page_id );
            if ( false === strpos( $content, 'wp-theme-sector-media-text' ) ) continue;
            $repaired = serialize_blocks( wpbb_child_381043_repair_block_alignment( parse_blocks( $content ) ) );
            if ( $repaired !== $content ) {
                wp_update_post( array( 'ID' => $page_id, 'post_content' => $repaired ) );
                clean_post_cache( $page_id );
            }
        }
    }
}

if ( ! function_exists( 'wpbb_child_381043_refresh_media_once' ) ) {
    function wpbb_child_381043_refresh_media_once( $page_id = 0, $profile = array() ) {
        if ( ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;

        $current_stylesheet = sanitize_key( get_stylesheet() );
        $done_key = 'wpbb_child_381043_media_' . $current_stylesheet;
        $owner_key = 'wpbb_child_381043_media_owner';
        // Demo posts are shared while child themes are switched. Refresh again
        // whenever a different child theme last supplied the active media.
        if ( get_option( $done_key ) && $current_stylesheet === (string) get_option( $owner_key ) ) return;

        $defined = get_defined_functions();
        foreach ( (array) ( $defined['user'] ?? array() ) as $function_name ) {
            if ( ! preg_match( '/^wpbb_[a-z0-9_]+_realistic_media_upgrade_v381041$/', $function_name ) ) continue;
            delete_option( $function_name );
            call_user_func( $function_name );
        }

        // Correct stale titles/alt text left behind when the same demo posts were
        // reused while switching child themes.
        $post_ids = get_posts( array(
            'post_type' => 'any',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'meta_key' => '_thumbnail_id',
            'fields' => 'ids',
        ) );
        foreach ( $post_ids as $post_id ) {
            $thumbnail_id = (int) get_post_thumbnail_id( $post_id );
            if ( ! $thumbnail_id ) continue;
            $attached = (string) get_post_meta( $thumbnail_id, '_wp_attached_file', true );
            $attachment_name = (string) get_post_field( 'post_name', $thumbnail_id );
            if ( false === strpos( $attached, '-blog/' ) && 0 !== strpos( $attachment_name, 'wpbb-' ) ) continue;
            $title = get_the_title( $post_id );
            if ( '' === trim( (string) $title ) ) continue;
            wp_update_post( array( 'ID' => $thumbnail_id, 'post_title' => $title ) );
            update_post_meta( $thumbnail_id, '_wp_attachment_image_alt', $title );
            clean_post_cache( $post_id );
            clean_attachment_cache( $thumbnail_id );
        }

        wpbb_child_381043_repair_demo_pages();
        update_option( $done_key, current_time( 'mysql' ), false );
        update_option( $owner_key, $current_stylesheet, false );
    }
}
add_action( 'wp_theme_after_demo_import', 'wpbb_child_381043_refresh_media_once', 180, 2 );
add_action( 'admin_init', 'wpbb_child_381043_refresh_media_once', 130 );

/**
 * v3.8.10.45: shared rhythm, contrast, sector-media and gallery repair.
 */
require_once __DIR__ . '/inc/sector-consistency.php';

// v3.8.10.64 shared BBuilder/demo consistency layer.
require_once get_stylesheet_directory() . '/inc/bbuilder-system-v62.php';

/**
 * v3.8.10.64 PWA endpoint hardening.
 *
 * The parent theme links to ?wpbb-pwa=manifest and registers
 * ?wpbb-pwa=service-worker. Serve those endpoints before the normal template
 * loader so browsers always receive the expected MIME type and valid payload.
 * The service worker intentionally has no fetch handler: this prevents stale
 * worker-cached ES modules from causing Chromium cross-world preload warnings.
 */
if ( ! function_exists( 'wpbb_child_381063_serve_pwa_endpoint' ) ) {
    function wpbb_child_381063_serve_pwa_endpoint() {
        if ( empty( $_GET['wpbb-pwa'] ) ) return;
        $mode = sanitize_key( wp_unslash( $_GET['wpbb-pwa'] ) );
        if ( ! in_array( $mode, array( 'manifest', 'service-worker' ), true ) ) return;

        while ( ob_get_level() ) {
            @ob_end_clean();
        }
        nocache_headers();
        header( 'X-Content-Type-Options: nosniff' );

        if ( 'manifest' === $mode ) {
            header( 'Content-Type: application/manifest+json; charset=UTF-8' );
            $name = trim( (string) get_bloginfo( 'name' ) );
            if ( '' === $name ) $name = 'WP Base';
            $scope = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
            if ( '' === $scope ) $scope = '/';
            $icons = array();
            foreach ( array( 192, 512 ) as $size ) {
                $file = get_stylesheet_directory() . '/assets/icons/icon-' . $size . '.png';
                if ( is_readable( $file ) ) {
                    $icons[] = array(
                        'src' => get_stylesheet_directory_uri() . '/assets/icons/icon-' . $size . '.png',
                        'sizes' => $size . 'x' . $size,
                        'type' => 'image/png',
                        'purpose' => 'any maskable',
                    );
                }
            }
            echo wp_json_encode( array(
                'name' => $name,
                'short_name' => function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 24 ) : substr( $name, 0, 24 ),
                'start_url' => home_url( '/' ),
                'scope' => $scope,
                'display' => 'standalone',
                'background_color' => '#ffffff',
                'theme_color' => '#3155D9',
                'icons' => $icons,
            ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            exit;
        }

        header( 'Content-Type: application/javascript; charset=UTF-8' );
        header( 'Service-Worker-Allowed: /' );
        echo "self.addEventListener('install',function(event){self.skipWaiting();});\n";
        echo "self.addEventListener('activate',function(event){event.waitUntil((async function(){try{var keys=await caches.keys();await Promise.all(keys.filter(function(k){return /^(wpbb|wp-theme|wpbase)/i.test(k);}).map(function(k){return caches.delete(k);}));}catch(e){}await self.clients.claim();})());});\n";
        exit;
    }
    add_action( 'template_redirect', 'wpbb_child_381063_serve_pwa_endpoint', -9999 );
}
// v3.8.10.75 structural/media/Woo repair.
require_once get_stylesheet_directory() . '/inc/v75-suite.php';

// v3.8.10.81: keep interactive wp-admin saves/updates fast.
require_once get_stylesheet_directory() . '/inc/v82-suite.php';
require_once get_stylesheet_directory() . '/inc/admin-performance.php';

// v3.8.10.83 premium Jobs-aligned sector presentation and multilingual managed-demo refresh.
require_once get_stylesheet_directory() . '/inc/v83-premium-suite.php';
// v3.8.10.97 final premium Jobs-aligned suite and mobile navigation.
require_once get_stylesheet_directory() . '/inc/v97-premium-suite.php';


/** 3.8.10.98 suite-wide layout/mobile finishing layer. */
function wpbb_suite_v98_enqueue(){
    $v = wp_get_theme()->get('Version');
    wp_enqueue_style('wpbb-suite-v98', get_stylesheet_directory_uri() . '/assets/suite-v98.css', array(), $v);
    wp_enqueue_script('wpbb-suite-v98', get_stylesheet_directory_uri() . '/assets/suite-v98.js', array(), $v, true);
}
add_action('wp_enqueue_scripts','wpbb_suite_v98_enqueue',999);

// v3.8.10.99 final suite-wide grid, branding, hero and mobile finish.
require_once get_stylesheet_directory() . '/inc/v99-finish.php';

// v3.8.11.00 cookie ownership, hero/colour and mobile navigation finish.
require_once get_stylesheet_directory() . '/inc/v100-finish.php';

// v3.8.11.02 navigation, legal, colour and media correction.
require_once get_stylesheet_directory() . '/inc/v101-finish.php';

// v3.8.11.04 deterministic mobile navigation and WooCommerce/alignment finish.
require_once get_stylesheet_directory() . '/inc/v104-finish.php';

// v3.8.11.05 legal/contact grid, mobile drawer and WooCommerce template finish.
require_once get_stylesheet_directory() . '/inc/v105-finish.php';

// v3.8.11.07 final search, WooCommerce, Jobs captcha/grid and responsive repair.
require_once get_stylesheet_directory() . '/inc/v107-finish.php';

// v3.8.11.08 WooCommerce layout/polish and packaging finish.
require_once get_stylesheet_directory() . '/inc/v108-finish.php';

// v3.8.11.09 WooCommerce, media and account finalisation.
require_once get_stylesheet_directory() . '/inc/v109-finish.php';

// v3.8.11.10 media, WooCommerce, managed-page and route-facing finish.
require_once get_stylesheet_directory() . '/inc/v110-finish.php';

// v3.8.11.11 hero finder, editorial grid, mega-menu and image-quality finish.
require_once get_stylesheet_directory() . '/inc/v111-finish.php';

// v3.8.11.12 editorial grid, hero clarity and media recovery.
require_once get_stylesheet_directory() . '/inc/v112-finish.php';

// v3.8.11.13 final hero edge/clarity and editorial-grid alignment.
require_once get_stylesheet_directory() . '/inc/v113-finish.php';

// v3.8.11.14 child-only settings, editor, legal, editorial and hero finish.
require_once get_stylesheet_directory() . '/inc/v114-finish.php';

// v3.8.11.15 final mega-menu, hero/media, quote and BBuilder repair.
require_once get_stylesheet_directory() . '/inc/v115-finish.php';

// v3.8.11.16 reset-safe layout/media, mega-menu, consent and BBuilder finish.
require_once get_stylesheet_directory() . '/inc/v116-finish.php';

// v3.8.11.17 exact mega-menu placement, reset-safe BBuilder grid and immediate media recovery.
require_once get_stylesheet_directory() . '/inc/v117-finish.php';


// v3.8.11.18 reset-safe gutters, direct hero assets, nav-trigger mega positioning and cache finish.
require_once get_stylesheet_directory() . '/inc/v118-finish.php';

// v3.8.11.19 live regression repair: closer mega menus, canonical gutters/grids and no-flash consent.
require_once get_stylesheet_directory() . '/inc/v119-finish.php';

// v3.8.11.20 stable v119 rollback, restored gutters/grids and deterministic hero pagination/quality repair.
require_once get_stylesheet_directory() . '/inc/v120-finish.php';

// v3.8.11.21 scoped BBuilder grid recovery; retire v119/v120 global geometry while preserving hero quality/pagination.
require_once get_stylesheet_directory() . '/inc/v121-finish.php';

// v3.8.11.22 component-only grid-gap finish; keep v121 alignment and restore stable card/media/stat spacing.
require_once get_stylesheet_directory() . '/inc/v122-finish.php';

// v3.8.11.23 remaining basic grids/gaps + authoritative hero source/pagination finish.
require_once get_stylesheet_directory() . '/inc/v123-finish.php';

// v3.8.11.24 final basic visual hardening: deterministic card gaps, full-width fun-facts and one compact hero pager.
require_once get_stylesheet_directory() . '/inc/v124-finish.php';

// v3.8.11.25 final scoped grid, hero clarity and WooCommerce shop/cart/account finish.
require_once get_stylesheet_directory() . '/inc/v125-final.php';

// v3.8.11.26 final cross-theme component grids, hero image/pagination and process-card recovery.
require_once get_stylesheet_directory() . '/inc/v126-final.php';

// v3.8.11.27 final live-regression hardening: robust card grids, process-card shape, hero pagination and Business/Building hero fade.
require_once get_stylesheet_directory() . '/inc/v127-final.php';

// v3.8.11.28 final live component recovery: commerce grids, cart/checkout, process cards and stable hero media/pagination.
require_once get_stylesheet_directory() . '/inc/v128-final.php';

// v3.8.11.34 final cross-theme hero, grid, process and WooCommerce ownership layer.
require_once get_stylesheet_directory() . '/inc/v134-final.php';


// v3.8.11.35 final duplicate/process/hero cleanup.
require_once get_stylesheet_directory() . '/inc/v135-final.php';

// v3.8.11.38 logistics nested-wrapper alignment, full-shell grids and sharper section media.
require_once get_stylesheet_directory() . '/inc/v136-final.php';

require_once get_stylesheet_directory() . '/inc/v137-final.php';

// v3.8.11.40 canonical premium 1440 grid and hero padding ownership.
require_once get_stylesheet_directory() . '/inc/v138-final.php';

// v3.8.11.41 logistics canonical grid correction: remove double inset and keep rebuilt process in-grid.
require_once get_stylesheet_directory() . '/inc/v139-final.php';

// v3.8.11.42 logistics homepage hard reset: one grid, native hero/process and legacy text cleanup.
require_once get_stylesheet_directory() . '/inc/v140-final.php';

// v3.8.11.43 numbered outcomes/process component reset.
require_once get_stylesheet_directory() . '/inc/v141-final.php';

// v3.8.11.44 canonical How-it-works row: remove outside bubbles and align cards to heading.
require_once get_stylesheet_directory() . '/inc/v142-final.php';
