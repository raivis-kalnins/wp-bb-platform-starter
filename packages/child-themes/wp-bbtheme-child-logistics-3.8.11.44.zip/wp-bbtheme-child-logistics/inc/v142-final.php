<?php
/**
 * WP BBTheme child suite 3.8.11.44 — canonical How-it-works row.
 *
 * The imported/native process component can retain an empty decorative bubble
 * outside each card and an extra nested wrapper that shifts the card row off
 * the heading grid. This layer replaces only that row with a clean three-card
 * component inside the same canonical section container.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'wpbb_child_v142_is_home' ) ) {
    function wpbb_child_v142_is_home() {
        return is_front_page() || is_home();
    }
}

if ( ! function_exists( 'wpbb_child_v142_enqueue' ) ) {
    function wpbb_child_v142_enqueue() {
        if ( ! wpbb_child_v142_is_home() ) return;

        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v142.css';
        $js  = '/assets/suite-v142.js';

        wp_enqueue_style(
            'wpbb-suite-v142',
            $uri . $css,
            array( 'wpbb-suite-v141' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.44'
        );
        wp_enqueue_script(
            'wpbb-suite-v142',
            $uri . $js,
            array( 'wpbb-suite-v141' ),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.44',
            true
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v142_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v142_body_class' ) ) {
    function wpbb_child_v142_body_class( $classes ) {
        if ( wpbb_child_v142_is_home() ) $classes[] = 'wpbb-v142';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v142_body_class', PHP_INT_MAX );
