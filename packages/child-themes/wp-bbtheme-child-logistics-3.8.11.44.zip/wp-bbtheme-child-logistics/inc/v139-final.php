<?php
/**
 * WP BBTheme child suite 3.8.11.41 — canonical logistics grid correction.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'wpbb_child_v139_enqueue' ) ) {
    function wpbb_child_v139_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();

        /* v137's DOM owner rebuilt the process section outside its native
         * container. Retire that script; v139 keeps native BBuilder structure
         * and only performs non-structural hero/media recovery. */
        wp_dequeue_script( 'wpbb-suite-v137' );
        wp_deregister_script( 'wpbb-suite-v137' );

        $css = '/assets/suite-v139.css';
        $js  = '/assets/suite-v139.js';
        wp_enqueue_style(
            'wpbb-suite-v139',
            $uri . $css,
            array( 'wpbb-suite-v138' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.41'
        );
        wp_enqueue_script(
            'wpbb-suite-v139',
            $uri . $js,
            array(),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.41',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v139',
            'window.wpbbSuiteV139=' . wp_json_encode( array(
                'version'  => '3.8.11.41',
                'themeKey' => function_exists( 'wpbb_child_v136_theme_key' ) ? wpbb_child_v136_theme_key() : 'logistics',
                'heroUrls' => function_exists( 'wpbb_child_v136_hero_urls' ) ? wpbb_child_v136_hero_urls() : array(),
            ) ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v139_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v139_body_class' ) ) {
    function wpbb_child_v139_body_class( $classes ) {
        $classes[] = 'wpbb-v139';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v139_body_class', PHP_INT_MAX );
