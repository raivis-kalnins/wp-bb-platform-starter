<?php
/**
 * WP BBTheme child suite 3.8.11.39 — final logistics hero/grid/pagination correction.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'wpbb_child_v137_enqueue' ) ) {
    function wpbb_child_v137_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();

        // v137 replaces the v136 DOM owner so the hero keeps Swiper's native
        // pagination and no competing repair script can rebuild it afterwards.
        wp_dequeue_script( 'wpbb-suite-v136' );
        wp_deregister_script( 'wpbb-suite-v136' );

        $css = '/assets/suite-v137.css';
        $js  = '/assets/suite-v137.js';
        wp_enqueue_style(
            'wpbb-suite-v137',
            $uri . $css,
            array( 'wpbb-suite-v136' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.39'
        );
        wp_enqueue_script(
            'wpbb-suite-v137',
            $uri . $js,
            array(),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.39',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v137',
            'window.wpbbSuiteV137=' . wp_json_encode( array(
                'version'       => '3.8.11.39',
                'themeKey'      => function_exists( 'wpbb_child_v136_theme_key' ) ? wpbb_child_v136_theme_key() : 'logistics',
                'heroUrls'      => function_exists( 'wpbb_child_v136_hero_urls' ) ? wpbb_child_v136_hero_urls() : array(),
                'fallbackCards' => function_exists( 'wpbb_child_v136_profile' ) ? wpbb_child_v136_profile() : array(),
            ) ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v137_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v137_body_class' ) ) {
    function wpbb_child_v137_body_class( $classes ) {
        $classes[] = 'wpbb-v137';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v137_body_class', PHP_INT_MAX );
