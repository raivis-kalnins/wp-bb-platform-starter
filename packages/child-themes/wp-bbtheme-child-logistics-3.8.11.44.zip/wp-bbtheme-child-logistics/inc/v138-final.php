<?php
/**
 * WP BBTheme child suite 3.8.11.40 — canonical premium grid and hero padding.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'wpbb_child_v138_enqueue' ) ) {
    function wpbb_child_v138_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v138.css';
        wp_enqueue_style(
            'wpbb-suite-v138',
            $uri . $css,
            array( 'wpbb-suite-v137' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.40'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v138_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v138_body_class' ) ) {
    function wpbb_child_v138_body_class( $classes ) {
        $classes[] = 'wpbb-v138';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v138_body_class', PHP_INT_MAX );
