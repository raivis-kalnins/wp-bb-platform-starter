<?php
/**
 * WP BBTheme child suite 3.8.11.42 — logistics homepage hard reset.
 *
 * The homepage had accumulated several late layout/DOM owners. This layer
 * leaves BBuilder's native section structure in place and owns only the final
 * homepage canvas, hero media/pagination, malformed legacy text cleanup and
 * non-destructive image recovery.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* Do not append the old sector-proof pattern to newly generated logistics
 * home content. Existing imported pages are also cleaned by the_content/JS
 * below, because some installs already have the malformed markup stored. */
remove_filter( 'wp_theme_demo_extra_home_sections', 'wpbb_logistics_extra_home_sections', 25 );

if ( ! function_exists( 'wpbb_child_v140_is_home' ) ) {
    function wpbb_child_v140_is_home() {
        return is_front_page() || is_home();
    }
}

if ( ! function_exists( 'wpbb_child_v140_enqueue' ) ) {
    function wpbb_child_v140_enqueue() {
        if ( ! wpbb_child_v140_is_home() ) return;

        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();

        /* One late DOM owner only. v136 and several neighbouring revisions
         * rebuild process/hero/grid markup and can race the native BBuilder
         * render. They are intentionally retired on the homepage. */
        foreach ( range( 119, 139 ) as $n ) {
            $handle = 'wpbb-suite-v' . $n;
            wp_dequeue_script( $handle );
            wp_deregister_script( $handle );
        }

        /* Remove only the recent conflicting layout layers. v134 and the base
         * theme remain available for components outside this homepage reset. */
        foreach ( range( 135, 139 ) as $n ) {
            $handle = 'wpbb-suite-v' . $n;
            wp_dequeue_style( $handle );
            wp_deregister_style( $handle );
        }

        $css = '/assets/suite-v140.css';
        $js  = '/assets/suite-v140.js';

        wp_enqueue_style(
            'wpbb-suite-v140',
            $uri . $css,
            array( 'wpbb-suite-v134' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.42'
        );
        wp_enqueue_script(
            'wpbb-suite-v140',
            $uri . $js,
            array(),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.42',
            true
        );

        wp_add_inline_script(
            'wpbb-suite-v140',
            'window.wpbbSuiteV140=' . wp_json_encode( array(
                'version'  => '3.8.11.42',
                'themeKey' => function_exists( 'wpbb_child_v136_theme_key' ) ? wpbb_child_v136_theme_key() : 'logistics',
                'heroUrls' => function_exists( 'wpbb_child_v136_hero_urls' ) ? wpbb_child_v136_hero_urls() : array(),
            ) ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v140_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v140_body_class' ) ) {
    function wpbb_child_v140_body_class( $classes ) {
        if ( wpbb_child_v140_is_home() ) $classes[] = 'wpbb-v140';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v140_body_class', PHP_INT_MAX );

/* Strip malformed legacy icon-card comments/JSON that some imported demo
 * pages stored as visible text. This runs after normal block rendering. */
if ( ! function_exists( 'wpbb_child_v140_clean_legacy_proof_text' ) ) {
    function wpbb_child_v140_clean_legacy_proof_text( $content ) {
        if ( ! wpbb_child_v140_is_home() ) return $content;
        if ( false === stripos( $content, 'wpbb-sector-proof-card' ) &&
             false === stripos( $content, 'wp:wpbb/icon-card' ) &&
             false === stripos( $content, 'svgCode' ) ) {
            return $content;
        }

        $patterns = array(
            '~<(?:p|pre|code|div)\b[^>]*>[^<]*(?:wp:wpbb/icon-card|wpbb-sector-proof-card|&quot;svgCode&quot;|"svgCode").*?</(?:p|pre|code|div)>~isu',
            '~(?:&lt;|<)!--\s*wp:wpbb/icon-card\b.*?wpbb-sector-proof-card.*?/--(?:&gt;|>)~isu',
            '~<!--\s*wp:wpbb/icon-card\b.*?wpbb-sector-proof-card.*?/-->~isu',
        );
        foreach ( $patterns as $pattern ) {
            $clean = preg_replace( $pattern, '', $content );
            if ( null !== $clean ) $content = $clean;
        }
        return $content;
    }
}
add_filter( 'the_content', 'wpbb_child_v140_clean_legacy_proof_text', PHP_INT_MAX );
