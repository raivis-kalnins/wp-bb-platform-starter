<?php
/**
 * WP BBTheme child suite 3.8.11.43 — numbered card component reset.
 *
 * The logistics homepage has two separate three-step/numbered components:
 * recent outcomes and the process/how-it-works row. Older suite layers can
 * still leave capsule media/body styles on the process cards or inconsistent
 * spacing inside the outcome cards. This layer only owns those components.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'wpbb_child_v141_is_home' ) ) {
    function wpbb_child_v141_is_home() {
        return is_front_page() || is_home();
    }
}

if ( ! function_exists( 'wpbb_child_v141_enqueue' ) ) {
    function wpbb_child_v141_enqueue() {
        if ( ! wpbb_child_v141_is_home() ) return;

        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v141.css';
        $js  = '/assets/suite-v141.js';

        wp_enqueue_style(
            'wpbb-suite-v141',
            $uri . $css,
            array( 'wpbb-suite-v140' ),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.43'
        );
        wp_enqueue_script(
            'wpbb-suite-v141',
            $uri . $js,
            array( 'wpbb-suite-v140' ),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.43',
            true
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v141_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v141_body_class' ) ) {
    function wpbb_child_v141_body_class( $classes ) {
        if ( wpbb_child_v141_is_home() ) $classes[] = 'wpbb-v141';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v141_body_class', PHP_INT_MAX );
