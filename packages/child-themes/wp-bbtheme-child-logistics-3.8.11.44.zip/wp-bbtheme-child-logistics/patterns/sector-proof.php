<?php
/**
 * Title: Logistics & Delivery proof band
 * Slug: wp-bbtheme-child-logistics/sector-proof
 * Categories: wp-patterns-main, wp-theme-current
 */
?>
<!-- wp:wpbb/bootstrap-div {"containerClass":"","utilityClasses":"wp-theme-section-shell wpbb-sector-proof-band"} -->
<!-- wp:wpbb/row {"containerClass":"container","gutterX":"gx-4","gutterY":"gy-4"} -->
<!-- wp:wpbb/column {"xs":12,"md":4} -->
<!-- wp:wpbb/icon-card {"mediaType":"svg","svgCode":"<svg viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"12\" cy=\"12\" r=\"8\"/><path d=\"M8 12h8M12 8v8\"/></svg>","title":"Fleet capability first","text":"Refrigerated, bi-thermal, oversized, car transporter and van services are structured as searchable content.","iconSize":"48px","contentAlign":"left","autoTextColor":true,"boxShadowClass":"shadow-sm","className":"wpbb-sector-proof-card"} /-->
<!-- /wp:wpbb/column -->
<!-- wp:wpbb/column {"xs":12,"md":4} -->
<!-- wp:wpbb/icon-card {"mediaType":"svg","svgCode":"<svg viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"12\" cy=\"12\" r=\"8\"/><path d=\"M8 12h8M12 8v8\"/></svg>","title":"Cargo-led discovery","text":"Visitors can narrow services by fleet, cargo type and payload needs.","iconSize":"48px","contentAlign":"left","autoTextColor":true,"boxShadowClass":"shadow-sm","className":"wpbb-sector-proof-card"} /-->
<!-- /wp:wpbb/column -->
<!-- wp:wpbb/column {"xs":12,"md":4} -->
<!-- wp:wpbb/icon-card {"mediaType":"svg","svgCode":"<svg viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><circle cx=\"12\" cy=\"12\" r=\"8\"/><path d=\"M8 12h8M12 8v8\"/></svg>","title":"Freight quote workflow","text":"Route and load details are captured as structured quote requests in WordPress.","iconSize":"48px","contentAlign":"left","autoTextColor":true,"boxShadowClass":"shadow-sm","className":"wpbb-sector-proof-card"} /-->
<!-- /wp:wpbb/column -->
<!-- /wp:wpbb/row -->
<!-- /wp:wpbb/bootstrap-div -->
