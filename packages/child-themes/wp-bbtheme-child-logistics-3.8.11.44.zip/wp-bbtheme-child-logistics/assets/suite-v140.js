(function(W,D){'use strict';
  var cfg=W.wpbbSuiteV140||{};
  var heroUrls=Array.isArray(cfg.heroUrls)?cfg.heroUrls.filter(Boolean):[];
  function qa(s,r){return Array.prototype.slice.call((r||D).querySelectorAll(s));}

  function cleanLegacyProofText(){
    var root=D.querySelector('#wp-theme-main');
    if(!root)return;
    var bad=/wp:wpbb\/icon-card|wpbb-sector-proof-card|svgCode|<svg\b|&lt;svg\b/i;

    qa('p,pre,code',root).forEach(function(el){
      if(bad.test(String(el.textContent||'')))el.remove();
    });

    qa('.wpbb-sector-proof-band,.wp-theme-sector-proof',root).forEach(function(section){
      qa('p,pre,code',section).forEach(function(el){
        if(bad.test(String(el.textContent||'')))el.remove();
      });
      Array.prototype.slice.call(section.childNodes).forEach(function(node){
        if(node.nodeType===3&&bad.test(String(node.nodeValue||'')))node.remove();
      });
      var rendered=section.querySelector('.wpbb-sector-proof-card,.wpbb-icon-card,.wp-theme-sector-proof__item,article,[class*=\"proof-card\"]');
      if(!rendered&&!String(section.textContent||'').trim())section.remove();
    });

    /* Imported malformed comments can also land as bare text nodes between
       otherwise valid sections. Remove only unmistakable block/JSON markers. */
    var walker=D.createTreeWalker(root,NodeFilter.SHOW_TEXT,null);
    var remove=[];var n;
    while((n=walker.nextNode())){
      var t=String(n.nodeValue||'');
      if(t.length>28&&bad.test(t))remove.push(n);
    }
    remove.forEach(function(node){if(node.parentNode)node.parentNode.removeChild(node);});
  }

  function repairHero(){
    var heroes=qa('#wp-theme-main .wp-theme-sector-hero .wpbb-swiper--hero,#wp-theme-main .wp-theme-sector-hero .swiper');
    heroes.forEach(function(hero){
      hero.classList.add('wpbb-v140-hero');
      var slides=qa('.swiper-slide,.wpbb-swiper-slide',hero).filter(function(s){return !s.classList.contains('swiper-slide-duplicate');});
      slides.forEach(function(slide,idx){
        var media=slide.querySelector('.wpbb-swiper-slide__media,.wp-theme-hero__media,.wpbb-hero-media');
        if(!media)return;
        var img=media.querySelector('img');
        if(!img){img=D.createElement('img');media.appendChild(img);}
        if(heroUrls.length){
          img.setAttribute('src',heroUrls[idx%heroUrls.length]);
          img.removeAttribute('srcset');
          img.removeAttribute('sizes');
          img.removeAttribute('width');
          img.removeAttribute('height');
        }
        img.decoding='async';
        if(idx===0){img.loading='eager';try{img.fetchPriority='high';}catch(e){}}
        else img.loading='lazy';
      });

      var host=hero.closest('.wp-theme-sector-hero')||hero.parentElement;
      qa('.wpbb-v136-hero-pagination,.wpbb-v135-hero-pagination,.wpbb-v134-hero-pagination,.wpbb-v133-hero-pagination,.wpbb-v128-hero-pagination,.wpbb-v127-hero-pagination,.wpbb-v126-hero-pagination,.wpbb-v124-hero-pagination,.wpbb-v123-hero-pagination,.wpbb-v121-pagination,.wpbb-v120-pagination',host).forEach(function(p){p.remove();});
      qa('.swiper-pagination,.wpbb-swiper-pagination',hero).forEach(function(p){
        p.style.removeProperty('display');p.hidden=false;p.removeAttribute('hidden');p.classList.remove('wpbb-v136-hidden','wpbb-v134-hidden');
      });
    });
  }

  function sharpenSectionMedia(){
    var selector=[
      '.wpbb-sector-card__media img','.wp-theme-sector-media-text__media img',
      '.wp-theme-blog-card img','.wp-theme-blog-list-card__media img',
      '.wp-theme-case-card img','.wp-theme-gallery-section .swiper-slide img',
      '.wp-theme-service-card img','.wp-theme-industry-card img'
    ].join(',');
    qa('#wp-theme-main '+selector.split(',').join(',#wp-theme-main ')).forEach(function(img){
      if(img.closest('.wp-theme-card-icon,.wp-theme-sector-card__icon,.wp-theme-icon-box,.wpbb-icon,.custom-logo-link,.site-logo,.wp-theme-item-gallery__thumb'))return;
      img.decoding='async';
      var src=String(img.getAttribute('src')||'');
      var full=src.replace(/-\d+x\d+(?=\.(?:jpe?g|png|webp|avif)(?:[?#]|$))/i,'');
      if(full&&full!==src&&!String(img.getAttribute('srcset')||'').trim())img.setAttribute('src',full);
    });
  }

  function run(){cleanLegacyProofText();repairHero();sharpenSectionMedia();}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',run,{once:true});else run();
  W.addEventListener('load',function(){run();W.setTimeout(run,250);W.setTimeout(run,900);});
})(window,document);
