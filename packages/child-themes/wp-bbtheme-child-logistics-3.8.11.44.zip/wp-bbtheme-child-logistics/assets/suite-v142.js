(function(W,D){'use strict';
  function qa(s,r){return Array.prototype.slice.call((r||D).querySelectorAll(s));}
  function text(el){return String(el&&el.textContent||'').replace(/\s+/g,' ').trim();}
  function norm(s){return String(s||'').replace(/\s+/g,' ').trim().toLowerCase();}
  function direct(el){return el?Array.prototype.slice.call(el.children||[]):[];}

  function findSection(){
    var s=D.querySelector('#wp-theme-main .wp-theme-process-section');
    if(s)return s;
    var h=qa('#wp-theme-main h2').find(function(n){return /^match the load to a service, send route details and receive a useful response\.?$/i.test(text(n));});
    return h?(h.closest('section,.wp-theme-section-shell,.wpbb-v67-section-shell')||h.parentElement):null;
  }

  function findHeading(section){
    if(!section)return null;
    var h=qa('h2',section).find(function(n){return /^match the load to a service, send route details and receive a useful response\.?$/i.test(text(n));});
    if(!h)return null;
    return h.closest('.wp-theme-section-heading')||h.parentElement;
  }

  function bestOldGrid(section){
    var selectors='.wp-theme-sector-process-grid,.wpbb-v62-card-grid,.wpbb-v141-process-grid,.wpbb-v136-process-grid,.wpbb-v135-process-grid,.wpbb-v134-process-grid,.row,.wpbb-row';
    var best=null,bestScore=-1;
    qa(selectors,section).forEach(function(g){
      if(g.classList.contains('wpbb-v142-process-grid'))return;
      var titles=qa('h3',g).map(function(h){return norm(text(h));});
      var hits=['match','quote','move'].filter(function(x){return titles.indexOf(x)>=0;}).length;
      if(hits<2)return;
      var kids=direct(g).filter(function(k){return k.nodeType===1;});
      var score=hits*100+(kids.length===3?40:0)-(qa('h2',g).length*60);
      if(score>bestScore){bestScore=score;best=g;}
    });
    return best;
  }

  function itemFor(section,title,fallbackCopy){
    var h=qa('h3',section).find(function(n){return norm(text(n))===title.toLowerCase() && !n.closest('.wpbb-v142-process-grid');});
    if(!h)return {title:title,copy:fallbackCopy};
    var scope=h.closest('.wp-theme-sector-card,.wp-theme-process-card,.wpbb-icon-card,.card,.wpbb-column,[class*="col-"]')||h.parentElement;
    var p=scope&&scope.querySelector('p');
    return {title:text(h)||title,copy:(p&&text(p))||fallbackCopy};
  }

  function canonicalContainer(section,heading){
    var c=heading&&heading.closest('.container,.wpbb-v67-section-inner,.wp-theme-section-inner,.wpbb-section-inner');
    if(c&&section.contains(c))return c;
    c=section.querySelector(':scope > .container,:scope > .wpbb-v67-section-inner,:scope > .wp-theme-section-inner,:scope > .wpbb-section-inner');
    return c||section;
  }

  function directChildContaining(container,node){
    if(!container||!node)return null;
    var cur=node;
    while(cur&&cur.parentElement&&cur.parentElement!==container)cur=cur.parentElement;
    return cur&&cur.parentElement===container?cur:null;
  }

  function makeGrid(items){
    var grid=D.createElement('div');
    grid.className='wpbb-v142-process-grid';
    items.forEach(function(item,i){
      var card=D.createElement('article');card.className='wpbb-v142-process-card';
      var badge=D.createElement('span');badge.className='wpbb-v142-process-badge';badge.textContent=('0'+(i+1)).slice(-2);
      var h=D.createElement('h3');h.textContent=item.title;
      var p=D.createElement('p');p.textContent=item.copy;
      card.appendChild(badge);card.appendChild(h);card.appendChild(p);grid.appendChild(card);
    });
    return grid;
  }

  function cleanEmptyAncestors(node,stop){
    var p=node;
    while(p&&p!==stop&&p.parentElement){
      var next=p.parentElement;
      if(text(p)===''&&!p.querySelector('img,svg,video,iframe,input,button,a'))p.remove();
      else break;
      p=next;
    }
  }

  function repair(){
    var section=findSection();if(!section)return;
    section.classList.add('wpbb-v142-process');
    var heading=findHeading(section);if(!heading)return;
    var container=canonicalContainer(section,heading);

    var items=[
      itemFor(section,'Match','Choose a fleet and service suited to the cargo.'),
      itemFor(section,'Quote','Send pickup, delivery, load and timing details.'),
      itemFor(section,'Move','Coordinate transport with clear operational contact points.')
    ];

    var existing=container.querySelector(':scope > .wpbb-v142-process-grid');
    if(existing)return;

    var oldGrid=bestOldGrid(section);
    if(oldGrid){
      var parent=oldGrid.parentElement;
      oldGrid.classList.add('wpbb-v142-retired-process');
      oldGrid.remove();
      if(parent)cleanEmptyAncestors(parent,container);
    }

    /* Remove any remaining legacy process ornaments/rows that contain the same
       three process titles. This is intentionally scoped to this one section. */
    qa('.wp-theme-sector-process-grid,.wpbb-v141-process-grid,.wpbb-v136-process-grid,.wpbb-v135-process-grid,.wpbb-v134-process-grid',section).forEach(function(g){
      if(g.classList.contains('wpbb-v142-process-grid'))return;
      var t=norm(text(g));
      if(t.indexOf('match')>=0&&t.indexOf('quote')>=0&&t.indexOf('move')>=0){g.remove();}
    });

    var grid=makeGrid(items);
    var anchor=directChildContaining(container,heading)||heading;
    if(anchor&&anchor.parentElement===container)anchor.insertAdjacentElement('afterend',grid);
    else container.appendChild(grid);
  }

  function run(){repair();}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',run,{once:true});else run();
  W.addEventListener('load',function(){run();W.setTimeout(run,220);W.setTimeout(run,850);});
})(window,document);
