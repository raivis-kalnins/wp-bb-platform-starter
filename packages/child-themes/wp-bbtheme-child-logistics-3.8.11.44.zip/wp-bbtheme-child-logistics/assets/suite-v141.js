(function(W,D){'use strict';
  function qa(s,r){return Array.prototype.slice.call((r||D).querySelectorAll(s));}
  function text(el){return String(el&&el.textContent||'').replace(/\s+/g,' ').trim();}
  function direct(el){return el?Array.prototype.slice.call(el.children||[]):[];}

  function sectionForHeading(re){
    var h=qa('#wp-theme-main h1,#wp-theme-main h2,#wp-theme-main h3').find(function(node){return re.test(text(node));});
    if(!h)return null;
    return h.closest('.wp-theme-case-studies-section,.wp-theme-case-studies,.wp-theme-process-section,.wpbb-v67-section-shell,.wp-theme-section-shell,section') || h.parentElement;
  }

  function bestGrid(section,selectors){
    if(!section)return null;
    var candidates=qa(selectors,section);
    var best=null,bestScore=-1;
    candidates.forEach(function(grid){
      var kids=direct(grid).filter(function(k){return k.nodeType===1;});
      var heads=qa('h3',grid).length;
      var score=(kids.length===3?50:0)+(kids.length>=3&&kids.length<=4?20:0)+(heads>=3?30:heads*4);
      if(score>bestScore){bestScore=score;best=grid;}
    });
    return best;
  }

  function exactLeaf(root,re){
    if(!root)return null;
    return qa('*',root).find(function(el){return !el.children.length&&re.test(text(el));})||null;
  }

  function cardIn(cell,selectors){
    if(!cell)return null;
    if(cell.matches&&cell.matches(selectors))return cell;
    return cell.querySelector(selectors)||cell;
  }

  function ensureStep(card,cell,index){
    var step=('0'+(index+1)).slice(-2);
    var re=new RegExp('^'+step+'$');
    var badge=exactLeaf(cell,re);
    if(badge&&badge!==card&&card.contains(badge)===false){
      try{card.insertBefore(badge,card.firstChild);}catch(e){}
    }
    if(!badge||!card.contains(badge)){
      badge=D.createElement('span');
      badge.textContent=step;
      card.insertBefore(badge,card.firstChild);
    }
    badge.classList.add('wpbb-v141-step-badge');
    badge.removeAttribute('style');
    return badge;
  }

  function markMetric(card){
    var leaves=qa('*',card).filter(function(el){
      if(el.children.length)return false;
      var t=text(el);
      if(/^0[123]$/.test(t))return false;
      return /^(?:\d+(?:\.\d+)?%?|\d+(?:\.\d+)?[kKmM]\+?|EU)$/.test(t);
    });
    if(!leaves.length)return;
    var value=leaves[leaves.length-1];
    value.classList.add('wpbb-v141-metric-value');
    var box=value.parentElement;
    for(var i=0;i<2&&box&&box.parentElement&&box.parentElement!==card;i++){
      var parent=box.parentElement;
      var t=text(parent);
      if(t.length>0&&t.length<=80&&!parent.querySelector('h3'))box=parent;else break;
    }
    if(box&&box!==card)box.classList.add('wpbb-v141-metric');
  }

  function markOutcomes(){
    var section=sectionForHeading(/^Recent work and measurable outcomes\.?$/i);
    if(!section)return;
    section.classList.add('wpbb-v141-outcomes');
    var grid=bestGrid(section,'.wp-theme-case-grid,.wp-theme-case-studies-grid,.wp-theme-results-grid,.wpbb-v62-card-grid,.wpbb-v134-grid,.wpbb-v136-grid,.row,.wpbb-row');
    if(!grid)return;
    grid.classList.add('wpbb-v141-outcomes-grid');
    var cells=direct(grid).filter(function(k){return k.querySelector&&k.querySelector('h3');}).slice(0,3);
    cells.forEach(function(cell,index){
      cell.classList.add('wpbb-v141-outcome-cell');
      var card=cardIn(cell,'.wp-theme-case-card,.wp-theme-result-card,.wp-theme-story-card,.card,.wpbb-icon-card');
      card.classList.add('wpbb-v141-outcome-card');
      ensureStep(card,cell,index);
      var h=card.querySelector('h3');if(h)h.classList.add('wpbb-v141-card-title');
      var ps=qa('p',card);if(ps.length)ps[0].classList.add('wpbb-v141-card-copy');
      markMetric(card);
    });
  }

  function markProcess(){
    var section=D.querySelector('#wp-theme-main .wp-theme-process-section') || sectionForHeading(/^Match the load to a service, send route details and receive a useful response\.?$/i);
    if(!section)return;
    section.classList.add('wpbb-v141-process');
    var grid=bestGrid(section,'.wp-theme-sector-process-grid,.wpbb-v62-card-grid,.wpbb-v136-process-grid,.row,.wpbb-row');
    if(!grid)return;
    grid.classList.add('wpbb-v141-process-grid');
    var cells=direct(grid).filter(function(k){return k.querySelector&&k.querySelector('h3');}).slice(0,3);
    cells.forEach(function(cell,index){
      cell.classList.add('wpbb-v141-process-cell');
      var card=cardIn(cell,'.wp-theme-process-card,.wp-theme-sector-card,.wpbb-icon-card,.card');
      card.classList.add('wpbb-v141-process-card');
      ensureStep(card,cell,index);
      var h=card.querySelector('h3');if(h)h.classList.add('wpbb-v141-card-title');
      var ps=qa('p',card);if(ps.length)ps[0].classList.add('wpbb-v141-card-copy');
    });
  }

  function run(){markOutcomes();markProcess();}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',run,{once:true});else run();
  W.addEventListener('load',function(){run();W.setTimeout(run,180);W.setTimeout(run,700);});
})(window,document);
