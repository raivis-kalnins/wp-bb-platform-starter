(function(W,D){
  'use strict';
  var cfg=W.wpbbSuiteV139||{};
  var heroUrls=Array.isArray(cfg.heroUrls)?cfg.heroUrls.filter(Boolean):[];
  function q(s,r){try{return (r||D).querySelector(s);}catch(e){return null;}}
  function qa(s,r){try{return Array.prototype.slice.call((r||D).querySelectorAll(s));}catch(e){return [];}}
  function hide(n){if(n&&n.classList)n.classList.add('wpbb-v136-hidden');}

  function heroBlocks(){
    return qa('#wp-theme-main .wpbb-swiper--hero,#wp-theme-main .wp-theme-sector-hero .swiper,#wp-theme-main .wp-theme-hero .swiper').filter(function(b,i,a){
      return a.indexOf(b)===i&&(!b.closest('.wpbb-swiper--hero')||b.classList.contains('wpbb-swiper--hero'));
    });
  }
  function heroShell(block){return block&&block.closest('.wp-theme-sector-hero,.wp-theme-hero,.wp-theme-section-shell,section')||block&&block.parentElement||block;}
  function heroSlides(block){return qa('.swiper-slide',block).filter(function(s){return !s.classList.contains('swiper-slide-duplicate');});}
  function heroMedia(slide){return q('.wpbb-swiper-slide__media,.wp-theme-hero__media,.wpbb-hero-media',slide);}
  function ensureHeroImage(slide,url,index){
    if(!slide||!url)return;
    var media=heroMedia(slide)||slide,img=q('img',media);
    if(!img){img=D.createElement('img');img.className='wpbb-v139-hero-image';media.appendChild(img);}
    img.src=url;img.removeAttribute('width');img.removeAttribute('height');img.loading='eager';img.decoding='async';
    try{img.fetchPriority=index===0?'high':'auto';}catch(e){}
    if(media.style)media.style.removeProperty('background-image');
  }
  function repairHero(){
    var blocks=heroBlocks();if(!blocks.length)return;
    blocks.forEach(function(block,i){
      var shell=heroShell(block);
      if(i>0){hide(shell||block);return;}
      block.classList.add('wpbb-v136-hero','wpbb-v139-hero');
      if(shell)shell.classList.add('wpbb-v136-hero-shell','wpbb-v139-hero-shell');
      heroSlides(block).forEach(function(slide,index){if(heroUrls.length)ensureHeroImage(slide,heroUrls[index%heroUrls.length],index);});
      var host=shell||block.parentElement||block;
      qa('.wpbb-v136-hero-pagination,.wpbb-v135-hero-pagination,.wpbb-v134-hero-pagination',host).forEach(hide);
      qa('.swiper-pagination,.wpbb-swiper-pagination',block).forEach(function(p){p.classList.remove('wpbb-v136-hidden');});
    });
  }

  /* Keep the image-quality repair, but deliberately do not rebuild process,
     stats, cards or section wrappers. Native BBuilder structure owns layout. */
  function sharpenSectionMedia(){
    var sel=[
      '.wp-theme-sector-media-text__media img','.wp-theme-sector-page-image img',
      '.wp-theme-blog-card .wp-block-post-featured-image img','.wp-theme-blog-list-card__media img',
      '.wpbb-sector-card__media img','.wp-theme-case-card img','.wp-theme-gallery-card img',
      '.wp-theme-service-card img','.wp-theme-industry-card img','.wp-theme-directory-card img',
      '.wp-theme-feature-card img','.wp-theme-card-media img','.wp-theme-card__media img',
      '.wp-theme-gallery-section .swiper-slide img','.wp-theme-gallery-section .wpbb-swiper-slide img',
      '.wp-theme-case-studies img','.wp-theme-insights-section .wp-block-post-featured-image img'
    ].join(',');
    qa('#wp-theme-main '+sel.split(',').join(',#wp-theme-main ')).forEach(function(img){
      if(img.closest('.wpbb-v139-hero,.wp-theme-card-icon,.wp-theme-sector-card__icon,.wp-theme-icon-box,.wpbb-icon,.custom-logo-link,.site-logo,.wp-theme-item-gallery__thumb'))return;
      img.decoding='async';
      var src=String(img.getAttribute('src')||''),full=src.replace(/-\d+x\d+(?=\.(?:jpe?g|png|webp|avif)(?:[?#]|$))/i,'');
      if(full&&full!==src&&!String(img.getAttribute('srcset')||'').trim())img.setAttribute('src',full);
    });
  }

  function run(){repairHero();sharpenSectionMedia();}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',run,{once:true});else run();
  W.addEventListener('load',function(){run();W.setTimeout(run,350);W.setTimeout(run,1200);});
})(window,document);
