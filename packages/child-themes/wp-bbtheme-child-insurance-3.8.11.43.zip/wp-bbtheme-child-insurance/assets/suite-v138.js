(function(W,D){
  'use strict';
  var cfg=W.wpbbSuiteV138||{}, media=cfg.media||{};
  function q(s,r){try{return (r||D).querySelector(s);}catch(e){return null;}}
  function qa(s,r){try{return Array.prototype.slice.call((r||D).querySelectorAll(s));}catch(e){return [];}}
  function uniq(a){return a.filter(function(x,i){return x&&a.indexOf(x)===i;});}
  function kids(n){return n?Array.prototype.slice.call(n.children||[]):[];}
  function inMain(n){return !!(n&&n.closest&&n.closest('#wp-theme-main'));}

  function markBody(){if(D.body)D.body.classList.add('wpbb-v138');}

  function markSections(){
    var main=q('#wp-theme-main'); if(!main)return;
    qa('.wpbb-v67-section-shell,.wp-theme-section-shell',main).forEach(function(s){
      if(s.closest('.wp-theme-sector-hero,.wp-theme-hero')||s.classList.contains('wp-theme-sector-hero')||s.classList.contains('wp-theme-hero'))return;
      s.classList.add('wpbb-v138-section');
    });
  }

  function cellFor(card,scope){
    var n=card,depth=0;
    while(n&&n!==scope&&n!==D.body&&depth<8){
      if(n!==card&&n.matches&&n.matches('.wpbb-column,.wp-block-wpbb-column,[class*="col-"],li.product,.wpbb-grid__item'))return n;
      n=n.parentElement;depth++;
    }
    return card;
  }

  function ownGrid(scope,cardSelector,cols){
    if(!scope)return;
    var cards=uniq(qa(cardSelector,scope)).filter(function(c){return inMain(c)&&!c.closest('.swiper,.wpbb-swiper--gallery,.wpbb-swiper--hero');});
    if(cards.length<2)return;
    var groups=[];
    cards.forEach(function(card){
      var cell=cellFor(card,scope),host=cell&&cell.parentElement;
      if(!host||!scope.contains(host))return;
      var g=groups.filter(function(x){return x.host===host;})[0];
      if(!g){g={host:host,cells:[],cards:[]};groups.push(g);}
      if(g.cells.indexOf(cell)<0)g.cells.push(cell);
      g.cards.push(card);
    });
    groups.sort(function(a,b){return b.cards.length-a.cards.length;});
    var g=groups[0]; if(!g||g.cards.length<2)return;
    g.host.classList.add('wpbb-v138-grid','wpbb-v138-cols-'+cols);
    g.cells.forEach(function(c){c.classList.add('wpbb-v138-cell');});
    g.cards.forEach(function(c){c.classList.add('wpbb-v138-card');});
  }

  function markKnownGrids(){
    var main=q('#wp-theme-main'); if(!main)return;
    qa('.wp-theme-services-section',main).forEach(function(s){ownGrid(s,'.wp-theme-sector-card,.wpbb-icon-card',4);});
    qa('.wp-theme-industries-section',main).forEach(function(s){ownGrid(s,'.wp-theme-sector-card,.wpbb-icon-card',4);});
    qa('.wp-theme-process-section',main).forEach(function(s){ownGrid(s,'.wp-theme-process-card,.wp-theme-sector-card,.wpbb-icon-card',3);});
    qa('.wp-theme-case-studies-section,.wp-theme-case-grid,.wp-theme-case-studies-grid',main).forEach(function(s){ownGrid(s,'.wp-theme-case-card',3);});
    qa('.wp-theme-insights-section,.wp-theme-blog-section,.wp-theme-insights-grid,.wp-theme-blog-grid',main).forEach(function(s){ownGrid(s,'.wp-theme-blog-card',3);});
    qa('.wp-theme-home-stats,.wp-theme-sector-proof',main).forEach(function(s){ownGrid(s,'.wpbb-fun-fact,.wp-theme-sector-proof__item',4);});
    qa('.wpbb-sector-finder',main).forEach(function(s){ownGrid(s,'.wpbb-sector-card',3);});
  }

  function forceImage(img,url){
    if(!img)return;
    var lazy=img.getAttribute('data-src')||img.getAttribute('data-lazy-src')||'';
    var src=String(img.getAttribute('src')||'');
    if(url)img.setAttribute('src',url); else if(lazy&&(!src||/^data:/i.test(src)||/placeholder/i.test(src)))img.setAttribute('src',lazy);
    if(url){img.removeAttribute('srcset');img.removeAttribute('sizes');img.removeAttribute('data-srcset');}
    img.setAttribute('loading','eager');
    img.setAttribute('decoding','async');
    img.style.opacity='1';img.style.visibility='visible';
    img.classList.remove('lazyload','lazyloading');img.classList.add('lazyloaded');
  }

  function ensureMediaImage(host,url){
    if(!host)return null;
    var img=q('img',host);
    if(!img&&url){img=D.createElement('img');img.alt='';host.appendChild(img);}
    forceImage(img,url);return img;
  }

  function hydrateMedia(){
    var main=q('#wp-theme-main');if(!main)return;
    var gallery=Array.isArray(media.gallery)?media.gallery:[];
    qa('.wp-theme-gallery-section .swiper-slide,.wp-theme-gallery-section .wpbb-swiper-slide',main).forEach(function(slide,i){
      var host=q('.wpbb-swiper-slide__media,.wp-theme-hero__media,.wpbb-hero-media,figure',slide)||slide;
      ensureMediaImage(host,gallery.length?gallery[i%gallery.length]:'');
    });

    var blogs=Array.isArray(media.blog)?media.blog:[];
    qa('.wp-theme-blog-card',main).forEach(function(card,i){
      var img=q('img',card),url=blogs.length?blogs[i%blogs.length]:'';
      if(img)forceImage(img,url);
      else if(url){var host=q('.wp-theme-blog-card__media,figure',card);ensureMediaImage(host,url);}
    });

    var cases=Array.isArray(media.case)?media.case:[];
    qa('.wp-theme-case-card',main).forEach(function(card,i){
      var img=q('img',card);if(img)forceImage(img,'');
      else if(cases.length){var host=q('.wp-theme-case-card__media,figure',card);if(host)ensureMediaImage(host,cases[i%cases.length]);}
    });

    qa('.wpbb-sector-card__media img,.wp-theme-sector-media-text__media img,.wpbb-v138-product-card img',main).forEach(function(img){forceImage(img,'');});
  }

  function cleanCatalogueResidue(){
    var main=q('#wp-theme-main');if(!main)return;
    qa('.wpbb-v138-catalogue',main).forEach(function(cat){
      cat.classList.remove('row','wpbb-row','wpbb-v137-grid','wpbb-v137-catalogue-grid');
      qa('[class*="wpbb-v137-catalogue"],[class*="wpbb-v126-catalogue"],.row,.wpbb-row',cat).forEach(function(n){
        if(n.classList.contains('wpbb-v138-product-grid'))return;
        if(!q('.wpbb-v138-product-card',n))return;
        n.style.width='100%';n.style.maxWidth='none';
      });
    });
  }

  function run(){markBody();markSections();markKnownGrids();hydrateMedia();cleanCatalogueResidue();}
  var timer=0;function schedule(){W.clearTimeout(timer);timer=W.setTimeout(run,40);}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
  W.addEventListener('load',function(){run();W.setTimeout(run,250);W.setTimeout(run,900);});
  if(W.MutationObserver){
    var root=q('#wp-theme-main')||D.body;
    if(root)new MutationObserver(function(ms){if(ms.some(function(m){return m.addedNodes&&m.addedNodes.length;}))schedule();}).observe(root,{childList:true,subtree:true});
  }
})(window,document);
