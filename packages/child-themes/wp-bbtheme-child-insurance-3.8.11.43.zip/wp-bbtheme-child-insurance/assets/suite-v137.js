(function(W,D){
  'use strict';
  var cfg=W.wpbbSuiteV137||{};
  var heroUrls=Array.isArray(cfg.heroUrls)?cfg.heroUrls.filter(Boolean):[];
  function q(s,r){try{return (r||D).querySelector(s);}catch(e){return null;}}
  function qa(s,r){try{return Array.prototype.slice.call((r||D).querySelectorAll(s));}catch(e){return [];}}
  function kids(n){return n?Array.prototype.slice.call(n.children||[]):[];}
  function txt(n){return String(n&&n.textContent||'').replace(/\s+/g,' ').trim();}
  function uniq(a){return a.filter(function(x,i){return x&&a.indexOf(x)===i;});}
  function isMain(n){return !!(n&&n.closest&&n.closest('#wp-theme-main'));}

  function markBody(){
    if(!D.body)return;
    D.body.classList.add('wpbb-v137','wpbb-v137-theme-'+String(cfg.themeKey||'sector').replace(/[^a-z0-9_-]/gi,'-'));
  }

  function sectionShells(){
    var main=q('#wp-theme-main');if(!main)return;
    qa('.wpbb-v67-section-shell,.wp-theme-section-shell',main).forEach(function(s){
      if(!s.closest('.wp-theme-sector-hero,.wp-theme-hero')&&!s.classList.contains('wp-theme-sector-hero'))s.classList.add('wpbb-v137-section');
    });
    qa('.wpbb-sector-finder,.wp-theme-insights-section,.wp-theme-case-studies-section,.wp-theme-blog-section',main).forEach(function(s){
      if(!s.closest('.wpbb-v137-section'))s.classList.add('wpbb-v137-standalone');
    });
  }

  function cellFor(card,scope){
    var n=card,depth=0;
    while(n&&n!==scope&&n!==D.body&&depth<7){
      if(n!==card&&n.matches&&n.matches('.wpbb-column,.wp-block-wpbb-column,[class*="col-"],li.product,.wpbb-grid__item'))return n;
      n=n.parentElement;depth++;
    }
    return card;
  }

  function bestGrid(cards,scope){
    cards=uniq(cards).filter(isMain);if(cards.length<2)return null;
    var groups=[];
    cards.forEach(function(card){
      var cell=cellFor(card,scope),host=cell&&cell.parentElement;if(!host||!scope.contains(host))return;
      var found=groups.filter(function(g){return g.host===host;})[0];
      if(!found){found={host:host,cells:[],cards:[]};groups.push(found);}
      if(found.cells.indexOf(cell)<0)found.cells.push(cell);
      found.cards.push(card);
    });
    groups.sort(function(a,b){return b.cards.length-a.cards.length;});
    if(groups.length&&groups[0].cards.length>=2)return groups[0];
    var host=cards[0].parentElement;
    if(host&&cards.every(function(card){return card.parentElement===host;}))return {host:host,cells:cards.slice(),cards:cards.slice()};
    return null;
  }

  function ownGrid(scope,cardSelector,cols,extraClass){
    if(!scope)return;
    var cards=uniq(qa(cardSelector,scope)).filter(function(c){return !c.closest('.swiper,.wpbb-swiper--hero');});
    var g=bestGrid(cards,scope);if(!g)return;
    g.host.classList.add('wpbb-v137-grid','wpbb-v137-cols-'+Math.max(2,Math.min(4,cols||g.cards.length)));
    if(extraClass)g.host.classList.add(extraClass);
    g.cells.forEach(function(c){c.classList.add('wpbb-v137-grid-cell');});
    g.cards.forEach(function(c){c.classList.add('wpbb-v137-card');});
  }

  function standardGrids(){
    var main=q('#wp-theme-main');if(!main)return;
    qa('.wp-theme-services-section,.wp-theme-industries-section',main).forEach(function(s){ownGrid(s,'.wp-theme-sector-card,.wpbb-icon-card',4,'wpbb-v137-feature-grid');});
    qa('.wp-theme-process-section',main).forEach(function(s){ownGrid(s,'.wp-theme-process-card,.wp-theme-sector-card,.wpbb-icon-card',3,'wpbb-v137-process-grid');});
    qa('.wp-theme-case-studies-section,.wp-theme-case-grid,.wp-theme-case-studies-grid',main).forEach(function(s){ownGrid(s,'.wp-theme-case-card',3,'wpbb-v137-case-grid');});
    qa('.wp-theme-insights-section,.wp-theme-blog-section,.wp-theme-blog-grid,.wp-theme-insights-grid',main).forEach(function(s){ownGrid(s,'.wp-theme-blog-card',3,'wpbb-v137-editorial-grid');});

    qa('.wp-theme-home-stats,.wp-theme-sector-proof',main).forEach(function(s){
      ownGrid(s,'.wpbb-fun-fact,.wp-theme-sector-proof__item',4,'wpbb-v137-stats-grid');
    });

    qa('.wpbb-sector-finder',main).forEach(function(s){
      var grid=q('.wpbb-sector-grid',s);if(!grid)return;
      var cards=kids(grid).filter(function(c){return c.matches&&c.matches('.wpbb-sector-card');});
      if(cards.length<2)return;
      grid.classList.add('wpbb-v137-grid','wpbb-v137-cols-3','wpbb-v137-finder-grid');
      cards.forEach(function(c){c.classList.add('wpbb-v137-grid-cell','wpbb-v137-card');});
    });
  }

  function catalogueGrid(){
    var main=q('#wp-theme-main');if(!main)return;
    qa('.wp-theme-home-product-catalogue',main).forEach(function(scope){
      qa('.row,.wpbb-row',scope).forEach(function(r){
        var direct=kids(r);if(!direct.length)return;
        if(direct.every(function(c){return !txt(c)&&!q('img,article,.card,.product',c);}))r.classList.add('wpbb-v137-empty-row');
      });
      var cards=uniq(qa('.wpbb-catalogue-card,.product.type-product,.type-product.product,.product-card,.iws-product-card',scope));
      var g=bestGrid(cards,scope);if(!g)return;
      g.host.classList.add('wpbb-v137-grid','wpbb-v137-cols-4','wpbb-v137-catalogue-grid');
      g.cells.forEach(function(c){c.classList.add('wpbb-v137-grid-cell','wpbb-v137-catalogue-cell');});
      g.cards.forEach(function(c){c.classList.add('wpbb-v137-card','wpbb-v137-product-card');});
    });
  }

  function mediaParent(img,card){
    if(!img||!card)return null;
    var n=img.parentElement,depth=0;
    while(n&&n!==card&&depth<3){
      if(n.matches&&n.matches('figure,picture,.wpbb-sector-card__media,.wpbb-swiper-slide__media,.wp-theme-case-card__media,.wp-theme-blog-card__media,.card-img-top'))return n;
      var text=txt(n);
      if(!text&&qa('img,picture,source',n).length<=3)return n;
      n=n.parentElement;depth++;
    }
    return img.parentElement!==card?img.parentElement:null;
  }

  function highResFromSrcset(img){
    var srcset=String(img.getAttribute('srcset')||'').trim();if(!srcset)return '';
    var best='',score=0;
    srcset.split(',').forEach(function(part){
      var bits=part.trim().split(/\s+/),url=bits[0]||'',d=bits[1]||'';
      var n=parseFloat(d)||0;if(/w$/i.test(d)&&n>score){score=n;best=url;}
    });
    return best;
  }

  function normaliseMedia(){
    var main=q('#wp-theme-main');if(!main)return;
    var cardSelector='.wpbb-sector-card,.wpbb-catalogue-card,.wp-theme-case-card,.wp-theme-blog-card,.wpbb-v137-product-card';
    qa(cardSelector,main).forEach(function(card){
      var img=q('img',card);if(!img)return;
      var media=mediaParent(img,card);if(media)media.classList.add('wpbb-v137-media');
      var best=highResFromSrcset(img);
      if(best&&best!==img.currentSrc&&best!==img.getAttribute('src')){
        img.setAttribute('src',best);img.removeAttribute('srcset');img.removeAttribute('sizes');
      }
      img.setAttribute('decoding','async');
      if(!img.closest('.wpbb-v137-hero'))img.setAttribute('loading','lazy');
      img.classList.add('wpbb-v137-image');
    });

    qa('.wp-theme-gallery-section .swiper-slide,.wp-theme-gallery-section .wpbb-swiper-slide',main).forEach(function(slide){
      slide.classList.add('wpbb-v137-gallery-card');
      var media=q('.wpbb-swiper-slide__media,.wp-theme-hero__media,.wpbb-hero-media',slide);
      if(media)media.classList.add('wpbb-v137-gallery-media');
      var img=q('img',slide);if(img){
        var best=highResFromSrcset(img);if(best){img.setAttribute('src',best);img.removeAttribute('srcset');img.removeAttribute('sizes');}
        img.setAttribute('decoding','async');img.setAttribute('loading','lazy');img.classList.add('wpbb-v137-image');
      }
    });

    qa('.wp-theme-sector-media-text__media',main).forEach(function(media){
      media.classList.add('wpbb-v137-about-media');
      var img=q('img',media);if(img){var best=highResFromSrcset(img);if(best){img.setAttribute('src',best);img.removeAttribute('srcset');img.removeAttribute('sizes');}img.setAttribute('decoding','async');img.setAttribute('loading','lazy');}
    });
  }

  function heroBlocks(){
    return uniq(qa('#wp-theme-main .wpbb-swiper--hero,#wp-theme-main .wp-theme-sector-hero .swiper,#wp-theme-main .wp-theme-hero .swiper')).filter(function(b){
      return !b.closest('.wpbb-swiper--hero')||b.classList.contains('wpbb-swiper--hero');
    });
  }
  function heroShell(block){return block&&block.closest('.wp-theme-sector-hero,.wp-theme-hero,.wp-theme-section-shell,section')||block&&block.parentElement||block;}
  function heroSlides(block){return qa('.swiper-slide',block).filter(function(s){return !s.classList.contains('swiper-slide-duplicate');});}
  function heroMedia(slide){return q('.wpbb-swiper-slide__media,.wp-theme-hero__media,.wpbb-hero-media',slide);}
  function heroRepair(){
    var blocks=heroBlocks();if(!blocks.length)return;
    blocks.forEach(function(block,index){
      var shell=heroShell(block);
      if(index>0){if(shell)shell.classList.add('wpbb-v137-hidden');return;}
      block.classList.add('wpbb-v137-hero');if(shell)shell.classList.add('wpbb-v137-hero-shell');
      heroSlides(block).forEach(function(slide,i){
        var media=heroMedia(slide)||slide,img=q('img',media);if(!img&&heroUrls[i]){img=D.createElement('img');media.appendChild(img);}
        if(!img)return;
        if(heroUrls.length)img.src=heroUrls[i%heroUrls.length];
        img.removeAttribute('srcset');img.removeAttribute('sizes');img.loading='eager';img.decoding='async';
        try{img.fetchPriority=i===0?'high':'auto';}catch(e){}
        img.classList.add('wpbb-v137-hero-image');
      });
    });
  }

  function run(){markBody();sectionShells();standardGrids();catalogueGrid();normaliseMedia();heroRepair();}
  var pending=false;function schedule(){if(pending)return;pending=true;W.setTimeout(function(){pending=false;run();},60);}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
  W.addEventListener('load',function(){run();W.setTimeout(run,300);W.setTimeout(run,900);});
  if(W.MutationObserver){
    var root=q('#wp-theme-main')||D.body;
    if(root)new MutationObserver(function(ms){if(ms.some(function(m){return m.addedNodes&&m.addedNodes.length;}))schedule();}).observe(root,{childList:true,subtree:true});
  }
})(window,document);
