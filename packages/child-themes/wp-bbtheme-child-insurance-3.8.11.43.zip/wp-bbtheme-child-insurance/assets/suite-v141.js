(function(W,D){
  'use strict';
  var cfg=W.wpbbSuiteV141||{};
  function q(s,r){try{return (r||D).querySelector(s);}catch(e){return null;}}
  function qa(s,r){try{return Array.prototype.slice.call((r||D).querySelectorAll(s));}catch(e){return [];}}
  function recoverImage(img){
    if(!img)return;
    var src=img.getAttribute('data-src')||img.getAttribute('data-lazy-src')||img.getAttribute('data-original')||'';
    if(src&&(!img.getAttribute('src')||/^data:/i.test(img.getAttribute('src'))||/placeholder/i.test(img.getAttribute('src'))))img.setAttribute('src',src);
    img.style.opacity='1';img.style.visibility='visible';
    img.classList.remove('lazyload','lazyloading');img.classList.add('lazyloaded');
  }
  function hero(){
    var urls=Array.isArray(cfg.heroUrls)?cfg.heroUrls.filter(Boolean):[];
    var slides=qa('#wp-theme-main .wp-theme-sector-hero .wpbb-swiper--hero .wpbb-swiper-slide--hero');
    slides.forEach(function(slide,i){
      var media=q('.wpbb-swiper-slide__media',slide);if(!media)return;
      var img=q('img',media);
      if(!img&&urls.length){img=D.createElement('img');img.alt='';media.appendChild(img);}
      if(img&&urls.length){img.setAttribute('src',urls[i%urls.length]);img.removeAttribute('srcset');img.removeAttribute('sizes');img.loading='eager';}
      recoverImage(img);
    });
  }
  function media(){qa('#wp-theme-main .wp-theme-about-section img,#wp-theme-main .wp-theme-cases-section img,#wp-theme-main .wp-theme-case-studies-section img,#wp-theme-main .wp-theme-insights-section img,#wp-theme-main .wp-theme-blog-section img').forEach(recoverImage);}
  function run(){hero();media();}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',run,{once:true});else run();
  W.addEventListener('load',function(){run();W.setTimeout(run,250);});
})(window,document);
