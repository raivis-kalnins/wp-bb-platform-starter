(function(W,D){
  'use strict';
  var cfg=W.wpbbSuiteV140||{};
  function q(s,r){try{return (r||D).querySelector(s);}catch(e){return null;}}
  function qa(s,r){try{return Array.prototype.slice.call((r||D).querySelectorAll(s));}catch(e){return [];}}
  function text(n){return String(n&&n.textContent||'').replace(/\s+/g,' ').trim();}
  function norm(s){return String(s||'').toLowerCase().replace(/[^a-z0-9.]+/g,' ').replace(/\s+/g,' ').trim();}
  function forceImage(img,url,eager){
    if(!img)return;
    var lazy=img.getAttribute('data-src')||img.getAttribute('data-lazy-src')||img.getAttribute('data-original')||'';
    if(url)img.setAttribute('src',url);
    else if(lazy&&(!img.getAttribute('src')||/^data:/i.test(img.getAttribute('src'))||/placeholder/i.test(img.getAttribute('src'))))img.setAttribute('src',lazy);
    if(url){img.removeAttribute('srcset');img.removeAttribute('sizes');img.removeAttribute('data-srcset');}
    img.loading=eager?'eager':'lazy';img.decoding='async';
    img.style.opacity='1';img.style.visibility='visible';img.style.display='block';
    img.classList.remove('lazyload','lazyloading');img.classList.add('lazyloaded');
  }
  function ownHero(){
    var main=q('#wp-theme-main');if(!main)return;
    var blocks=qa('.wpbb-swiper--hero,.wp-theme-sector-hero .swiper,.wp-theme-sector-hero .wpbb-swiper',main);
    if(!blocks.length)return;
    blocks.forEach(function(block,idx){
      var shell=block.closest('.wp-theme-sector-hero,.wp-theme-section-shell,.wpbb-v67-section-shell,section')||block.parentElement;
      if(idx>0){if(shell)shell.classList.add('wpbb-v140-hidden');return;}
      block.classList.add('wpbb-v140-hero');if(shell)shell.classList.add('wpbb-v140-hero-shell');
      qa('.swiper-slide,.wpbb-swiper-slide',block).forEach(function(slide,i){
        if(slide.classList.contains('swiper-slide-duplicate'))return;
        var media=q('.wpbb-swiper-slide__media,.wp-theme-hero__media,.wpbb-hero-media',slide);
        if(!media)return;
        var img=q('img',media);if(!img&&cfg.heroUrls&&cfg.heroUrls.length){img=D.createElement('img');img.alt='';media.appendChild(img);}
        forceImage(img,(cfg.heroUrls||[])[i%(cfg.heroUrls||[]).length]||'',true);
        if(img)img.classList.add('wpbb-v140-hero-image');
      });
    });
  }
  function markSections(){
    var main=q('#wp-theme-main');if(!main)return;
    qa('.insurance-finder-section,.wp-theme-services-section,.wp-theme-about-section,.wp-theme-industries-section,.wp-theme-home-stats,.wp-theme-cases-section,.wp-theme-case-studies-section,.wp-theme-gallery-section,.wp-theme-shop-section,.wp-theme-process-section,.wp-theme-faq-section,.wp-theme-insights-section,.wp-theme-blog-section',main).forEach(function(s){s.classList.add('wpbb-v140-section');});
  }
  function productFallbacks(){
    var map=cfg.products||{};
    qa('#wp-theme-main .wpbb-sector-card').forEach(function(card){
      var title=text(q('h2,h3,h4',card));var key=norm(title);var url=map[key]||'';if(!url)return;
      var host=q('.wpbb-sector-card__media,figure,a',card);var img=q('img',host||card);forceImage(img,url,true);
      if(host){host.style.backgroundImage='url("'+String(url).replace(/"/g,'%22')+'")';host.style.backgroundSize='cover';host.style.backgroundPosition='center';}
    });
    qa('#wp-theme-main .wpbb-v140-product-card').forEach(function(card){var img=q('img',card);forceImage(img,'',true);});
  }
  function galleryFallbacks(){
    var urls=cfg.gallery||[];
    qa('#wp-theme-main .wpbb-v140-gallery-card').forEach(function(card,i){var img=q('img',card);forceImage(img,urls[i%urls.length]||'',true);});
  }
  function makeAllHomeMediaVisible(){
    var main=q('#wp-theme-main');if(!main)return;
    qa('.wp-theme-about-section img,.wp-theme-case-studies-section img,.wp-theme-cases-section img,.wp-theme-insights-section img,.wp-theme-blog-section img',main).forEach(function(img){forceImage(img,'',true);});
  }
  function removeStaleRuntimeClasses(){
    var main=q('#wp-theme-main');if(!main)return;
    qa('[class*="wpbb-v137-grid"],[class*="wpbb-v138-grid"]',main).forEach(function(n){
      Array.prototype.slice.call(n.classList).forEach(function(c){if(/^wpbb-v13[78]-(grid|cols|cell|card|feature|process|case|editorial|stats|finder|catalogue)/.test(c))n.classList.remove(c);});
    });
  }
  function run(){if(D.body)D.body.classList.add('wpbb-v140');removeStaleRuntimeClasses();markSections();ownHero();productFallbacks();galleryFallbacks();makeAllHomeMediaVisible();}
  var t=0;function schedule(){W.clearTimeout(t);t=W.setTimeout(run,20);}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
  W.addEventListener('load',function(){run();W.setTimeout(run,250);});
})(window,document);
