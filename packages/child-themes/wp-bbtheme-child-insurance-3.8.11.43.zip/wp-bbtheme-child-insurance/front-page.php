<?php
/**
 * Dedicated insurance homepage layout — v3.8.11.43.
 * A single semantic grid avoids inherited Gutenberg/Bootstrap layout drift.
 */
defined( 'ABSPATH' ) || exit;
get_header();

$theme_uri = trailingslashit( get_stylesheet_directory_uri() );
$img = static function( $relative ) use ( $theme_uri ) {
    return $theme_uri . ltrim( $relative, '/' );
};
$page_url = static function( $slug ) {
    if ( function_exists( 'wp_theme_demo_page_url' ) ) return wp_theme_demo_page_url( $slug );
    return home_url( '/' . trim( $slug, '/' ) . '/' );
};

$products = array(
    array( 'Car Roadside', 'Cars', 'Essential roadside assistance and short-distance recovery.', 'product-1.jpg' ),
    array( 'Euro Plus', 'Cars', 'Comprehensive UK and European roadside cover.', 'product-2.jpg' ),
    array( 'Home Plus', 'Cars', 'Roadside and home assistance with nationwide recovery.', 'product-3.jpg' ),
    array( 'Mobility Plus', 'Mobility', 'Breakdown assistance designed for mobility vehicles.', 'product-4.jpg' ),
    array( 'Motorbike Plus', 'Motorbikes', 'Roadside and recovery cover for motorcycles.', 'product-5.jpg' ),
    array( 'Roadside Plus', 'Cars', 'Roadside help with extended local recovery.', 'product-6.jpg' ),
    array( 'UK Plus', 'Cars', 'Roadside assistance and nationwide UK recovery.', 'product-7.jpg' ),
    array( 'Van Roadside 3.5T', 'Vans', 'Roadside assistance for eligible light commercial vans.', 'product-8.jpg' ),
);

$product_links = array();
if ( class_exists( 'WP_Query' ) ) {
    $q = new WP_Query( array( 'post_type'=>'product', 'post_status'=>'publish', 'posts_per_page'=>32, 'no_found_rows'=>true ) );
    while ( $q->have_posts() ) {
        $q->the_post();
        $product_links[ strtolower( trim( get_the_title() ) ) ] = get_permalink();
    }
    wp_reset_postdata();
}
$product_url = static function( $title ) use ( $product_links ) {
    $key = strtolower( trim( $title ) );
    return $product_links[ $key ] ?? ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' ) );
};

$posts = get_posts( array( 'post_type'=>'post', 'post_status'=>'publish', 'posts_per_page'=>3, 'orderby'=>'date', 'order'=>'DESC' ) );
?>
<main id="primary" class="ins143-home">
    <section class="ins143-hero" aria-labelledby="ins143-hero-title">
        <div class="ins143-shell ins143-hero-grid">
            <div class="ins143-hero-copy">
                <p class="ins143-kicker">Cover packages, easier to compare</p>
                <h1 id="ins143-hero-title">Insurance packages that explain the cover before the checkout.</h1>
                <p class="ins143-lead">Filter cover by vehicle and level, compare benefits, choose monthly or yearly options and use WooCommerce for basket, checkout, orders and account management.</p>
                <div class="ins143-actions"><a class="ins143-btn" href="#finder">Find cover</a><a class="ins143-link" href="<?php echo esc_url( $page_url('services') ); ?>">Explore services</a></div>
            </div>
        </div>
        <figure class="ins143-hero-media"><img src="<?php echo esc_url( $img('assets/img/hero-v136/slide-1.jpg') ); ?>" alt="Insurance protection concept" fetchpriority="high" decoding="async"></figure>
    </section>

    <section class="ins143-partners" aria-label="Trusted partners">
        <div class="ins143-shell ins143-partner-grid">
            <?php foreach ( array('Northstar','Atlas','Horizon','Summit','Vertex') as $name ) : ?>
                <div class="ins143-partner"><span aria-hidden="true"><?php echo esc_html( substr( $name, 0, 1 ) ); ?></span><?php echo esc_html( $name ); ?></div>
            <?php endforeach; ?>
        </div>
    </section>

    <section id="finder" class="ins143-section ins143-white">
        <div class="ins143-shell">
            <div class="ins143-finder-box">
                <div class="ins143-heading ins143-heading-wide"><p class="ins143-kicker">Cover finder</p><h2>Find cover for your vehicle and priorities.</h2><p>Compare packages, then configure billing and assistance options before continuing.</p></div>
                <form class="ins143-filter" action="<?php echo esc_url( function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/') ); ?>" method="get">
                    <label>Vehicle<select name="vehicle"><option>Any vehicle</option><option>Car</option><option>Van</option><option>Motorbike</option><option>Mobility</option></select></label>
                    <label>Cover level<select name="cover"><option>Any cover</option><option>Roadside</option><option>Home</option><option>UK recovery</option><option>European</option></select></label>
                    <label>Max monthly price<select name="price"><option>No maximum</option><option>£10</option><option>£15</option><option>£25</option></select></label>
                    <button class="ins143-btn" type="submit">Find cover</button>
                </form>
                <p class="ins143-result-count">8 packages matching your choices</p>
                <div class="ins143-grid ins143-grid-3">
                    <?php foreach ( $products as $p ) : ?>
                        <article class="ins143-card ins143-product-card">
                            <a class="ins143-card-media" href="<?php echo esc_url( $product_url($p[0]) ); ?>"><img src="<?php echo esc_url( $img('assets/img/demo/'.$p[3]) ); ?>" alt="<?php echo esc_attr($p[0]); ?>" loading="lazy" decoding="async"></a>
                            <div class="ins143-card-body"><p class="ins143-kicker"><?php echo esc_html($p[1]); ?></p><h3><a href="<?php echo esc_url( $product_url($p[0]) ); ?>"><?php echo esc_html($p[0]); ?></a></h3><p><?php echo esc_html($p[2]); ?></p><a class="ins143-text-link" href="<?php echo esc_url( $product_url($p[0]) ); ?>">Configure cover →</a></div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <section class="ins143-section ins143-tint">
        <div class="ins143-shell">
            <div class="ins143-heading"><p class="ins143-kicker">What we do</p><h2>Cover packages, quotes and account journeys in one familiar WooCommerce flow.</h2></div>
            <div class="ins143-grid ins143-grid-4">
                <?php foreach ( array(
                    array('Roadside cover','Entry-level assistance with clear recovery limits.'),
                    array('Home assistance','Help when the vehicle will not start at home.'),
                    array('UK recovery','Nationwide recovery options for longer-distance support.'),
                    array('European cover','Packages for customers who regularly drive abroad.')
                ) as $s ) : ?><article class="ins143-icon-card"><span>✓</span><h3><?php echo esc_html($s[0]); ?></h3><p><?php echo esc_html($s[1]); ?></p></article><?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="ins143-section ins143-white">
        <div class="ins143-shell ins143-split">
            <figure class="ins143-split-media"><img src="<?php echo esc_url( $img('assets/img/demo/about-photo.jpg') ); ?>" alt="Protection for customers" loading="lazy" decoding="async"></figure>
            <div class="ins143-split-copy"><p class="ins143-kicker">Why choose us</p><h2>A package-led insurance site with clearer comparison and checkout.</h2><p>The package finder follows useful breakdown-cover patterns: vehicle type, feature-led cards, configurable purchase options and a complete account journey.</p><a class="ins143-btn" href="<?php echo esc_url( $page_url('services') ); ?>">Explore services</a></div>
        </div>
    </section>

    <section class="ins143-section ins143-white ins143-solutions">
        <div class="ins143-shell">
            <div class="ins143-heading"><p class="ins143-kicker">Built around your needs</p><h2>Cover for cars, vans, motorbikes and mobility needs.</h2></div>
            <div class="ins143-grid ins143-grid-4">
                <?php foreach ( array(
                    array('Cars','Cover packages for everyday passenger vehicles.'),array('Vans','Commercial-vehicle options with weight and size considerations.'),array('Motorbikes','Roadside and recovery choices for motorcycles.'),array('Mobility','Accessible vehicle cover with clear assistance features.')
                ) as $s ) : ?><article class="ins143-icon-card"><span>✓</span><h3><?php echo esc_html($s[0]); ?></h3><p><?php echo esc_html($s[1]); ?></p></article><?php endforeach; ?>
            </div>
            <div class="ins143-grid ins143-grid-4 ins143-stats">
                <?php foreach ( array(array('8','Cover packages'),array('4','Vehicle groups'),array('2','Billing cycles'),array('1','Quote + account flow')) as $st ) : ?><div class="ins143-stat"><strong><?php echo esc_html($st[0]); ?></strong><span><?php echo esc_html($st[1]); ?></span></div><?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="ins143-section ins143-white">
        <div class="ins143-shell">
            <div class="ins143-heading"><p class="ins143-kicker">Selected stories</p><h2>Recent work and measurable outcomes.</h2></div>
            <div class="ins143-grid ins143-grid-3">
                <?php foreach ( array(
                    array('01','Roadside comparison refresh','Eight packages reorganised around vehicle type, recovery area and price.','8','cover packages'),
                    array('02','Quote journey redesign','Vehicle and renewal information captured before team follow-up.','42%','fewer incomplete leads'),
                    array('03','Account journey cleanup','Purchase, account and policy contact routes brought into one navigation system.','1','clear customer hub')
                ) as $c ) : ?><article class="ins143-case"><span><?php echo esc_html($c[0]); ?></span><h3><?php echo esc_html($c[1]); ?></h3><p><?php echo esc_html($c[2]); ?></p><div><strong><?php echo esc_html($c[3]); ?></strong><small><?php echo esc_html($c[4]); ?></small></div></article><?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="ins143-section ins143-soft">
        <div class="ins143-shell">
            <div class="ins143-heading"><p class="ins143-kicker">Gallery</p><h2>A closer look at the work, people and places behind the service.</h2></div>
            <div class="ins143-grid ins143-grid-3">
                <?php foreach ( array(array('item-1.jpg','Personal insurance guidance'),array('item-2.jpg','Home insurance'),array('item-4.jpg','Vehicle cover')) as $g ) : ?><article class="ins143-gallery-card"><img src="<?php echo esc_url( $img('assets/img/demo/'.$g[0]) ); ?>" alt="<?php echo esc_attr($g[1]); ?>" loading="lazy" decoding="async"><h3><?php echo esc_html($g[1]); ?></h3></article><?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="ins143-section ins143-soft">
        <div class="ins143-shell">
            <div class="ins143-heading"><p class="ins143-kicker">Shop</p><h2>Find the right product without the noise.</h2></div>
            <div class="ins143-grid ins143-grid-4">
                <?php foreach ( $products as $p ) : ?><article class="ins143-card ins143-catalogue-card"><a class="ins143-card-media" href="<?php echo esc_url( $product_url($p[0]) ); ?>"><img src="<?php echo esc_url( $img('assets/img/demo/'.$p[3]) ); ?>" alt="<?php echo esc_attr($p[0]); ?>" loading="lazy" decoding="async"></a><div class="ins143-card-body"><p class="ins143-kicker"><?php echo esc_html($p[1]); ?></p><h3><a href="<?php echo esc_url( $product_url($p[0]) ); ?>"><?php echo esc_html($p[0]); ?></a></h3><p><?php echo esc_html($p[2]); ?></p><a class="ins143-btn ins143-btn-small" href="<?php echo esc_url( $product_url($p[0]) ); ?>">Open card</a></div></article><?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="ins143-section ins143-tint">
        <div class="ins143-shell">
            <div class="ins143-heading"><p class="ins143-kicker">How it works</p><h2>Filter packages, compare benefits and complete the cover purchase in WooCommerce.</h2></div>
            <div class="ins143-grid ins143-grid-3">
                <?php foreach ( array(array('01','Filter','Choose vehicle type, cover level and budget.'),array('02','Configure','Select monthly/yearly billing and optional assistance.'),array('03','Buy','Use basket, checkout, order confirmation and My Account.')) as $s ) : ?><article class="ins143-process"><span><?php echo esc_html($s[0]); ?></span><h3><?php echo esc_html($s[1]); ?></h3><p><?php echo esc_html($s[2]); ?></p></article><?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="ins143-section ins143-white">
        <div class="ins143-shell">
            <div class="ins143-heading"><p class="ins143-kicker">FAQ</p><h2>Cover, payment and assistance questions answered before purchase.</h2></div>
            <div class="ins143-faq">
                <?php foreach ( array(
                    array('Can I change every section?','Yes. The page uses straightforward WordPress theme output and can be adapted as the project evolves.'),
                    array('Can the website grow with the organisation?','Yes. Keep the structure and add the integrations the active project actually needs.'),
                    array('Will the imported menus remain editable?','Yes. Header, utility and footer navigation remain normal WordPress menus.')
                ) as $i=>$f ) : ?><details <?php echo $i===0?'open':''; ?>><summary><?php echo esc_html($f[0]); ?></summary><p><?php echo esc_html($f[1]); ?></p></details><?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="ins143-section ins143-white">
        <div class="ins143-shell">
            <div class="ins143-heading ins143-heading-row"><div><p class="ins143-kicker">Latest thinking</p><h2>Latest guides, news and practical advice.</h2></div><a class="ins143-link" href="<?php echo esc_url( $page_url('blog') ); ?>">View all articles</a></div>
            <div class="ins143-grid ins143-grid-3">
                <?php if ( $posts ) : foreach ( $posts as $index=>$post ) : setup_postdata($post); $thumb=get_the_post_thumbnail_url($post,'large'); if(!$thumb){$fallback=array('blog-1.jpg','blog-2.jpg','blog-3.jpg');$thumb=$img('assets/img/blog/'.$fallback[$index%3]);} ?><article class="ins143-card ins143-news-card"><a class="ins143-card-media" href="<?php the_permalink(); ?>"><img src="<?php echo esc_url($thumb); ?>" alt="" loading="lazy" decoding="async"></a><div class="ins143-card-body"><p class="ins143-meta"><?php echo esc_html( get_the_date('j F Y') ); ?></p><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18 ) ); ?></p><a class="ins143-text-link" href="<?php the_permalink(); ?>">Read article →</a></div></article><?php endforeach; wp_reset_postdata(); else : ?>
                    <?php foreach ( array(array('blog-1.jpg','How yearly and monthly roadside plans differ'),array('blog-2.jpg','What van drivers should check before buying cover'),array('blog-3.jpg','A practical guide to European breakdown cover')) as $b ) : ?><article class="ins143-card ins143-news-card"><div class="ins143-card-media"><img src="<?php echo esc_url($img('assets/img/blog/'.$b[0])); ?>" alt="" loading="lazy"></div><div class="ins143-card-body"><h3><?php echo esc_html($b[1]); ?></h3><p>A concise guide with clear hierarchy and practical next steps.</p></div></article><?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

</main>
<?php get_footer(); ?>
