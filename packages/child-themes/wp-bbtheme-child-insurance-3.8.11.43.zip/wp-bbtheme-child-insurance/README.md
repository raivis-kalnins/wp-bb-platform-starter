## 3.8.11.43 full-bleed hero and footer repair
- Makes the homepage hero genuinely viewport-wide while keeping the copy locked to the shared 1180px content grid; the 2560px hero artwork runs from the grid midpoint to the right browser edge.
- Removes the duplicate homepage newsletter so the footer renders one green subscription band only.
- Repairs the parent footer on the same 1180px grid as the homepage, removes double container padding and resets Bootstrap row/column drift.
- Restores the intended white footer body with navy text, a green newsletter band, aligned fields, and responsive 3/2/1-column footer behaviour.
- Keeps the v142 deterministic homepage grids and local card imagery unchanged.

## 3.8.11.42 clean homepage geometry owner
- Stops loading the cumulative v119-v140 layout layers and returns the frontend to the stable v118 base before applying one new homepage-only geometry layer.
- Restores the hero as a full-width section with bundled 2560px imagery, aligned copy, stable height and responsive stacking.
- Uses one 1180px shell, 24px desktop gutter and consistent vertical rhythm for every normal homepage section, plus the header and footer.
- Resets Bootstrap row/column drift so finder, services, solutions, stats, cases, gallery, products, process, FAQ and Latest Thinking begin on the same left/right grid.
- Keeps deterministic server-rendered process, gallery and WooCommerce catalogue markup without runtime DOM rebuilding.
- Uses 16:10 local high-resolution media for finder/product/gallery/editorial cards and the about section.

## 3.8.11.40 single homepage layout owner
- Removes the competing v119-v139 frontend layout runtimes so one script owns homepage geometry instead of several mutation passes fighting each other.
- Rebuilds the process cards as deterministic three-column server-rendered cards so the Filter / Configure / Buy section cannot collapse into rounded placeholder pills.
- Rebuilds the homepage gallery as a stable three-card grid using bundled local imagery, eliminating the grey first-slide/lazy-load failure.
- Rebuilds the WooCommerce homepage catalogue with a deterministic product-to-image map so every product card has a real 16:10 image and equal-height grid geometry.
- Forces every non-hero homepage section onto the same 1180px shell, 24px desktop gap and consistent vertical rhythm, including the separate stats and FAQ sections.
- Restores clipped/missing section headings and gives the hero its own full-bleed geometry so the headline is no longer cut off by inherited row/slider rules.
- Keeps responsive 2-column tablet and 1-column mobile layouts without Bootstrap percentage-width leakage.

## 3.8.11.39 homepage grid and image hardening
- Replaces the managed homepage WooCommerce catalogue block with a flat server-rendered 4 x 2 grid, removing the nested Bootstrap-column failure that produced narrow vertical product slivers.
- Forces section heading rows back to a single full-width flow so headings cannot inherit card-grid column widths.
- Reasserts one 1180px shell and 24px gap for services, solutions, stats, finder, case-study, process and editorial areas.
- Uses the same 16:10 media frame for finder, gallery, about, editorial and catalogue imagery.
- Hydrates gallery/editorial imagery from bundled high-resolution assets and makes homepage media eager so full-page captures do not show grey lazy placeholders.
- Keeps the existing full-bleed high-resolution hero treatment intact.

## 3.8.11.37 alignment, grid and media consistency
- Uses one late frontend layout owner so older repair scripts cannot race and re-collapse grids.
- Aligns non-hero homepage sections to the same 1180px content shell and 24px card gutter.
- Normalises services, solutions, process, stats, finder, case-study, editorial and catalogue rows with responsive CSS Grid geometry.
- Fixes the home product catalogue sliver regression by resetting stale Bootstrap percentage widths on the actual product-cell row.
- Uses a consistent 16:10 crop for card/gallery media and promotes the largest available `srcset` candidate for sharper demo imagery.
- Keeps the hero full-bleed and uses the bundled 2560px slide sources without blur/upscale filters.

## 3.8.11.16 reset-safe final release fixes
- Demo reset/import now re-runs the canonical managed BBuilder page rebuild and all v116 repairs automatically.
- The old migration that removed legitimate responsive BBuilder column widths is disabled; desktop multi-column layouts survive a clean demo reset.
- Desktop mega menus use the measured header bottom plus a hover bridge, matching the close Jobs positioning across all children.
- Home hero sliders use three distinct child-owned images, visible pagination, 8.5-second autoplay and pause-on-hover with sharp natural-scale rendering.
- Managed demo/editorial/catalogue/gallery/Woo media is restored from bundled files; Woo Clothes keeps the complete bundled product-image pool.
- Quote drawers use resilient trigger detection and sit flush to the right viewport edge on quote-enabled themes.
- Cookie-consent acceptance persists across reloads using a stable browser marker.
- Legal pages remain left-aligned on the normal grid; Latest Thinking media/card edges are normalized.
- Partner/brand serialization is normalized idempotently to prevent repeated wrappers and the `wpbb/column` validation warning.
- Theme Settings retain child-owned controls for disabling dark mode and keeping English-only Polylang content.

## 3.8.11.14 child-only settings, editor, legal, editorial and hero finish

- Latest Thinking card rows now use the same 1320px grid as their headings; the 1440px row override that shifted the first card left has been removed.
- Hero images use a direct child-owned native source, stronger left-edge gradient masking and no CSS blur/viewport stretching.
- Appearance > Theme Settings adds switches to disable dark mode and disable translations/keep English only. Enabling English-only moves non-English Polylang Pages and Posts to Trash and hides the language switcher.
- Privacy/Terms/Cookies content spans the normal site grid and is left-aligned instead of being forced into a centered narrow column.
- The known raw partner-heading serialization defect is repaired in imported pages and on future page saves, resolving the wpbb/column validation error.
- Child editor CSS is moved from enqueue_block_editor_assets to enqueue_block_assets for the WordPress editor iframe.

## 3.8.11.13 child-only hero and editorial grid finish

- Latest Thinking / related editorial cards use the full 1440px site grid; the legacy outer BBuilder row and list start padding can no longer create a first-card left inset.
- Homepage heroes use a native-resolution child asset without viewport-width stretching.
- A stronger white-to-transparent hero gradient crosses the photograph's left edge so the image seam is hidden.
- Existing and translated managed hero blocks are refreshed from the same child-owned asset after upgrade.

## 3.8.11.12 child-only visual/media fixes

- Latest Thinking card grid now inherits the section grid with no first-card left inset.
- Sharper child-owned hero source and late frontend override.
- Managed catalogue and editorial media are re-synchronised from bundled child assets.
- Media/text CTA buttons align to the copy edge.

## 3.8.11.11 media and WooCommerce finalisation

- Repairs missing demo media from bundled local assets, including cloned-site WooCommerce product images and Automotive vehicle finder thumbnails.
- Forces WooCommerce filters, ranges, compare controls and product actions to the child theme accent instead of the plugin blue fallback.
- Uses a two-column desktop Basket, Checkout and My Account shell with mobile stacking only below 821px.
- Uses the highest-resolution bundled hero source during managed demo rebuilds; Business uses the 1600x1000 office source.
- Requires parent WP BBTheme 3.8.10.23 for reliable My Account header URLs on cloned sites.

## 3.8.10.82 suite consistency

Requires WP BBuilder 5.6.9+ for palette inheritance and the shared hCaptcha verifier. This release keeps the sector's individual brand colour while using the same 1440px canvas, card/form rhythm, dark-mode baseline and footer/newsletter hierarchy as the rest of the 15-theme suite. The one-time cleanup is restricted to records explicitly marked as theme-managed demo content.

## 3.8.10.65

- Fixes the Theme Settings frontend-protection panel so its CSS is loaded in the admin head instead of appearing as visible text.
- Makes sector media repair load the WordPress image API safely before generating attachment metadata.
- Refines shared card, directory, gallery and responsive alignment.
- Adds block-theme Single Product, Cart and Checkout templates while preserving the existing classic-template fallback.

## 3.8.10.47

- More compact and consistent section spacing, cards and responsive layouts.
- Smaller in-frame gallery thumbnail pagination and improved light/dark contrast.
- Reliable child-owned WooCommerce product shells where the theme includes commerce.

# WP BBTheme Child Insurance 3.8.10.65
Child theme for WP BBTheme. Built to use the shared Gutenberg/WP BBuilder design system and demo importer.

## Included
- WooCommerce cover-package catalogue
- Custom package finder inspired by feature-led breakdown cover stores
- Vehicle type, billing cycle and home-assistance add-to-cart options
- Insurance Quote custom post type with product-level quote request form
- Legacy WooCommerce basket, checkout, order and My Account shells
- Demo insurance package products and comparison content

## Requirements
- WordPress 6.6+
- PHP 8.0+
- Parent theme `wp-bbtheme` 3.7.0+
- WP BBuilder
- WooCommerce + WP Theme Woo Support

### 3.8.10.46
- Dashboard-safe, resumable sector media repair; no synchronous bulk image regeneration on `admin_init`.
- Password protection controls live under **Theme Settings → General**.
- Thumbnail navigation is overlaid inside the main gallery image.
- Active-sector Blog and directory media are repaired after child-theme switching.

## SCSS structure (3.8.10.9)

Frontend styles are split into `tokens`, `tools`, `base`, `header`, `footer`, `components`, `swiper`, `motion`, `forms`, `blog`, `quality`, `sector`, `responsive` and `features`. Fluid typography uses the suite `fluid-font()` mixin and explicit viewport guards rather than `clamp()`. The generated production CSS intentionally contains no `!important` declarations.

### Build compatibility

The child build is dependency-free and works with Yarn 1.22.x as well as newer Yarn versions. No Corepack step is required. Use:

```sh
yarn prod
```

The command runs `node tools/build.mjs` and rebuilds the hashed CSS/JS manifest directly.


### 3.8.10.45
- Consistent 80/64/52px section rhythm and explicit light/dark card contrast.
- Active-theme sector media repair for demo pages, blogs, directories and galleries.
- Top-aligned About imagery plus thumbnail and modal galleries on supported directory cards and single pages.

### 3.8.10.44
- Frontend password protection is enabled by default with password `wp@demo`.
- Administrators can disable it or set a new password in **Settings → Theme Settings** at `/wp-admin/options-general.php?page=wp-theme-settings`.
- Successful visitors receive a signed access cookie valid for 24 hours by default.
- Purge full-page/server/CDN caches after changing the protection setting.

### 3.8.10.42
- Replaced demo feature icons with Tabler Icons v3.46.0 outline SVGs, sized for normal UI use and coloured from the child-theme brand token.
- Single-column imported demo rows are repaired to 12 columns at every breakpoint.
- Dark-mode demo cards use explicit dark surfaces/readable text.
- Optional frontend-only demo password protection is available in Settings → Theme Settings (default password `wp@demo`).
### 3.8.10.43
- Shared alignment and dark-mode contrast fixes across service, solution, process, directory, blog and commerce cards.
- Current child-theme media is reapplied after child-theme switches, including optimised AVIF/WebP files.
- Visible slider/grid images are loaded deterministically and duplicate single-item summary text is removed.

## 3.8.10.65 BBuilder demo system
This release expects WP BBuilder 5.6.4+ and standardises demo editing around BBuilder Row/Column, Div, Icon Card, Swiper and selected native WordPress content blocks. Legacy Group/Columns demo markup is migrated automatically.


## 3.8.11.08
WooCommerce shop, basket, checkout and account layouts were normalised across the sector suite; theme preview artwork was refreshed and package documentation was reduced to this README.
