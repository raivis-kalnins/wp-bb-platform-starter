<?php
/** v3.8.11.43 — dedicated homepage shell. */
defined( 'ABSPATH' ) || exit;

function wpbb_child_v143_enqueue() {
    if ( ! is_front_page() ) return;
    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();
    foreach ( range( 119, 141 ) as $n ) {
        $handle = 'wpbb-suite-v' . $n;
        wp_dequeue_style( $handle ); wp_deregister_style( $handle );
        wp_dequeue_script( $handle ); wp_deregister_script( $handle );
    }
    $css = '/assets/suite-v143.css';
    wp_enqueue_style( 'wpbb-suite-v143', $uri . $css, array(), is_readable($dir.$css) ? (string) filemtime($dir.$css) : '3.8.11.43' );
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v143_enqueue', PHP_INT_MAX );

function wpbb_child_v143_body_class( $classes ) {
    if ( is_front_page() ) $classes[] = 'wpbb-v143';
    return array_values( array_unique( $classes ) );
}
add_filter( 'body_class', 'wpbb_child_v143_body_class', PHP_INT_MAX );
