<?php
/**
 * WP BBTheme child suite 3.8.11.39 — homepage spacing/alignment finish.
 *
 * Keeps the working v138 catalogue renderer and image hydration, then adds one
 * final stylesheet whose only job is section geometry/rhythm.  Also removes
 * stale malformed Gutenberg comment text that may exist in imported demo data.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v139_clean_demo_markup' ) ) {
    function wpbb_child_v139_clean_demo_markup( $content ) {
        if ( ! is_string( $content ) || '' === $content ) return $content;
        if ( false === stripos( $content, 'wp:wpbb/icon-card' ) ) return $content;

        /* Raw malformed comments, for example <!– wp:wpbb/icon-card ... /–>. */
        $content = preg_replace(
            '~<![\-–—]{1,3}\s*wp:wpbb/icon-card\b(?:(?!<![\-–—]{1,3}\s*wp:).)*?wpbb-sector-proof-card(?:(?!<![\-–—]{1,3}\s*wp:).)*?/[\-–—]{1,3}>~isu',
            '',
            $content
        );

        /* Escaped variants that WordPress may have stored as visible text. */
        $content = preg_replace(
            '~&lt;![\-–—]{1,3}\s*wp:wpbb/icon-card\b(?:(?!&lt;![\-–—]{1,3}\s*wp:).)*?wpbb-sector-proof-card(?:(?!&lt;![\-–—]{1,3}\s*wp:).)*?/[\-–—]{1,3}&gt;~isu',
            '',
            $content
        );

        return $content;
    }
}
add_filter( 'the_content', 'wpbb_child_v139_clean_demo_markup', PHP_INT_MAX );
add_filter( 'wp_theme_demo_extra_home_sections', 'wpbb_child_v139_clean_demo_markup', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v139_enqueue' ) ) {
    function wpbb_child_v139_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v139.css';

        wp_enqueue_style(
            'wpbb-suite-v139',
            $uri . $css,
            wp_style_is( 'wpbb-suite-v138', 'enqueued' ) ? array( 'wpbb-suite-v138' ) : array(),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.39'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v139_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v139_body_class' ) ) {
    function wpbb_child_v139_body_class( $classes ) {
        $classes[] = 'wpbb-v139';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v139_body_class', PHP_INT_MAX );
