<?php
/**
 * WP BBTheme child suite 3.8.11.37 — one alignment/grid/media owner.
 *
 * The homepage had accumulated several late layout repair layers.  This final
 * layer leaves the useful earlier component styling in place, but removes the
 * competing late DOM runtimes and applies one deterministic set of section,
 * grid and media classes after the page has rendered.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'wpbb_child_v137_theme_key' ) ) {
    function wpbb_child_v137_theme_key() {
        if ( function_exists( 'wpbb_child_v136_theme_key' ) ) return wpbb_child_v136_theme_key();
        $slug = basename( get_stylesheet_directory() );
        $slug = preg_replace( '/^wp-bbtheme-child-/', '', $slug );
        return sanitize_key( $slug );
    }
}

if ( ! function_exists( 'wpbb_child_v137_hero_urls' ) ) {
    function wpbb_child_v137_hero_urls() {
        if ( function_exists( 'wpbb_child_v136_hero_urls' ) ) return wpbb_child_v136_hero_urls();
        $dir  = get_stylesheet_directory();
        $uri  = get_stylesheet_directory_uri();
        $urls = array();
        foreach ( array( 1, 2, 3 ) as $i ) {
            foreach ( array( 'assets/img/hero-v136', 'assets/img/hero-v134', 'assets/img/hero-v118' ) as $base ) {
                $rel  = $base . '/slide-' . $i . '.jpg';
                $path = $dir . '/' . $rel;
                if ( is_file( $path ) ) {
                    $urls[] = $uri . '/' . $rel . '?v=' . filemtime( $path );
                    break;
                }
            }
        }
        return $urls;
    }
}

if ( ! function_exists( 'wpbb_child_v137_enqueue' ) ) {
    function wpbb_child_v137_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();

        // Only one late DOM owner.  Earlier CSS remains available for Woo and
        // specialist components, while v137 wins geometry through later,
        // body-scoped selectors.
        foreach ( range( 119, 136 ) as $n ) {
            $handle = 'wpbb-suite-v' . $n;
            wp_dequeue_script( $handle );
            wp_deregister_script( $handle );
        }

        $css = '/assets/suite-v137.css';
        $js  = '/assets/suite-v137.js';
        wp_enqueue_style(
            'wpbb-suite-v137',
            $uri . $css,
            array(),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.37'
        );
        wp_enqueue_script(
            'wpbb-suite-v137',
            $uri . $js,
            array(),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.37',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v137',
            'window.wpbbSuiteV137=' . wp_json_encode( array(
                'version'  => '3.8.11.37',
                'themeKey' => wpbb_child_v137_theme_key(),
                'heroUrls' => wpbb_child_v137_hero_urls(),
            ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v137_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v137_body_class' ) ) {
    function wpbb_child_v137_body_class( $classes ) {
        $classes[] = 'wpbb-v137';
        $classes[] = 'wpbb-v137-theme-' . wpbb_child_v137_theme_key();
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v137_body_class', PHP_INT_MAX );
