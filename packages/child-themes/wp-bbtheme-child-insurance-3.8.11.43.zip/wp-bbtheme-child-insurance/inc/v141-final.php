<?php
/**
 * WP BBTheme child suite 3.8.11.41 — clean homepage geometry owner.
 *
 * This deliberately starts from the stable v118 runtime and does not load the
 * cumulative v119-v140 layout layers. It owns only the homepage hero, common
 * section shell, product catalogue, gallery and process-card output.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v141_asset_url' ) ) {
    function wpbb_child_v141_asset_url( $relative ) {
        $relative = ltrim( str_replace( '\\', '/', (string) $relative ), '/' );
        if ( '' === $relative || false !== strpos( $relative, '../' ) ) return '';
        $path = get_stylesheet_directory() . '/' . $relative;
        if ( ! is_readable( $path ) ) return '';
        return add_query_arg( 'v', (string) filemtime( $path ), trailingslashit( get_stylesheet_directory_uri() ) . $relative );
    }
}

if ( ! function_exists( 'wpbb_child_v141_hero_urls' ) ) {
    function wpbb_child_v141_hero_urls() {
        $urls = array();
        foreach ( array( 1, 2, 3 ) as $i ) {
            foreach ( array(
                'assets/img/hero-v136/slide-' . $i . '.jpg',
                'assets/img/hero-v118/slide-' . $i . '.jpg',
                'assets/img/demo/slide-' . $i . '.jpg',
            ) as $relative ) {
                $url = wpbb_child_v141_asset_url( $relative );
                if ( $url ) {
                    $urls[] = $url;
                    break;
                }
            }
        }
        return array_values( array_unique( $urls ) );
    }
}

if ( ! function_exists( 'wpbb_child_v141_normalize_hero_attrs' ) ) {
    function wpbb_child_v141_normalize_hero_attrs( $attrs ) {
        if ( ! is_array( $attrs ) || 'hero' !== sanitize_key( (string) ( $attrs['demoStyle'] ?? '' ) ) ) return $attrs;
        $urls = wpbb_child_v141_hero_urls();
        if ( ! $urls ) return $attrs;
        $attrs['autoplay']       = true;
        $attrs['autoplayDelay']  = 8500;
        $attrs['pauseOnHover']   = true;
        $attrs['showPagination'] = true;
        $attrs['loop']           = true;
        $attrs['rewind']         = true;
        $attrs['speed']          = 850;
        if ( ! empty( $attrs['slides'] ) && is_array( $attrs['slides'] ) ) {
            foreach ( $attrs['slides'] as $index => $slide ) {
                if ( is_array( $slide ) ) $attrs['slides'][ $index ]['image'] = $urls[ $index % count( $urls ) ];
            }
        }
        if ( ! empty( $attrs['slidesJson'] ) && is_string( $attrs['slidesJson'] ) ) {
            $slides = json_decode( $attrs['slidesJson'], true );
            if ( is_array( $slides ) ) {
                foreach ( $slides as $index => $slide ) {
                    if ( is_array( $slide ) ) $slides[ $index ]['image'] = $urls[ $index % count( $urls ) ];
                }
                $attrs['slidesJson'] = wp_json_encode( $slides, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            }
        }
        return $attrs;
    }
}

if ( ! function_exists( 'wpbb_child_v141_render_block_data' ) ) {
    function wpbb_child_v141_render_block_data( $parsed_block, $source_block, $parent_block = null ) {
        if ( is_array( $parsed_block ) && 'wpbb/swiper' === (string) ( $parsed_block['blockName'] ?? '' ) ) {
            $parsed_block['attrs'] = wpbb_child_v141_normalize_hero_attrs( (array) ( $parsed_block['attrs'] ?? array() ) );
        }
        return $parsed_block;
    }
    add_filter( 'render_block_data', 'wpbb_child_v141_render_block_data', PHP_INT_MAX, 3 );
}

if ( ! function_exists( 'wpbb_child_v141_demo_profile' ) ) {
    function wpbb_child_v141_demo_profile( $profile ) {
        if ( ! is_array( $profile ) ) return $profile;
        $urls = wpbb_child_v141_hero_urls();
        if ( $urls ) {
            $profile['hero_image'] = $urls[0];
            if ( ! empty( $profile['hero_slides'] ) && is_array( $profile['hero_slides'] ) ) {
                foreach ( $profile['hero_slides'] as $index => $slide ) {
                    if ( is_array( $slide ) ) $profile['hero_slides'][ $index ]['image'] = $urls[ $index % count( $urls ) ];
                }
            }
        }
        return $profile;
    }
    add_filter( 'wp_theme_demo_profile', 'wpbb_child_v141_demo_profile', PHP_INT_MAX );
}

if ( ! function_exists( 'wpbb_child_v141_product_image_map' ) ) {
    function wpbb_child_v141_product_image_map() {
        return array(
            'car roadside'      => 'assets/img/demo/product-1.jpg',
            'roadside plus'     => 'assets/img/demo/product-2.jpg',
            'home plus'         => 'assets/img/demo/product-3.jpg',
            'uk plus'           => 'assets/img/demo/product-4.jpg',
            'euro plus'         => 'assets/img/demo/product-5.jpg',
            'van roadside 3.5t' => 'assets/img/demo/product-6.jpg',
            'motorbike plus'    => 'assets/img/demo/product-7.jpg',
            'mobility plus'     => 'assets/img/demo/product-8.jpg',
        );
    }
}

if ( ! function_exists( 'wpbb_child_v141_process_card' ) ) {
    function wpbb_child_v141_process_card( $block_content, $block ) {
        if ( is_admin() || ! is_front_page() ) return $block_content;
        if ( ! is_array( $block ) || 'wpbb/icon-card' !== (string) ( $block['blockName'] ?? '' ) ) return $block_content;
        $attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
        $class = (string) ( $attrs['className'] ?? '' );
        if ( false === strpos( $class, 'wp-theme-process-card' ) ) return $block_content;

        $raw_title = trim( wp_strip_all_tags( (string) ( $attrs['title'] ?? '' ) ) );
        $text      = trim( wp_strip_all_tags( (string) ( $attrs['text'] ?? '' ) ) );
        $step      = '';
        $title     = $raw_title;
        if ( preg_match( '/^\s*(\d{1,2})\s+(.+)$/u', $raw_title, $m ) ) {
            $step  = str_pad( $m[1], 2, '0', STR_PAD_LEFT );
            $title = trim( $m[2] );
        }
        if ( '' === $step ) $step = '01';

        return '<article class="wpbb-v141-process-card">'
            . '<span class="wpbb-v141-process-step">' . esc_html( $step ) . '</span>'
            . ( '' !== $title ? '<h3>' . esc_html( $title ) . '</h3>' : '' )
            . ( '' !== $text ? '<p>' . esc_html( $text ) . '</p>' : '' )
            . '</article>';
    }
    add_filter( 'render_block', 'wpbb_child_v141_process_card', PHP_INT_MAX, 2 );
}

if ( ! function_exists( 'wpbb_child_v141_gallery' ) ) {
    function wpbb_child_v141_gallery( $block_content, $block ) {
        if ( is_admin() || ! is_front_page() ) return $block_content;
        if ( ! is_array( $block ) || 'wpbb/swiper' !== (string) ( $block['blockName'] ?? '' ) ) return $block_content;
        $attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
        if ( 'gallery' !== sanitize_key( (string) ( $attrs['demoStyle'] ?? '' ) ) ) return $block_content;

        $cards = array(
            array( 'assets/img/demo/item-1.jpg', __( 'Personal insurance guidance', 'wp-bbtheme-child-insurance' ) ),
            array( 'assets/img/demo/item-2.jpg', __( 'Home insurance', 'wp-bbtheme-child-insurance' ) ),
            array( 'assets/img/demo/item-4.jpg', __( 'Vehicle cover', 'wp-bbtheme-child-insurance' ) ),
        );
        ob_start();
        ?>
        <div class="wpbb-v141-gallery-grid">
            <?php foreach ( $cards as $card ) : $src = wpbb_child_v141_asset_url( $card[0] ); if ( ! $src ) continue; ?>
                <article class="wpbb-v141-gallery-card">
                    <figure class="wpbb-v141-gallery-media"><img src="<?php echo esc_url( $src ); ?>" alt="<?php echo esc_attr( $card[1] ); ?>" loading="eager" decoding="async"></figure>
                    <div class="wpbb-v141-gallery-body"><p class="wp-theme-sector-eyebrow"><?php echo esc_html__( 'Gallery', 'wp-bbtheme-child-insurance' ); ?></p><h3><?php echo esc_html( $card[1] ); ?></h3></div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php
        return trim( ob_get_clean() );
    }
    add_filter( 'render_block', 'wpbb_child_v141_gallery', PHP_INT_MAX, 2 );
}

if ( ! function_exists( 'wpbb_child_v141_catalogue' ) ) {
    function wpbb_child_v141_catalogue( $block_content, $block ) {
        if ( is_admin() || ! is_front_page() ) return $block_content;
        if ( ! is_array( $block ) || 'wpbb/catalogue' !== (string) ( $block['blockName'] ?? '' ) ) return $block_content;
        $attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
        $class = (string) ( $attrs['className'] ?? '' );
        if ( false === strpos( $class, 'wp-theme-home-product-catalogue' ) && false === strpos( (string) $block_content, 'wp-theme-home-product-catalogue' ) ) return $block_content;
        if ( ! class_exists( 'WP_Query' ) ) return $block_content;

        $query = new WP_Query( array(
            'post_type'           => 'product',
            'post_status'         => 'publish',
            'posts_per_page'      => 8,
            'orderby'             => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
            'order'               => 'ASC',
            'ignore_sticky_posts' => true,
            'no_found_rows'       => true,
        ) );
        if ( ! $query->have_posts() ) return $block_content;

        $map = wpbb_child_v141_product_image_map();
        ob_start();
        ?>
        <div class="wp-theme-home-product-catalogue wpbb-v141-catalogue">
            <div class="wpbb-v141-product-grid">
                <?php while ( $query->have_posts() ) : $query->the_post();
                    $id      = get_the_ID();
                    $title   = get_the_title( $id );
                    $url     = get_permalink( $id );
                    $excerpt = trim( wp_strip_all_tags( get_the_excerpt( $id ) ) );
                    if ( '' === $excerpt ) $excerpt = trim( wp_strip_all_tags( (string) get_post_field( 'post_content', $id ) ) );
                    $excerpt = wp_trim_words( $excerpt, 16 );
                    $key     = strtolower( trim( preg_replace( '/\s+/', ' ', $title ) ) );
                    $image   = isset( $map[ $key ] ) ? wpbb_child_v141_asset_url( $map[ $key ] ) : '';
                    if ( ! $image ) {
                        $thumb = get_post_thumbnail_id( $id );
                        $image = $thumb ? wp_get_attachment_image_url( $thumb, 'full' ) : '';
                    }
                    $terms   = get_the_terms( $id, 'product_cat' );
                    $eyebrow = '';
                    if ( is_array( $terms ) && ! empty( $terms ) && ! is_wp_error( $terms ) ) $eyebrow = (string) $terms[0]->name;
                    ?>
                    <article class="wpbb-v141-product-card">
                        <a class="wpbb-v141-product-media" href="<?php echo esc_url( $url ); ?>" aria-label="<?php echo esc_attr( $title ); ?>">
                            <?php if ( $image ) : ?><img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="eager" decoding="async"><?php endif; ?>
                        </a>
                        <div class="wpbb-v141-product-body">
                            <?php if ( $eyebrow ) : ?><p class="wp-theme-sector-eyebrow"><?php echo esc_html( $eyebrow ); ?></p><?php endif; ?>
                            <h3><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $title ); ?></a></h3>
                            <?php if ( $excerpt ) : ?><p class="wpbb-v141-product-copy"><?php echo esc_html( $excerpt ); ?></p><?php endif; ?>
                            <a class="btn btn-primary wpbb-v141-product-link" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html__( 'Open card', 'wp-bbtheme-child-insurance' ); ?></a>
                        </div>
                    </article>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </div>
        <?php
        return trim( ob_get_clean() );
    }
    add_filter( 'render_block', 'wpbb_child_v141_catalogue', PHP_INT_MAX, 2 );
}

if ( ! function_exists( 'wpbb_child_v141_clean_visible_block_comments' ) ) {
    function wpbb_child_v141_clean_visible_block_comments( $content ) {
        if ( ! is_string( $content ) || '' === $content ) return $content;
        return (string) preg_replace( '~(?:<|&lt;)![\-–—]{1,3}\s*wp:wpbb/icon-card\b.*?wpbb-sector-proof-card.*?/\s*[\-–—]{1,3}(?:>|&gt;)~isu', '', $content );
    }
    add_filter( 'the_content', 'wpbb_child_v141_clean_visible_block_comments', PHP_INT_MAX );
}

if ( ! function_exists( 'wpbb_child_v141_enqueue' ) ) {
    function wpbb_child_v141_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();

        // Safety net for sites that keep object-cache state between theme uploads.
        foreach ( range( 119, 140 ) as $n ) {
            $handle = 'wpbb-suite-v' . $n;
            wp_dequeue_style( $handle );
            wp_deregister_style( $handle );
            wp_dequeue_script( $handle );
            wp_deregister_script( $handle );
        }

        $css = '/assets/suite-v141.css';
        $js  = '/assets/suite-v141.js';
        wp_enqueue_style(
            'wpbb-suite-v141',
            $uri . $css,
            wp_style_is( 'wpbb-suite-v118', 'enqueued' ) ? array( 'wpbb-suite-v118' ) : array(),
            is_readable( $dir . $css ) ? (string) filemtime( $dir . $css ) : '3.8.11.41'
        );
        wp_enqueue_script(
            'wpbb-suite-v141',
            $uri . $js,
            array(),
            is_readable( $dir . $js ) ? (string) filemtime( $dir . $js ) : '3.8.11.41',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v141',
            'window.wpbbSuiteV141=' . wp_json_encode( array(
                'version'  => '3.8.11.41',
                'heroUrls' => wpbb_child_v141_hero_urls(),
            ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ';',
            'before'
        );
    }
    add_action( 'wp_enqueue_scripts', 'wpbb_child_v141_enqueue', PHP_INT_MAX );
}

if ( ! function_exists( 'wpbb_child_v141_body_class' ) ) {
    function wpbb_child_v141_body_class( $classes ) {
        $classes[] = 'wpbb-v141';
        return array_values( array_unique( $classes ) );
    }
    add_filter( 'body_class', 'wpbb_child_v141_body_class', PHP_INT_MAX );
}
