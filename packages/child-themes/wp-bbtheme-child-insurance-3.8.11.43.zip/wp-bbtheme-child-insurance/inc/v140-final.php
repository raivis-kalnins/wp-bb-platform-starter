<?php
/**
 * WP BBTheme child suite 3.8.11.40 — single homepage owner.
 *
 * Removes the two competing late DOM runtimes (v137/v138), replaces the
 * fragile process/gallery/catalogue blocks with deterministic child-owned
 * markup, and loads one final homepage geometry/media layer.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v140_asset_url' ) ) {
    function wpbb_child_v140_asset_url( $relative ) {
        $relative = ltrim( (string) $relative, '/' );
        $path = get_stylesheet_directory() . '/' . $relative;
        if ( ! is_file( $path ) ) return '';
        return get_stylesheet_directory_uri() . '/' . $relative . '?v=' . filemtime( $path );
    }
}

if ( ! function_exists( 'wpbb_child_v140_product_image_map' ) ) {
    function wpbb_child_v140_product_image_map() {
        return array(
            'car roadside'       => 'assets/img/demo/product-1.jpg',
            'roadside plus'      => 'assets/img/demo/product-2.jpg',
            'home plus'          => 'assets/img/demo/product-3.jpg',
            'uk plus'            => 'assets/img/demo/product-4.jpg',
            'euro plus'          => 'assets/img/demo/product-5.jpg',
            'van roadside 3.5t'  => 'assets/img/demo/product-6.jpg',
            'motorbike plus'     => 'assets/img/demo/product-7.jpg',
            'mobility plus'      => 'assets/img/demo/product-8.jpg',
        );
    }
}

if ( ! function_exists( 'wpbb_child_v140_process_card' ) ) {
    function wpbb_child_v140_process_card( $block_content, $block ) {
        if ( ! is_array( $block ) || 'wpbb/icon-card' !== (string) ( $block['blockName'] ?? '' ) ) return $block_content;
        $attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
        $class = (string) ( $attrs['className'] ?? '' );
        if ( false === strpos( $class, 'wp-theme-process-card' ) ) return $block_content;

        $raw_title = trim( wp_strip_all_tags( (string) ( $attrs['title'] ?? '' ) ) );
        $text      = trim( wp_strip_all_tags( (string) ( $attrs['text'] ?? '' ) ) );
        $step      = '';
        $title     = $raw_title;
        if ( preg_match( '/^\s*(\d{1,2})\s+(.+)$/u', $raw_title, $m ) ) {
            $step  = str_pad( $m[1], 2, '0', STR_PAD_LEFT );
            $title = trim( $m[2] );
        }
        if ( '' === $step ) $step = '01';

        ob_start();
        ?>
        <article class="wpbb-v140-process-card">
            <span class="wpbb-v140-process-step"><?php echo esc_html( $step ); ?></span>
            <?php if ( '' !== $title ) : ?><h3><?php echo esc_html( $title ); ?></h3><?php endif; ?>
            <?php if ( '' !== $text ) : ?><p><?php echo esc_html( $text ); ?></p><?php endif; ?>
        </article>
        <?php
        return trim( ob_get_clean() );
    }
}
add_filter( 'render_block', 'wpbb_child_v140_process_card', PHP_INT_MAX, 2 );

if ( ! function_exists( 'wpbb_child_v140_gallery' ) ) {
    function wpbb_child_v140_gallery( $block_content, $block ) {
        if ( ! is_array( $block ) || 'wpbb/swiper' !== (string) ( $block['blockName'] ?? '' ) ) return $block_content;
        $attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
        if ( 'gallery' !== (string) ( $attrs['demoStyle'] ?? '' ) ) return $block_content;

        $cards = array(
            array( 'assets/img/demo/item-1.jpg', __( 'Personal insurance guidance', 'wp-bbtheme-child-insurance' ) ),
            array( 'assets/img/demo/item-2.jpg', __( 'Home insurance', 'wp-bbtheme-child-insurance' ) ),
            array( 'assets/img/demo/item-4.jpg', __( 'Vehicle cover', 'wp-bbtheme-child-insurance' ) ),
        );

        ob_start();
        ?>
        <div class="wpbb-v140-gallery-grid" data-wpbb-v140-gallery>
            <?php foreach ( $cards as $card ) :
                $src = wpbb_child_v140_asset_url( $card[0] );
                if ( ! $src ) continue;
                ?>
                <article class="wpbb-v140-gallery-card">
                    <figure class="wpbb-v140-gallery-media"><img src="<?php echo esc_url( $src ); ?>" alt="<?php echo esc_attr( $card[1] ); ?>" loading="eager" decoding="async"></figure>
                    <div class="wpbb-v140-gallery-body"><p class="wp-theme-sector-eyebrow"><?php echo esc_html__( 'Gallery', 'wp-bbtheme-child-insurance' ); ?></p><h3><?php echo esc_html( $card[1] ); ?></h3></div>
                </article>
            <?php endforeach; ?>
        </div>
        <?php
        return trim( ob_get_clean() );
    }
}
add_filter( 'render_block', 'wpbb_child_v140_gallery', PHP_INT_MAX, 2 );

if ( ! function_exists( 'wpbb_child_v140_catalogue' ) ) {
    function wpbb_child_v140_catalogue( $block_content, $block ) {
        if ( ! is_array( $block ) || 'wpbb/catalogue' !== (string) ( $block['blockName'] ?? '' ) ) return $block_content;
        $attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
        $class = (string) ( $attrs['className'] ?? '' );
        if ( false === strpos( $class, 'wp-theme-home-product-catalogue' ) && false === strpos( (string) $block_content, 'wp-theme-home-product-catalogue' ) ) return $block_content;
        if ( ! class_exists( 'WP_Query' ) ) return $block_content;

        $query = new WP_Query( array(
            'post_type'           => 'product',
            'post_status'         => 'publish',
            'posts_per_page'      => 8,
            'orderby'             => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
            'order'               => 'ASC',
            'ignore_sticky_posts' => true,
            'no_found_rows'       => true,
        ) );
        if ( ! $query->have_posts() ) return $block_content;

        $map = wpbb_child_v140_product_image_map();
        ob_start();
        ?>
        <div class="wp-theme-home-product-catalogue wpbb-v140-catalogue" data-wpbb-v140-catalogue>
            <div class="wpbb-v140-product-grid">
                <?php while ( $query->have_posts() ) : $query->the_post();
                    $id      = get_the_ID();
                    $title   = get_the_title( $id );
                    $url     = get_permalink( $id );
                    $excerpt = trim( wp_strip_all_tags( get_the_excerpt( $id ) ) );
                    if ( '' === $excerpt ) $excerpt = trim( wp_strip_all_tags( (string) get_post_field( 'post_content', $id ) ) );
                    $excerpt = wp_trim_words( $excerpt, 18 );
                    $key     = strtolower( trim( preg_replace( '/\s+/', ' ', $title ) ) );
                    $image   = isset( $map[ $key ] ) ? wpbb_child_v140_asset_url( $map[ $key ] ) : '';
                    if ( ! $image ) {
                        $thumb = get_post_thumbnail_id( $id );
                        $image = $thumb ? wp_get_attachment_image_url( $thumb, 'full' ) : '';
                    }
                    $terms   = get_the_terms( $id, 'product_cat' );
                    $eyebrow = '';
                    if ( is_array( $terms ) && ! empty( $terms ) && ! is_wp_error( $terms ) ) $eyebrow = (string) $terms[0]->name;
                    ?>
                    <article class="wpbb-v140-product-card">
                        <a class="wpbb-v140-product-media" href="<?php echo esc_url( $url ); ?>" aria-label="<?php echo esc_attr( $title ); ?>">
                            <?php if ( $image ) : ?><img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="eager" decoding="async"><?php endif; ?>
                        </a>
                        <div class="wpbb-v140-product-body">
                            <?php if ( $eyebrow ) : ?><p class="wp-theme-sector-eyebrow"><?php echo esc_html( $eyebrow ); ?></p><?php endif; ?>
                            <h3><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $title ); ?></a></h3>
                            <?php if ( $excerpt ) : ?><p class="wpbb-v140-product-copy"><?php echo esc_html( $excerpt ); ?></p><?php endif; ?>
                            <a class="btn btn-primary wpbb-v140-product-link" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html__( 'Open card', 'wp-bbtheme-child-insurance' ); ?></a>
                        </div>
                    </article>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </div>
        <?php
        return trim( ob_get_clean() );
    }
}
if ( function_exists( 'wpbb_child_v138_render_home_catalogue' ) ) {
    remove_filter( 'render_block', 'wpbb_child_v138_render_home_catalogue', PHP_INT_MAX );
}
add_filter( 'render_block', 'wpbb_child_v140_catalogue', PHP_INT_MAX, 2 );

if ( ! function_exists( 'wpbb_child_v140_clean_visible_block_comments' ) ) {
    function wpbb_child_v140_clean_visible_block_comments( $content ) {
        if ( ! is_string( $content ) || '' === $content ) return $content;
        // Imported demo snapshots may contain malformed Gutenberg comments with
        // typographic dashes. Remove only the known proof-card comment payloads.
        $content = preg_replace( '~(?:<|&lt;)![\-–—]{1,3}\s*wp:wpbb/icon-card\b.*?wpbb-sector-proof-card.*?/\s*[\-–—]{1,3}(?:>|&gt;)~isu', '', $content );
        return $content;
    }
}
add_filter( 'the_content', 'wpbb_child_v140_clean_visible_block_comments', PHP_INT_MAX );
add_filter( 'wp_theme_demo_extra_home_sections', 'wpbb_child_v140_clean_visible_block_comments', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v140_enqueue' ) ) {
    function wpbb_child_v140_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();

        // v137 and v138 both mutate the same homepage grids/media. Retire all
        // late DOM owners and keep v140 as the only runtime after v118.
        foreach ( range( 119, 139 ) as $n ) {
            $handle = 'wpbb-suite-v' . $n;
            wp_dequeue_script( $handle );
            wp_deregister_script( $handle );
        }

        $css = '/assets/suite-v140.css';
        $js  = '/assets/suite-v140.js';
        wp_enqueue_style(
            'wpbb-suite-v140',
            $uri . $css,
            wp_style_is( 'wpbb-suite-v139', 'enqueued' ) ? array( 'wpbb-suite-v139' ) : array(),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.40'
        );
        wp_enqueue_script(
            'wpbb-suite-v140',
            $uri . $js,
            array(),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.40',
            true
        );

        $hero = array();
        foreach ( array( 1, 2, 3 ) as $i ) {
            foreach ( array( 'assets/img/hero-v136/slide-' . $i . '.jpg', 'assets/img/demo/hero-hq.jpg' ) as $rel ) {
                $url = wpbb_child_v140_asset_url( $rel );
                if ( $url ) { $hero[] = $url; break; }
            }
        }
        $products = array();
        foreach ( wpbb_child_v140_product_image_map() as $name => $rel ) {
            $url = wpbb_child_v140_asset_url( $rel );
            if ( $url ) $products[ $name ] = $url;
        }
        wp_add_inline_script(
            'wpbb-suite-v140',
            'window.wpbbSuiteV140=' . wp_json_encode( array(
                'version'  => '3.8.11.40',
                'heroUrls' => $hero,
                'products' => $products,
                'gallery'  => array_values( array_filter( array(
                    wpbb_child_v140_asset_url( 'assets/img/demo/item-1.jpg' ),
                    wpbb_child_v140_asset_url( 'assets/img/demo/item-2.jpg' ),
                    wpbb_child_v140_asset_url( 'assets/img/demo/item-4.jpg' ),
                ) ) ),
            ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v140_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v140_body_class' ) ) {
    function wpbb_child_v140_body_class( $classes ) {
        $classes[] = 'wpbb-v140';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v140_body_class', PHP_INT_MAX );
