<?php
/**
 * WP BBTheme child suite 3.8.11.38 — homepage geometry and media hardening.
 *
 * The previous client-side catalogue repair still inherited the catalogue
 * block's nested Bootstrap percentage columns.  This layer removes that
 * dependency by rendering the homepage catalogue as a native child-theme grid
 * and gives the remaining homepage sections one explicit shell/grid owner.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'wpbb_child_v138_asset_url' ) ) {
    function wpbb_child_v138_asset_url( $relative ) {
        $relative = ltrim( (string) $relative, '/' );
        $path = get_stylesheet_directory() . '/' . $relative;
        if ( ! is_file( $path ) ) return '';
        return get_stylesheet_directory_uri() . '/' . $relative . '?v=' . filemtime( $path );
    }
}

if ( ! function_exists( 'wpbb_child_v138_media_urls' ) ) {
    function wpbb_child_v138_media_urls() {
        $gallery = array();
        $blog    = array();
        $case    = array();
        for ( $i = 1; $i <= 4; $i++ ) {
            $url = wpbb_child_v138_asset_url( 'assets/img/demo/item-' . $i . '.jpg' );
            if ( $url ) $gallery[] = $url;
        }
        for ( $i = 1; $i <= 3; $i++ ) {
            $url = wpbb_child_v138_asset_url( 'assets/img/blog/blog-' . $i . '.jpg' );
            if ( $url ) $blog[] = $url;
            $url = wpbb_child_v138_asset_url( 'assets/img/site-previews/project-' . $i . '.jpg' );
            if ( $url ) $case[] = $url;
        }
        return array( 'gallery' => $gallery, 'blog' => $blog, 'case' => $case );
    }
}

if ( ! function_exists( 'wpbb_child_v138_render_home_catalogue' ) ) {
    /**
     * Replace only the managed homepage catalogue block.  Rendering our own
     * flat grid means old .row/.col percentage rules can no longer turn the
     * eight cards into narrow vertical slivers.
     */
    function wpbb_child_v138_render_home_catalogue( $block_content, $block ) {
        if ( ! is_array( $block ) || 'wpbb/catalogue' !== (string) ( $block['blockName'] ?? '' ) ) return $block_content;
        $attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
        $class = (string) ( $attrs['className'] ?? '' );
        if ( false === strpos( $class, 'wp-theme-home-product-catalogue' ) && false === strpos( (string) $block_content, 'wp-theme-home-product-catalogue' ) ) return $block_content;
        if ( ! class_exists( 'WP_Query' ) ) return $block_content;

        $query = new WP_Query( array(
            'post_type'           => 'product',
            'post_status'         => 'publish',
            'posts_per_page'      => 8,
            'orderby'             => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
            'order'               => 'ASC',
            'ignore_sticky_posts' => true,
            'no_found_rows'       => true,
        ) );
        if ( ! $query->have_posts() ) return $block_content;

        $fallback_index = 1;
        ob_start();
        ?>
        <div class="wp-theme-home-product-catalogue wpbb-v138-catalogue" data-wpbb-v138-catalogue>
            <div class="wpbb-v138-product-grid">
                <?php while ( $query->have_posts() ) : $query->the_post();
                    $id      = get_the_ID();
                    $title   = get_the_title( $id );
                    $url     = get_permalink( $id );
                    $excerpt = trim( wp_strip_all_tags( get_the_excerpt( $id ) ) );
                    if ( '' === $excerpt ) $excerpt = trim( wp_strip_all_tags( (string) get_post_field( 'post_content', $id ) ) );
                    $excerpt = wp_trim_words( $excerpt, 18 );
                    $thumb   = get_post_thumbnail_id( $id );
                    $image   = $thumb ? wp_get_attachment_image_url( $thumb, 'full' ) : '';
                    if ( ! $image ) $image = wpbb_child_v138_asset_url( 'assets/img/demo/product-' . $fallback_index . '.jpg' );
                    $fallback_index = $fallback_index >= 8 ? 1 : $fallback_index + 1;
                    $terms = get_the_terms( $id, 'product_cat' );
                    $eyebrow = '';
                    if ( is_array( $terms ) && ! empty( $terms ) && ! is_wp_error( $terms ) ) $eyebrow = (string) $terms[0]->name;
                    ?>
                    <article class="wpbb-v138-product-card">
                        <a class="wpbb-v138-product-media" href="<?php echo esc_url( $url ); ?>" aria-label="<?php echo esc_attr( $title ); ?>">
                            <?php if ( $image ) : ?><img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="eager" decoding="async"><?php endif; ?>
                        </a>
                        <div class="wpbb-v138-product-body">
                            <?php if ( $eyebrow ) : ?><p class="wp-theme-sector-eyebrow wpbb-v138-product-eyebrow"><?php echo esc_html( $eyebrow ); ?></p><?php endif; ?>
                            <h3 class="wpbb-v138-product-title"><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $title ); ?></a></h3>
                            <?php if ( $excerpt ) : ?><p class="wpbb-v138-product-copy"><?php echo esc_html( $excerpt ); ?></p><?php endif; ?>
                            <a class="btn btn-primary wpbb-v138-product-link" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html__( 'Open card', 'wp-bbtheme-child-insurance' ); ?></a>
                        </div>
                    </article>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </div>
        <?php
        return trim( ob_get_clean() );
    }
}
add_filter( 'render_block', 'wpbb_child_v138_render_home_catalogue', PHP_INT_MAX, 2 );

if ( ! function_exists( 'wpbb_child_v138_enqueue' ) ) {
    function wpbb_child_v138_enqueue() {
        $dir = get_stylesheet_directory();
        $uri = get_stylesheet_directory_uri();
        $css = '/assets/suite-v138.css';
        $js  = '/assets/suite-v138.js';

        wp_enqueue_style(
            'wpbb-suite-v138',
            $uri . $css,
            wp_style_is( 'wpbb-suite-v137', 'enqueued' ) ? array( 'wpbb-suite-v137' ) : array(),
            is_file( $dir . $css ) ? filemtime( $dir . $css ) : '3.8.11.38'
        );
        wp_enqueue_script(
            'wpbb-suite-v138',
            $uri . $js,
            wp_script_is( 'wpbb-suite-v137', 'enqueued' ) ? array( 'wpbb-suite-v137' ) : array(),
            is_file( $dir . $js ) ? filemtime( $dir . $js ) : '3.8.11.38',
            true
        );
        wp_add_inline_script(
            'wpbb-suite-v138',
            'window.wpbbSuiteV138=' . wp_json_encode( array(
                'version' => '3.8.11.38',
                'media'   => wpbb_child_v138_media_urls(),
            ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ';',
            'before'
        );
    }
}
add_action( 'wp_enqueue_scripts', 'wpbb_child_v138_enqueue', PHP_INT_MAX );

if ( ! function_exists( 'wpbb_child_v138_body_class' ) ) {
    function wpbb_child_v138_body_class( $classes ) {
        $classes[] = 'wpbb-v138';
        return array_values( array_unique( $classes ) );
    }
}
add_filter( 'body_class', 'wpbb_child_v138_body_class', PHP_INT_MAX );
